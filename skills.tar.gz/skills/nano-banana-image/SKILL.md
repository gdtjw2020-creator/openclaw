---
name: nano-banana-image
description: AI图像生成和编辑工具。使用Nano Banana API生成高质量图片，支持多种尺寸（1K/2K/4K）和宽高比（1:1/16:9/9:16/4:3/3:4），可基于提示词生成或编辑现有图片。适用于：小梅情感文章配图、头像生成、图片编辑、创意设计等场景。需要配置BANANA2_API_KEY环境变量。
---

# Nano Banana Image

使用Nano Banana API生成和编辑AI图片。

## 前置条件

### 1. 安装依赖
```bash
pip install -r scripts/requirements.txt
```

### 2. 配置API密钥
设置环境变量（必需）：
```bash
export BANANA2_API_KEY="your_api_key_here"
export BANANA2_BASE_URL="https://ai.t8star.cn"  # 可选，默认值
```

**获取API密钥**：访问 https://ai.t8star.cn 注册账号

## 使用方法

### 图像生成

**基本用法**：
```python
from scripts.nano_banana_api import NanoBananaAPI

api = NanoBananaAPI(api_key="your_key", base_url="https://ai.t8star.cn")

# 生成图片
url = api.generate_image(
    prompt="一只可爱的橘猫在花园里玩耍，阳光明媚，高清摄影风格",
    width=1024,
    height=1024,
    aspect_ratio="1:1",
    image_size="2K"
)
print(f"Generated URL: {url}")
```

**小梅文章配图示例**：
```python
# 封面图（16:9 横图）
url = api.generate_image(
    prompt="Girl looking at phone with hopeful expression, waiting for message, warm bedroom light, cinematic composition, watercolor illustration style, soft muted colors",
    aspect_ratio="16:9",
    image_size="2K"
)

# 插图（1:1 方图）
url = api.generate_image(
    prompt="Orange cat sleeping on phone, cozy bedroom, warm afternoon light, watercolor illustration",
    aspect_ratio="1:1",
    image_size="1K"
)
```

### 参数说明

#### generate_image 参数

| 参数 | 类型 | 必需 | 默认值 | 说明 |
|------|------|------|--------|------|
| `prompt` | string | ✅ | - | 图片生成提示词（中英文均可，最大25000字符） |
| `width` | int | ❌ | 1024 | 图片宽度（256-4096） |
| `height` | int | ❌ | 1024 | 图片高度（256-4096） |
| `aspect_ratio` | string | ❌ | "16:9" | 宽高比：1:1, 16:9, 9:16, 4:3, 3:4 |
| `image_size` | string | ❌ | "2K" | 图片质量：1K, 2K, 4K |
| `reference_image_urls` | list | ❌ | [] | 参考图片URL列表 |

#### edit_image 参数

| 参数 | 类型 | 必需 | 说明 |
|------|------|------|------|
| `image_path` | string | ✅ | 要编辑的图片路径 |
| `prompt` | string | ✅ | 编辑提示词 |
| `aspect_ratio` | string | ❌ | 输出宽高比（默认1:1） |
| `image_size` | string | ❌ | 输出质量（默认1K） |
| `reference_images` | list | ❌ | 参考图片路径列表 |

### 图像编辑

```python
# 编辑现有图片
url = api.edit_image(
    image_path="/path/to/image.jpg",
    prompt="将猫咪的眼睛变成蓝色，增加阳光效果",
    aspect_ratio="1:1",
    image_size="2K"
)
print(f"Edited URL: {url}")
```

### 图像上传和下载

```python
# 上传本地图片到服务器
url = api.upload_image(file_path="/path/to/local/image.png")
print(f"Uploaded URL: {url}")

# 从URL下载图片到本地
success = api.download_image(
    url="https://example.com/image.png",
    save_path="/path/to/save/downloaded.png"
)
print(f"Download success: {success}")
```

## 小梅文章配图工作流

**完整流程**：
```python
from scripts.nano_banana_api import NanoBananaAPI
import os

api = NanoBananaAPI(
    api_key=os.getenv("BANANA2_API_KEY"),
    base_url="https://ai.t8star.cn"
)

# 1. 生成封面图（16:9）
cover_url = api.generate_image(
    prompt="[文章核心意象], [情绪氛围], cinematic composition, watercolor illustration style, soft muted colors",
    aspect_ratio="16:9",
    image_size="2K"
)

# 2. 生成插图1（开头氛围图）
img1_url = api.generate_image(
    prompt="[文章开头场景], [情绪氛围], watercolor style, gentle mood, soft colors",
    aspect_ratio="1:1",
    image_size="1K"
)

# 3. 生成插图2（结尾收尾图）
img2_url = api.generate_image(
    prompt="[文章结尾意象或小梅记忆点], peaceful atmosphere, watercolor style, gentle mood",
    aspect_ratio="1:1",
    image_size="1K"
)

# 4. 下载所有图片
api.download_image(cover_url, "xiaomei-works/[日期]/[主题]/cover.png")
api.download_image(img1_url, "xiaomei-works/[日期]/[主题]/img1.png")
api.download_image(img2_url, "xiaomei-works/[日期]/[主题]/img2.png")
```

**提示词模板**：

| 文章主题 | 封面提示词 | 插图提示词 |
|----------|------------|------------|
| 暧昧期 | Girl looking at phone with hopeful expression, waiting for message, warm bedroom light, cinematic composition, watercolor illustration style, soft muted colors | Orange cat sleeping on phone, cozy bedroom, warm afternoon light, watercolor illustration |
| 深夜想你 | Phone glowing in dark room, unsent message on screen, lonely atmosphere, watercolor style, blue tones | Coffee cup on windowsill at night, city lights outside, melancholic watercolor style |
| 下雨天的回忆 | Rainy window with blurred city lights, nostalgic mood, cinematic composition, 16:9, watercolor illustration style | Coffee cup on windowsill, rain drops on glass, nostalgic mood, watercolor illustration |

## 常见问题

### Q: API调用失败？
A: 检查以下几点：
1. API密钥是否正确设置：`echo $BANANA2_API_KEY`
2. 网络连接是否正常
3. 提示词是否过长（最大25000字符）

### Q: 图片质量不够好？
A: 尝试：
1. 提高 `image_size` 参数（1K → 2K → 4K）
2. 优化提示词，添加更多细节描述
3. 使用 `reference_image_urls` 提供参考图片

### Q: 生成速度慢？
A: 正常情况下需要10-30秒，取决于：
1. 图片尺寸（4K比1K慢）
2. 服务器负载
3. 网络状况

### Q: 如何控制图片风格？
A: 在提示词中添加风格关键词：
- 水彩风：`watercolor illustration style, soft muted colors`
- 摄影风：`high quality photography, professional lighting`
- 动漫风：`anime style, vibrant colors, detailed`
- 油画风：`oil painting style, rich textures`

## 错误处理

脚本包含完善的错误处理机制：
- API调用错误会显示详细信息
- 文件操作错误会检查路径和权限
- 网络错误会自动重试（最多3次）

**调试模式**：
```python
import logging
logging.basicConfig(level=logging.DEBUG)
# 然后调用API，会看到详细日志
```

## 参考

- **API文档**：https://ai.t8star.cn
- **小梅情感写作**：xiaomei-emotional-writing skill
- **图片美化**：wechat-article-beautifier skill
