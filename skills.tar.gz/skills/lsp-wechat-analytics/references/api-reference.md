# 微信公众号 API 参考

## Access Token

### 获取 Access Token
```
GET https://api.weixin.qq.com/cgi-bin/token
```

参数：
- `grant_type`: client_credential
- `appid`: 公众号 AppID
- `secret`: 公众号 AppSecret

返回：
```json
{
  "access_token": "ACCESS_TOKEN",
  "expires_in": 7200
}
```

## 文章管理

### 获取已发布文章列表
```
POST https://api.weixin.qq.com/cgi-bin/freepublish/batchget?access_token=ACCESS_TOKEN
```

请求体：
```json
{
  "offset": 0,
  "count": 20,
  "no_content": 1
}
```

返回：
```json
{
  "total_count": 100,
  "item_count": 20,
  "item": [
    {
      "article_id": "ARTICLE_ID",
      "content": {
        "news_item": [
          {
            "title": "标题",
            "thumb_url": "封面图URL",
            "url": "文章URL",
            "digest": "摘要"
          }
        ]
      },
      "update_time": 1640000000
    }
  ]
}
```

## 数据统计

### 获取图文群发每日数据
```
POST https://api.weixin.qq.com/datacube/getarticlesummary?access_token=ACCESS_TOKEN
```

请求体：
```json
{
  "begin_date": "2024-01-01",
  "end_date": "2024-01-07"
}
```

### 获取图文群发总数据
```
POST https://api.weixin.qq.com/datacube/getarticletotal?access_token=ACCESS_TOKEN
```

返回字段说明：
- `int_page_read_user`: 图文页阅读人数
- `int_page_read_count`: 图文页阅读次数
- `ori_page_read_user`: 原文页阅读人数
- `share_user`: 分享人数
- `share_count`: 分享次数
- `add_to_fav_user`: 收藏人数

## 错误码

| 错误码 | 说明 |
|--------|------|
| 40001 | access_token 无效 |
| 40014 | access_token 过期 |
| 45009 | 接口调用超过限制 |
| 48001 | 没有该接口权限 |

## 注意事项

1. Access Token 有效期 2 小时，需要缓存并定期刷新
2. 数据统计接口最多查询 7 天数据
3. 统计数据有 1-3 天延迟
4. API 调用有频率限制，建议合理控制调用频率
