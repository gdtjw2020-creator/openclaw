---
name: wechat-message-autoreply
description: 微信公众号消息自动回复技能包。基于 RPA 技术与 AI 语义理解结合，支持：(1) 读取留言内容 (2) AI 模拟真人理解并回复 (3) 高级拟人化点击绕过拦截 (4) 弹窗(Portal)深度适配。
---

# WeChat Message Autoreply (Smart Edition)

基于 RPA 技术与 AI 语义理解结合的微信公众号后台留言自动回复工具。

## 更新亮点 (Premium Upgrades)

- **AI 智能意图识别**：拒绝机械化回复。流程优化为：(1) 抓取未回复评论内容 (2) 让 AI 理解语境并拟定富有感情的“真人感”回复 (3) 执行发送。
- **全链路拟人化**：强制使用 `simulateHumanClick` 模拟完整的事件链（Pointer -> Mouse -> Click），完全绕过前端框架的事件拦截。
- **Portal 深度搜索**：针对微信后台使用 Portal 挂载弹窗的特性，脚本支持跨上下文搜索“确定/发送”按钮，确保 100% 成功率。

## 前置要求

1.  **已登录的 Chrome 浏览器**：必须在调试模式下启动并登录。
2.  **MCP Server**：配置 `chrome-devtools` 服务。
3.  **页面状态**：停留在“留言管理”页面 (`/misc/appmsgcomment`)。

## 核心 API (scripts/message_reply.js)

- `fetchUnrepliedComments()`: 返回当前页未回复评论的 JSON 数组。
- `_replySingleItem(element, text)`: 执行单条回复动作。
- `simulateHumanClick(element)`: 强制拟人化点击交互。

## 最佳实践：智能回复流程

1.  **第一步：获取评论 JSON**
    ```javascript
    const comments = await fetchUnrepliedComments();
    console.log(JSON.stringify(comments)); 
    ```
2.  **第二步：让 AI (Antigravity) 拟稿**。将上述 JSON 告知 AI 助手，由其为每条内容拟定个性化回复。
3.  **第三步：分发回复**
    ```javascript
    const smartReplies = { "听风": "马斯克一定会被你的创意打动的！😉", ... };
    const items = await fetchUnrepliedComments();
    for (let it of items) {
        if (smartReplies[it.user]) {
            await _replySingleItem(it.element, smartReplies[it.user]);
        }
    }
    ```

## 故障排查

- **发送按钮置灰**：脚本已集成 `input/change` 事件派发。若依然置灰，请检查是否有敏感词触发系统拦截。
- **找不到按钮**：微信 UI 若调整，请检查 `_replySingleItem` 中的按钮关键词（目前匹配：确定、发送、回复）。
