# 小梅情感写作技能 - 经验总结

## 2026-01-31 写作任务经验总结

### 执行情况
- ✅ 选题策划、文案创作、配图生成、美化排版全部完成
- ❌ 自动化发布到草稿箱失败（浏览器服务不稳定）
- ✅ 提供了手动复制方案作为备选

### 问题分析

#### 1. 浏览器自动化服务不稳定
**问题：**
- Linux headless浏览器频繁断开连接
- 无法完成账号切换（从AI绘画美人切换到小梅的深夜随笔）
- Cookie清除后session仍然有效
- 用户无法看到Linux后台的浏览器界面

**根本原因：**
- 浏览器自动化服务依赖gateway，但gateway在Linux后台运行不稳定
- 跨设备操作（你操作本地，我操作Linux服务器）导致无法同步状态
- 公众号登录状态保存在HTTP-only cookie中，JavaScript清除无效

**解决方案：**
- 优先提供手动复制方案（带复制按钮的HTML文件）
- 仅在用户明确要求且环境稳定时才尝试自动化发布
- 在SKILL.md中明确说明：发布步骤默认为手动操作

#### 2. 缺少带复制功能的HTML文件
**问题：**
- 最初生成的HTML文件没有复制按钮
- 用户需要富文本格式（带样式）直接粘贴到公众号
- WhatsApp不支持发送富文本格式

**根本原因：**
- 按照SKILL.md，美化后直接尝试自动发布
- 没有考虑到自动发布可能失败的情况
- 缺少中间形态：带复制按钮的HTML

**解决方案：**
- 在Step 7（美化排版）后，额外生成 `article_wechat_copy.html`
- 该文件包含：
  - 复制按钮（使用JavaScript navigator.clipboard API）
  - 内联样式的HTML内容（公众号只支持内联样式）
  - 使用说明
  - 预览区域
- 用户可以打开HTML文件，点击按钮，直接粘贴到公众号

#### 3. 图片需要单独处理
**问题：**
- HTML中的图片引用是相对路径（img1.png, img2.png）
- 公众号编辑器要求图片必须先上传到公众号服务器
- 无法直接粘贴本地图片

**解决方案：**
- 在HTML文件中用文字标记图片位置
- 提醒用户在公众号编辑器中手动上传并插入图片
- 或在复制HTML后，手动替换图片URL为公众号图片库的URL

### 流程改进建议

#### 修改后的完整流程

**Step 0-6:** 保持不变
- 读取知识库 → 创建目录 → 选题 → 文案 → 标题 → 审核 → 生成配图

**Step 7:** 美化排版（新增输出）
- 生成 `article_wechat.html` - 原始美化版本
- **新增** 生成 `article_wechat_copy.html` - 带复制按钮版本
  - 所有样式内联
  - JavaScript复制按钮
  - 使用说明
  - 图片位置标记

**Step 8:** 发布（改为多种方案）
- **方案A（推荐）：手动复制粘贴**
  - 用户打开 `article_wechat_copy.html`
  - 点击复制按钮
  - 粘贴到公众号编辑器
  - 手动上传图片并插入
- **方案B（条件允许）：自动化发布**
  - 仅在以下条件满足时尝试：
    1. 用户明确要求自动发布
    2. 浏览器服务稳定可用
    3. 已登录正确的公众号
  - 使用Chrome DevTools方式操作
- **方案C（备选）：发送文件**
  - 通过其他方式发送HTML和图片文件
  - 用户手动导入

### 技术细节

#### 带复制按钮的HTML文件模板

```html
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>文章标题 - 公众号复制版</title>
<style>
  /* 页面样式（不影响复制内容） */
  body { max-width: 800px; margin: 0 auto; padding: 20px; }
  .copy-btn { 
    background: #07c160; 
    color: white; 
    border: none; 
    padding: 12px 24px; 
    font-size: 16px; 
    border-radius: 4px; 
    cursor: pointer; 
    width: 100%; 
  }
  .preview-box { 
    background: white; 
    padding: 30px 25px; 
    border-radius: 8px; 
    margin-top: 20px; 
  }
</style>
</head>
<body>
<h1>文章标题</h1>
<div class="instructions">
使用说明：点击按钮复制，然后粘贴到公众号编辑器
</div>

<button class="copy-btn" onclick="copyArticle()">📋 复制文章内容</button>
<div id="successMsg" style="display:none; background: #d4edda; padding: 12px; margin: 10px 0;">
✅ 复制成功！
</div>

<div class="preview-box">
<div id="articleContent">
  <!-- 文章内容，所有样式内联 -->
  <p style="font-size: 15px; color: #595959; line-height: 1.75; text-indent: 2em;">
    文章内容...
  </p>
</div>
</div>

<script>
function copyArticle() {
  const content = document.getElementById('articleContent').innerHTML;
  const blob = new Blob([content], { type: 'text/html' });
  const clipboardItem = new ClipboardItem({
    'text/html': blob,
    'text/plain': new Blob([document.getElementById('articleContent').innerText], { type: 'text/plain' })
  });
  
  navigator.clipboard.write([clipboardItem]).then(function() {
    document.getElementById('successMsg').style.display = 'block';
    setTimeout(() => { document.getElementById('successMsg').style.display = 'none'; }, 3000);
  }).catch(function(err) {
    alert('复制失败，请手动复制');
  });
}
</script>
</body>
</html>
```

#### 内联样式转换

公众号编辑器只支持内联样式，需要将CSS转换为style属性：

**转换前（CSS类）：**
```html
<style>
.article-content p { color: #595959; line-height: 1.75; }
</style>
<div class="article-content">
  <p>内容</p>
</div>
```

**转换后（内联样式）：**
```html
<div>
  <p style="color: #595959; line-height: 1.75;">内容</p>
</div>
```

### 其他发现

#### 1. 工作目录结构优化

当前结构：
```
xiaomei-works/[日期]/[主题]/
├── article.md
├── article_wechat.html
├── creative_brief.json
├── cover.png
├── img1.png
├── img2.png
└── publish_info.json
```

建议新增：
```
├── article_wechat_copy.html  # 带复制按钮的HTML
└── README.md  # 快速说明文件
```

#### 2. 用户沟通要点

遇到发布问题时，应该：
1. 快速判断问题类型（服务/权限/账号）
2. 立即提供备选方案
3. 解释清楚技术限制（避免用户误解）
4. 提供具体的操作步骤

**错误示例：**
- "浏览器服务断开了，我也不知道怎么办"
- "让我再试试"（重复失败的操作）

**正确示例：**
- "浏览器自动化服务不稳定。我准备了备选方案：带复制按钮的HTML文件，你可以手动复制到公众号编辑器。需要我现在发送吗？"

### 后续行动

1. ✅ 创建 `article_wechat_copy.html` 模板脚本
2. ⏳ 更新 SKILL.md，添加新的Step 7.5（生成复制文件）
3. ⏳ 更新 Step 8（改为多种发布方案）
4. ⏳ 在 references/ 中添加本文档

### 总结

**成功的部分：**
- 文案创作质量高（符合小梅人设）
- 配图生成顺利
- 美化排版成功

**需要改进的部分：**
- 缺少备选发布方案
- HTML文件缺少复制功能
- 对浏览器自动化的依赖过高

**核心教训：**
> 永远提供备选方案。自动化可能失败，但手动操作永远可用。

---

创建时间：2026-01-31  
任务：一月再见，那些我们没能说出口的话  
状态：文案完成，发布改为手动
