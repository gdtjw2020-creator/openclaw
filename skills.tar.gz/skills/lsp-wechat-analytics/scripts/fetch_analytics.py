#!/usr/bin/env python3
"""
微信公众号文章数据获取脚本
获取已发布文章的阅读数据并保存到本地
"""

import os
import json
import requests
from datetime import datetime, timedelta
from pathlib import Path
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

APP_ID = os.getenv('WECHAT_APP_ID')
APP_SECRET = os.getenv('WECHAT_APP_SECRET')

# 数据存储路径
ANALYTICS_DIR = Path('works/analytics')
ARTICLES_FILE = ANALYTICS_DIR / 'articles.json'
ARCHIVE_FILE = ANALYTICS_DIR / 'articles_archive.json'


def get_access_token():
    """获取微信 Access Token"""
    url = f'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={APP_ID}&secret={APP_SECRET}'
    response = requests.get(url)
    data = response.json()
    
    if 'access_token' in data:
        return data['access_token']
    else:
        raise Exception(f"获取 Access Token 失败: {data}")


def get_published_articles(access_token, offset=0, count=20):
    """获取已发布文章列表"""
    url = f'https://api.weixin.qq.com/cgi-bin/freepublish/batchget?access_token={access_token}'
    payload = {
        'offset': offset,
        'count': count,
        'no_content': 1
    }
    response = requests.post(url, json=payload)
    return response.json()


def get_article_stats(access_token, begin_date, end_date):
    """获取文章数据统计"""
    url = f'https://api.weixin.qq.com/datacube/getarticletotal?access_token={access_token}'
    payload = {
        'begin_date': begin_date,
        'end_date': end_date
    }
    response = requests.post(url, json=payload)
    return response.json()


def load_existing_articles():
    """加载现有文章数据"""
    if ARTICLES_FILE.exists():
        with open(ARTICLES_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {'articles': [], 'last_updated': None}


def save_articles(data):
    """保存文章数据"""
    ANALYTICS_DIR.mkdir(parents=True, exist_ok=True)
    data['last_updated'] = datetime.now().isoformat()
    with open(ARTICLES_FILE, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"✅ 数据已保存到 {ARTICLES_FILE}")


def archive_articles(articles):
    """归档历史文章数据"""
    archive = {'articles': [], 'archived_at': None}
    if ARCHIVE_FILE.exists():
        with open(ARCHIVE_FILE, 'r', encoding='utf-8') as f:
            archive = json.load(f)
    
    # 添加新文章到归档
    existing_ids = {a.get('article_id') for a in archive['articles']}
    for article in articles:
        if article.get('article_id') not in existing_ids:
            archive['articles'].append(article)
    
    archive['archived_at'] = datetime.now().isoformat()
    with open(ARCHIVE_FILE, 'w', encoding='utf-8') as f:
        json.dump(archive, f, ensure_ascii=False, indent=2)


def fetch_all_articles():
    """获取所有文章数据"""
    if not APP_ID or not APP_SECRET:
        print("❌ 错误：请在 .env 文件中配置 WECHAT_APP_ID 和 WECHAT_APP_SECRET")
        return
    
    print("🔄 正在获取 Access Token...")
    access_token = get_access_token()
    
    print("📚 正在获取文章列表...")
    all_articles = []
    offset = 0
    
    while True:
        result = get_published_articles(access_token, offset=offset)
        
        if 'item' not in result or len(result['item']) == 0:
            break
        
        for item in result['item']:
            content = item.get('content', {})
            news_item = content.get('news_item', [{}])[0] if content.get('news_item') else {}
            
            article = {
                'article_id': item.get('article_id'),
                'title': news_item.get('title', ''),
                'publish_time': datetime.fromtimestamp(item.get('update_time', 0)).isoformat(),
                'cover_url': news_item.get('thumb_url', ''),
                'url': news_item.get('url', ''),
                'digest': news_item.get('digest', ''),
                # 阅读数据需要单独获取
                'read_num': 0,
                'like_num': 0,
                'share_num': 0,
                'comment_num': 0
            }
            all_articles.append(article)
        
        offset += len(result['item'])
        if offset >= result.get('total_count', 0):
            break
    
    print(f"📊 共获取 {len(all_articles)} 篇文章")
    
    # 保存数据
    data = {'articles': all_articles}
    save_articles(data)
    archive_articles(all_articles)
    
    return all_articles


if __name__ == '__main__':
    fetch_all_articles()
