# 微信公众号 API 文档

## 目录
1. [获取 Access Token](#获取-access-token)
2. [上传图片](#上传图片)
3. [上传永久素材](#上传永久素材)
4. [创建草稿](#创建草稿)
5. [发布草稿](#发布草稿)

---

## 获取 Access Token

### 接口地址
```
GET https://api.weixin.qq.com/cgi-bin/token
```

### 参数
| 参数 | 必填 | 说明 |
|------|------|------|
| grant_type | 是 | 固定值 `client_credential` |
| appid | 是 | 公众号的 AppID |
| secret | 是 | 公众号的 AppSecret |

### 返回示例
```json
{
  "access_token": "ACCESS_TOKEN",
  "expires_in": 7200
}
```

### 注意事项
- access_token 有效期为 2 小时
- 建议缓存 token，避免频繁请求
- 每日调用上限 2000 次

---

## 上传图片

用于上传图文消息内的图片，获取图片 URL。

### 接口地址
```
POST https://api.weixin.qq.com/cgi-bin/media/uploadimg?access_token=ACCESS_TOKEN
```

### 参数
| 参数 | 必填 | 说明 |
|------|------|------|
| media | 是 | form-data 中媒体文件标识 |

### 返回示例
```json
{
  "url": "http://mmbiz.qpic.cn/xxx"
}
```

### 注意事项
- 图片大小限制 2MB
- 支持 jpg, png, gif 格式
- 返回的 URL 可直接用于文章内容

---

## 上传永久素材

用于上传封面图等永久素材。

### 接口地址
```
POST https://api.weixin.qq.com/cgi-bin/material/add_material?access_token=ACCESS_TOKEN&type=TYPE
```

### 参数
| 参数 | 必填 | 说明 |
|------|------|------|
| type | 是 | 素材类型：image/voice/video/thumb |
| media | 是 | form-data 中媒体文件标识 |

### 返回示例
```json
{
  "media_id": "MEDIA_ID",
  "url": "URL"
}
```

### 素材类型说明
- `image`: 图片，2MB，支持 bmp/png/jpeg/jpg/gif
- `thumb`: 缩略图，64KB，支持 jpg
- `voice`: 语音，2MB，支持 mp3/wma/wav/amr
- `video`: 视频，10MB，支持 mp4

---

## 创建草稿

### 接口地址
```
POST https://api.weixin.qq.com/cgi-bin/draft/add?access_token=ACCESS_TOKEN
```

### 请求体
```json
{
  "articles": [
    {
      "title": "文章标题",
      "author": "作者",
      "digest": "摘要",
      "content": "HTML内容",
      "content_source_url": "原文链接",
      "thumb_media_id": "封面图media_id",
      "show_cover_pic": 0,
      "need_open_comment": 1,
      "only_fans_can_comment": 0
    }
  ]
}
```

### 参数说明
| 参数 | 必填 | 说明 |
|------|------|------|
| title | 是 | 标题，最多64字节 |
| author | 否 | 作者，最多8字节 |
| digest | 否 | 摘要，最多120字节 |
| content | 是 | 正文HTML，最多2万字符 |
| content_source_url | 否 | 原文链接 |
| thumb_media_id | 是 | 封面图的media_id |
| show_cover_pic | 否 | 是否显示封面，0不显示，1显示 |
| need_open_comment | 否 | 是否开启评论，0关闭，1开启 |
| only_fans_can_comment | 否 | 是否仅粉丝可评论 |

### 返回示例
```json
{
  "media_id": "MEDIA_ID"
}
```

### 内容格式要求
- 必须是 HTML 格式
- 样式必须内联（style 属性）
- 不支持外部 CSS 和 JavaScript
- 图片必须使用微信服务器的 URL

---

## 发布草稿

### 接口地址
```
POST https://api.weixin.qq.com/cgi-bin/freepublish/submit?access_token=ACCESS_TOKEN
```

### 请求体
```json
{
  "media_id": "MEDIA_ID"
}
```

### 返回示例
```json
{
  "errcode": 0,
  "errmsg": "ok",
  "publish_id": "PUBLISH_ID"
}
```

### 注意事项
- 发布后文章进入审核状态
- 审核通过后自动发布
- 可通过 publish_id 查询发布状态

---

## 其他常用接口

### 获取草稿列表
```
POST https://api.weixin.qq.com/cgi-bin/draft/batchget?access_token=ACCESS_TOKEN
```

### 删除草稿
```
POST https://api.weixin.qq.com/cgi-bin/draft/delete?access_token=ACCESS_TOKEN
```

### 获取发布状态
```
POST https://api.weixin.qq.com/cgi-bin/freepublish/get?access_token=ACCESS_TOKEN
```

---

## 调用频率限制

| 接口 | 限制 |
|------|------|
| 获取 access_token | 2000次/天 |
| 上传图片 | 100次/天 |
| 上传永久素材 | 10次/天（图片5000张上限） |
| 创建草稿 | 无明确限制 |
| 发布 | 无明确限制 |
