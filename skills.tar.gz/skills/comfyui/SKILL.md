---
name: comfyui
description: AI图片生成工具，通过ComfyUI MCP服务器生成高质量AI图片。使用此skill当用户需要：生成AI图片、调整图片尺寸、使用不同工作流、批量生成图片、图片编辑（使用Flux2 Klein模型）、从参考图片生成新图片等AI图片相关任务
---

# ComfyUI AI图片生成

通过ComfyUI MCP服务器生成、下载和管理AI图片。

## 前置条件

- ComfyUI服务运行在 `http://127.0.0.1:8188`
- 安装依赖：`pip install mcp fastmcp httpx pydantic`

## 主要工具

### comfyui_generate_image

生成AI图片。

**参数：**
- `prompt` (必需): 正向提示词
- `negative_prompt` (可选): 负向提示词，默认"blurry ugly bad"
- `workflow_path` (可选): 工作流文件，默认"Flux2 Klein_edit_api_local.json"
- `filename_prefix` (可选): 文件名前缀，默认"mcp_generated"
- `download_to_local` (可选): 是否下载，默认true
- `output_dir` (可选): 输出目录（相对/绝对路径）
- `seed` (可选): 随机种子
- `width` (可选): 宽度，默认720
- `height` (可选): 高度，默认1280
- `reference_image` (可选): 参考图片路径（ComfyUI input目录）

**默认尺寸：** 720x1280（竖版）

### comfyui_check_status

检查生成任务状态。

**参数：**
- `prompt_id` (必需): 任务ID

### comfyui_download_image

下载已生成的图片。

**参数：**
- `filename` (必需): 图片文件名
- `output_dir` (可选): 保存目录
- `subfolder` (可选): 子文件夹
- `local_filename` (可选): 本地文件名

### comfyui_list_workflows

列出可用的工作流文件。

## 工作流

### Flux2 Klein工作流

默认工作流支持：
- 高质量图片生成
- 图片编辑（参考图片）
- 图片调整尺寸

**节点映射：**
- 节点117: 正向提示词 (CR Text)
- 节点102: 种子 (RandomNoise)
- 节点122: 尺寸 (ImageResize+)
- 节点76: 参考图片 (LoadImage)
- 节点9: 保存 (SaveImage)

### 原始工作流

**节点映射：**
- 节点6: 正向提示词
- 节点7: 负向提示词
- 节点3: 种子
- 节点13: 尺寸
- 节点9: 保存

## 路径配置

### 相对路径
```json
{"output_dir": "./ai_images"}
```
保存在调用方项目的ai_images目录

### 绝对路径
```json
{"output_dir": "C:/MyImages/AI"}
```

### 不指定output_dir
保存在MCP项目的generated_images目录

## 常见场景

### 生成图片并自动下载
```json
{"prompt": "一只可爱的橘猫在阳光下睡觉，细节丰富"}
```

### 自定义尺寸
```json
{"prompt": "赛博朋克城市", "width": 1536, "height": 1024}
```

### 使用参考图片
```json
{"prompt": "将图片风格改为油画效果", "reference_image": "pasted/photo.jpg"}
```

### 固定种子
```json
{"prompt": "测试图片", "seed": 12345}
```

## 故障排除

**无法连接到ComfyUI：**
- 确认ComfyUI运行在 http://127.0.0.1:8188
- 检查端口是否被占用

**工作流文件不存在：**
- 确认工作流文件在正确路径
- 使用 `comfyui_list_workflows` 检查可用文件

**生成超时：**
- 降低图片分辨率
- 检查GPU资源
- 增加超时时间（默认300秒）

## 最佳实践

1. 使用详细的提示词描述
2. 合理使用负向提示词
3. 控制图片尺寸以平衡质量和速度
4. 定期清理生成的图片
5. 使用固定种子重现结果
