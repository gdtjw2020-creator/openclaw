# 主题样式库

## 目录
1. [Default 主题](#default-主题)
2. [Elegant 主题](#elegant-主题)
3. [Tech 主题](#tech-主题)
4. [Vibrant 主题](#vibrant-主题)

---

## Default 主题

简洁大方，适合通用文章。

```css
/* ===== Default Theme ===== */

/* 容器 */
.article-container {
  max-width: 677px;
  margin: 0 auto;
  padding: 20px;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  background: #fff;
}

/* 标题 */
h1 {
  font-size: 22px;
  font-weight: bold;
  color: #333;
  text-align: center;
  margin: 25px 0 20px;
  line-height: 1.4;
}

h2 {
  font-size: 18px;
  font-weight: bold;
  color: #333;
  border-bottom: 1px solid #eee;
  padding-bottom: 10px;
  margin: 25px 0 15px;
  line-height: 1.4;
}

h3 {
  font-size: 16px;
  font-weight: bold;
  color: #333;
  margin: 20px 0 12px;
  line-height: 1.4;
}

h4, h5, h6 {
  font-size: 15px;
  font-weight: bold;
  color: #555;
  margin: 15px 0 10px;
}

/* 段落 */
p {
  font-size: 15px;
  color: #333;
  line-height: 1.8;
  margin: 15px 0;
  text-align: justify;
}

/* 引用块 */
blockquote {
  border-left: 3px solid #07c160;
  background: #f9f9f9;
  padding: 12px 15px;
  margin: 20px 0;
  color: #666;
  font-size: 14px;
  line-height: 1.7;
}

blockquote p {
  margin: 0;
  font-size: 14px;
}

/* 代码块 */
pre {
  background: #282c34;
  color: #abb2bf;
  padding: 15px;
  border-radius: 5px;
  overflow-x: auto;
  font-size: 13px;
  line-height: 1.6;
  margin: 20px 0;
}

pre code {
  font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, Monaco, monospace;
  background: none;
  padding: 0;
  color: inherit;
}

/* 行内代码 */
code {
  font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, Monaco, monospace;
  background: #f0f0f0;
  padding: 2px 6px;
  border-radius: 3px;
  color: #c7254e;
  font-size: 14px;
}

/* 列表 */
ul, ol {
  padding-left: 25px;
  margin: 15px 0;
}

li {
  font-size: 15px;
  line-height: 1.8;
  color: #333;
  margin: 8px 0;
}

/* 图片 */
img {
  max-width: 100%;
  height: auto;
  display: block;
  margin: 20px auto;
  border-radius: 5px;
}

/* 链接 */
a {
  color: #07c160;
  text-decoration: none;
}

/* 分割线 */
hr {
  border: none;
  border-top: 1px dashed #ddd;
  margin: 25px 0;
}

/* 表格 */
table {
  width: 100%;
  border-collapse: collapse;
  margin: 20px 0;
  font-size: 14px;
}

th, td {
  border: 1px solid #ddd;
  padding: 10px 12px;
  text-align: left;
}

th {
  background: #f5f5f5;
  font-weight: bold;
}

/* 强调 */
strong {
  font-weight: bold;
  color: #333;
}

em {
  font-style: italic;
  color: #555;
}
```

---

## Elegant 主题

文艺清新风格，适合生活、情感类文章。

```css
/* ===== Elegant Theme ===== */

.article-container {
  max-width: 677px;
  margin: 0 auto;
  padding: 25px;
  font-family: "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif;
  background: #fefefe;
}

h1 {
  font-size: 24px;
  font-weight: 500;
  color: #2c3e50;
  text-align: center;
  margin: 30px 0 25px;
  letter-spacing: 2px;
}

h2 {
  font-size: 18px;
  font-weight: 500;
  color: #34495e;
  margin: 28px 0 15px;
  padding-left: 12px;
  border-left: 4px solid #e74c3c;
}

h3 {
  font-size: 16px;
  font-weight: 500;
  color: #2c3e50;
  margin: 22px 0 12px;
}

p {
  font-size: 15px;
  color: #444;
  line-height: 2;
  margin: 18px 0;
  text-align: justify;
  letter-spacing: 0.5px;
}

blockquote {
  background: linear-gradient(to right, #ffecd2, #fcb69f);
  border: none;
  border-radius: 8px;
  padding: 15px 20px;
  margin: 22px 0;
  color: #5d4e37;
  font-size: 14px;
  font-style: italic;
}

pre {
  background: #2d3436;
  color: #dfe6e9;
  padding: 18px;
  border-radius: 8px;
  font-size: 13px;
  line-height: 1.6;
  margin: 22px 0;
}

code {
  font-family: "Fira Code", Consolas, monospace;
  background: #ffeaa7;
  padding: 2px 8px;
  border-radius: 4px;
  color: #d63031;
  font-size: 14px;
}

ul, ol {
  padding-left: 22px;
  margin: 18px 0;
}

li {
  font-size: 15px;
  line-height: 2;
  color: #444;
  margin: 10px 0;
}

img {
  max-width: 100%;
  border-radius: 10px;
  margin: 25px auto;
  box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

a {
  color: #e74c3c;
  text-decoration: none;
  border-bottom: 1px dashed #e74c3c;
}

hr {
  border: none;
  height: 1px;
  background: linear-gradient(to right, transparent, #bdc3c7, transparent);
  margin: 30px 0;
}

strong {
  color: #e74c3c;
  font-weight: 600;
}
```

---

## Tech 主题

科技感风格，适合技术教程类文章。

```css
/* ===== Tech Theme ===== */

.article-container {
  max-width: 677px;
  margin: 0 auto;
  padding: 20px;
  font-family: -apple-system, "SF Pro Text", "Helvetica Neue", Arial, sans-serif;
  background: #fff;
}

h1 {
  font-size: 24px;
  font-weight: 700;
  color: #1a1a2e;
  text-align: center;
  margin: 25px 0;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

h2 {
  font-size: 18px;
  font-weight: 600;
  color: #16213e;
  margin: 25px 0 15px;
  padding: 8px 15px;
  background: #f8f9fa;
  border-left: 4px solid #667eea;
  border-radius: 0 5px 5px 0;
}

h3 {
  font-size: 16px;
  font-weight: 600;
  color: #1a1a2e;
  margin: 20px 0 12px;
}

p {
  font-size: 15px;
  color: #333;
  line-height: 1.8;
  margin: 15px 0;
}

blockquote {
  background: #e8f4f8;
  border-left: 4px solid #0984e3;
  padding: 12px 18px;
  margin: 20px 0;
  color: #2d3436;
  font-size: 14px;
  border-radius: 0 8px 8px 0;
}

pre {
  background: #1e1e1e;
  color: #d4d4d4;
  padding: 18px;
  border-radius: 8px;
  font-size: 13px;
  line-height: 1.6;
  margin: 20px 0;
  border: 1px solid #333;
}

code {
  font-family: "JetBrains Mono", "Fira Code", Consolas, monospace;
  background: #e3f2fd;
  padding: 3px 8px;
  border-radius: 4px;
  color: #1565c0;
  font-size: 14px;
}

ul, ol {
  padding-left: 25px;
  margin: 15px 0;
}

li {
  font-size: 15px;
  line-height: 1.8;
  color: #333;
  margin: 8px 0;
}

li::marker {
  color: #667eea;
}

img {
  max-width: 100%;
  border-radius: 8px;
  margin: 20px auto;
  border: 1px solid #eee;
}

a {
  color: #667eea;
  text-decoration: none;
  font-weight: 500;
}

hr {
  border: none;
  height: 2px;
  background: linear-gradient(to right, #667eea, #764ba2);
  margin: 30px 0;
  border-radius: 1px;
}

table {
  width: 100%;
  border-collapse: collapse;
  margin: 20px 0;
  font-size: 14px;
}

th {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 12px;
  text-align: left;
}

td {
  border: 1px solid #e0e0e0;
  padding: 10px 12px;
}

tr:nth-child(even) {
  background: #f8f9fa;
}

strong {
  color: #667eea;
  font-weight: 600;
}
```

---

## Vibrant 主题

活泼明亮风格，适合营销、活动类文章。

```css
/* ===== Vibrant Theme ===== */

.article-container {
  max-width: 677px;
  margin: 0 auto;
  padding: 20px;
  font-family: "PingFang SC", "Microsoft YaHei", sans-serif;
  background: #fff;
}

h1 {
  font-size: 24px;
  font-weight: bold;
  color: #fff;
  text-align: center;
  margin: 25px 0;
  padding: 15px 20px;
  background: linear-gradient(135deg, #ff6b6b, #feca57);
  border-radius: 10px;
}

h2 {
  font-size: 18px;
  font-weight: bold;
  color: #ff6b6b;
  margin: 25px 0 15px;
  padding-bottom: 8px;
  border-bottom: 2px dashed #feca57;
}

h3 {
  font-size: 16px;
  font-weight: bold;
  color: #5f27cd;
  margin: 20px 0 12px;
}

p {
  font-size: 15px;
  color: #333;
  line-height: 1.9;
  margin: 15px 0;
}

blockquote {
  background: #fff3cd;
  border: 2px solid #feca57;
  border-radius: 10px;
  padding: 15px 18px;
  margin: 20px 0;
  color: #856404;
  font-size: 14px;
}

pre {
  background: #2d3436;
  color: #74b9ff;
  padding: 18px;
  border-radius: 10px;
  font-size: 13px;
  line-height: 1.6;
  margin: 20px 0;
  border: 2px solid #0984e3;
}

code {
  font-family: Consolas, monospace;
  background: #dfe6e9;
  padding: 3px 8px;
  border-radius: 5px;
  color: #d63031;
  font-size: 14px;
}

ul {
  list-style: none;
  padding-left: 0;
  margin: 15px 0;
}

ul li {
  font-size: 15px;
  line-height: 1.9;
  color: #333;
  margin: 10px 0;
  padding-left: 25px;
  position: relative;
}

ul li::before {
  content: "🔥";
  position: absolute;
  left: 0;
}

ol {
  padding-left: 25px;
  margin: 15px 0;
}

ol li {
  font-size: 15px;
  line-height: 1.9;
  color: #333;
  margin: 10px 0;
}

img {
  max-width: 100%;
  border-radius: 12px;
  margin: 20px auto;
  box-shadow: 0 5px 20px rgba(255, 107, 107, 0.3);
}

a {
  color: #ff6b6b;
  text-decoration: none;
  font-weight: bold;
}

hr {
  border: none;
  height: 3px;
  background: linear-gradient(to right, #ff6b6b, #feca57, #48dbfb, #ff6b6b);
  margin: 30px 0;
  border-radius: 2px;
}

strong {
  color: #ff6b6b;
  font-weight: bold;
}

em {
  color: #5f27cd;
  font-style: normal;
  background: #f0e6ff;
  padding: 2px 5px;
  border-radius: 3px;
}
```

---

## 使用方法

1. 选择适合文章风格的主题
2. 将对应的 CSS 应用到 HTML
3. 使用 CSS 内联化工具处理
4. 生成最终的公众号格式内容
