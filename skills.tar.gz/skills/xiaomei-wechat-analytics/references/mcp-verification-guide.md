# 使用 Chrome DevTools MCP 工具验证账号

本文档展示如何使用 Chrome DevTools MCP 工具来验证当前登录的公众号是否为小梅的账号。

## 操作步骤

### 1. 获取页面快照

首先，确保你已经打开了 Chrome 浏览器并访问了公众号后台：

```
https://mp.weixin.qq.com/
```

然后使用以下 MCP 工具获取页面快照：

```javascript
chrome-devtools_take_snapshot
```

### 2. 检查账号名称

从返回的快照中查找公众号名称。公众号名称通常出现在：
- 页面标题（title 标签）
- 页面顶部的导航栏
- 左上角的账号信息区域

### 3. 验证账号

检查找到的公众号名称是否为：

```
小梅的深夜随笔
```

### 4. 执行验证脚本

如果需要使用 Python 脚本验证，可以运行：

```bash
cd .opencode/skill/wechat-analytics/scripts
python verify_account.py
```

## 快照示例

**正确的快照应该包含：**

```json
{
  "title": "小梅的深夜随笔 | 公众号平台",
  "url": "https://mp.weixin.qq.com/cgi-bin/home",
  "elements": [
    {
      "type": "heading",
      "value": "小梅的深夜随笔"
    }
  ]
}
```

## 验证通过后的操作

如果验证通过，可以继续：

1. 使用 `chrome-devtools_take_snapshot` 获取文章数据
2. 使用 `chrome-devtools_evaluate_script` 提取文章信息
3. 保存数据到 `works/analytics/articles.json`
4. 运行 `analyze_articles.py` 分析数据

## 验证失败处理

如果验证失败（账号名称不是"小梅的深夜随笔"），请：

1. 退出当前公众号账号
2. 重新登录正确的公众号
3. 刷新页面
4. 重新获取快照并验证

## 示例 MCP 工具调用

### 导航到公众号后台

```javascript
chrome-devtools_navigate_page
{
  "type": "url",
  "url": "https://mp.weixin.qq.com/"
}
```

### 获取页面快照

```javascript
chrome-devtools_take_snapshot
```

### 等待页面加载

```javascript
chrome-devtools_wait_for
{
  "text": "近期发表"
}
```

## 自动化验证脚本示例

如果需要自动化验证流程，可以创建一个脚本：

```python
from scripts.verify_account import verify_account_name, save_config, load_config
from datetime import datetime

# 假设从快照中获取的账号名称
current_account = "小梅的深夜随笔"  # 或从 MCP 快照中提取

# 验证账号
is_valid, message = verify_account_name(current_account)
print(message)

if is_valid:
    # 更新配置
    config = load_config()
    config['last_checked_account'] = current_account
    config['last_verified_time'] = datetime.now().isoformat()
    save_config(config)
    print("✅ 验证通过，可以继续抓取数据")
else:
    print("❌ 验证失败，请切换到正确的账号")
    exit(1)
```

## 注意事项

1. 确保已经登录公众号后台
2. 确保页面完全加载完成
3. 公众号名称必须完全匹配"小梅的深夜随笔"
4. 如果遇到验证失败，请先检查是否登录了正确的账号