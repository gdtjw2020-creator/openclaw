# 工作流配置说明

## 工作流类型

### 1. Flux2 Klein工作流

**文件名：** `Flux2 Klein_edit_api_local.json`

**特点：**
- 高质量图片生成
- 支持图片编辑
- 支持参考图片
- 灵活的尺寸调整

**节点结构：**
```
节点117 (CR Text): 正向提示词
节点102 (RandomNoise): 随机种子
节点122 (ImageResize+): 图片尺寸
节点76 (LoadImage): 参考图片加载
节点9 (SaveImage): 图片保存
```

**适用场景：**
- 生成高质量AI图片
- 基于参考图片编辑
- 批量生成不同尺寸
- 需要精细控制

**参数配置：**
```json
{
  "prompt": "你的提示词",
  "width": 720,
  "height": 1280,
  "seed": 12345,
  "reference_image": "pasted/photo.jpg"
}
```

### 2. 原始工作流

**文件名：** `flow-api.json`

**特点：**
- 基础图片生成
- 支持负向提示词
- 简单直接

**节点结构：**
```
节点6 (CLIPTextEncode): 正向提示词
节点7 (CLIPTextEncode): 负向提示词
节点3 (KSampler): 采样器
节点13 (EmptySD3LatentImage): 尺寸
节点9 (SaveImage): 图片保存
```

**适用场景：**
- 基础图片生成
- 简单快速生成
- 需要负向提示词控制

## 自定义工作流

### 节点ID映射

当创建自定义工作流时，需要确保以下节点存在：

**Flux2 Klein格式：**
- 正向提示词节点（ID: 117）
- 种子节点（ID: 102）
- 尺寸节点（ID: 122）
- 参考图片节点（ID: 76，可选）
- 保存节点（ID: 9）

**原始格式：**
- 正向提示词节点（ID: 6）
- 负向提示词节点（ID: 7）
- 种子节点（ID: 3）
- 尺寸节点（ID: 13）
- 保存节点（ID: 9）

### 工作流导出步骤

1. **在ComfyUI中设计工作流**
   - 打开ComfyUI界面
   - 拖拽所需节点
   - 连接节点

2. **导出工作流**
   - 点击"导出API"
   - 保存为JSON文件

3. **适配MCP服务器**
   - 确保包含必需节点
   - 记录节点ID
   - 如需修改节点ID，更新`server.py`中的映射

4. **测试工作流**
   - 使用`comfyui_list_workflows`确认文件
   - 使用简单提示词测试

## 常见节点类型

### 文本编码
- `CLIPTextEncode`: 文本编码
- `CR Text`: 高级文本编码（Flux2）

### 图像处理
- `LoadImage`: 加载图片
- `ImageResize+`: 调整尺寸
- `VAEDecode`: VAE解码
- `VAELoader`: 加载VAE

### 采样
- `KSampler`: 采样器
- `RandomNoise`: 随机噪声（种子）

### 模型加载
- `UNETLoader`: 加载UNet模型
- `CLIPLoader`: 加载CLIP
- `LoraLoaderModelOnly`: 加载LoRA

### 输出
- `SaveImage`: 保存图片
- `PreviewImage`: 预览图片

## 工作流优化

### 性能优化

**1. 减少不必要的节点**
- 移除调试节点
- 避免重复处理
- 简化工作流

**2. 优化采样参数**
- 减少采样步数（20-30步通常足够）
- 调整CFG scale
- 使用合适的采样器（如euler、dpmpp）

**3. 图片尺寸**
- 从小尺寸开始测试（512x512）
- 逐步增加尺寸
- 避免过大尺寸（>2048x2048）

### 质量优化

**1. 提示词优化**
- 使用详细的提示词
- 添加质量关键词
- 合理使用负向提示词

**2. 模型选择**
- 选择适合的模型
- 考虑使用LoRA
- 测试不同模型效果

**3. 参数调优**
- 调整采样步数（20-50）
- 微调CFG scale（7-15）
- 选择合适的采样器

## 工作流管理

### 文件命名

使用有意义的文件名：
```
basic_generation.json
flux2_edit.json
portrait_workflow.json
landscape_workflow.json
```

### 版本控制

```json
workflow_v1.json
workflow_v2.json
workflow_v3_stable.json
```

### 目录组织

```
workflows/
├── basic/
│   ├── simple_gen.json
│   └── portrait.json
├── advanced/
│   ├── flux2_edit.json
│   └── style_transfer.json
└── experimental/
    └── test_workflow.json
```

## 故障排除

### 工作流加载失败

**可能原因：**
- JSON格式错误
- 缺少必需节点
- 节点ID不匹配

**解决方法：**
1. 验证JSON格式
2. 检查必需节点
3. 更新节点ID映射

### 生成结果不符合预期

**可能原因：**
- 提示词不够详细
- 参数设置不当
- 模型不适合当前任务

**解决方法：**
1. 优化提示词
2. 调整参数
3. 尝试其他工作流或模型
