#!/usr/bin/env python3
"""
微信公众号文章数据分析脚本
分析文章表现并生成报告
"""

import json
from datetime import datetime
from pathlib import Path
from collections import Counter

# 数据存储路径
ANALYTICS_DIR = Path('works/analytics')
ARTICLES_FILE = ANALYTICS_DIR / 'articles.json'
REPORT_FILE = ANALYTICS_DIR / 'analysis_report.md'
KNOWLEDGE_BASE_FILE = ANALYTICS_DIR / 'knowledge_base.json'


def load_articles():
    """加载文章数据"""
    if not ARTICLES_FILE.exists():
        print("❌ 文章数据文件不存在，请先运行 fetch_analytics.py")
        return []
    
    with open(ARTICLES_FILE, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return data.get('articles', [])


def load_knowledge_base():
    """加载知识库"""
    if KNOWLEDGE_BASE_FILE.exists():
        with open(KNOWLEDGE_BASE_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {
        'best_practices': {
            'title_patterns': [],
            'content_patterns': [],
            'publish_times': []
        },
        'performance_benchmarks': {
            'avg_read_num': 0,
            'avg_like_rate': 0
        },
        'scene_categories': {}
    }


def analyze_articles(articles):
    """分析文章数据"""
    if not articles:
        return None
    
    # 基础统计
    total_articles = len(articles)
    total_reads = sum(a.get('read_num', 0) for a in articles)
    total_likes = sum(a.get('like_num', 0) for a in articles)
    total_shares = sum(a.get('share_num', 0) for a in articles)
    
    avg_reads = total_reads / total_articles if total_articles > 0 else 0
    avg_likes = total_likes / total_articles if total_articles > 0 else 0
    
    # 按阅读量排序
    sorted_by_reads = sorted(articles, key=lambda x: x.get('read_num', 0), reverse=True)
    top_articles = sorted_by_reads[:10]
    
    # 标题分析
    title_lengths = [len(a.get('title', '')) for a in articles]
    avg_title_length = sum(title_lengths) / len(title_lengths) if title_lengths else 0
    
    # 发布时间分析
    publish_hours = []
    for a in articles:
        try:
            dt = datetime.fromisoformat(a.get('publish_time', ''))
            publish_hours.append(dt.hour)
        except:
            pass
    
    hour_counter = Counter(publish_hours)
    best_hours = hour_counter.most_common(3)
    
    return {
        'total_articles': total_articles,
        'total_reads': total_reads,
        'total_likes': total_likes,
        'total_shares': total_shares,
        'avg_reads': avg_reads,
        'avg_likes': avg_likes,
        'avg_title_length': avg_title_length,
        'top_articles': top_articles,
        'best_publish_hours': best_hours
    }


def generate_report(analysis):
    """生成分析报告"""
    if not analysis:
        return "暂无数据可分析"
    
    report = f"""# 微信公众号文章数据分析报告

生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## 📊 整体数据

| 指标 | 数值 |
|------|------|
| 文章总数 | {analysis['total_articles']} |
| 总阅读量 | {analysis['total_reads']:,} |
| 总点赞数 | {analysis['total_likes']:,} |
| 总分享数 | {analysis['total_shares']:,} |
| 平均阅读量 | {analysis['avg_reads']:.0f} |
| 平均点赞数 | {analysis['avg_likes']:.1f} |
| 平均标题长度 | {analysis['avg_title_length']:.0f} 字 |

## 🏆 阅读量 TOP 10 文章

"""
    
    for i, article in enumerate(analysis['top_articles'], 1):
        report += f"{i}. **{article.get('title', '无标题')}**\n"
        report += f"   - 阅读量：{article.get('read_num', 0):,}\n"
        report += f"   - 点赞数：{article.get('like_num', 0)}\n"
        report += f"   - 发布时间：{article.get('publish_time', '未知')[:10]}\n\n"
    
    report += """## ⏰ 最佳发布时间

"""
    
    for hour, count in analysis['best_publish_hours']:
        report += f"- {hour}:00 - {hour+1}:00 （{count} 篇文章）\n"
    
    report += """
## 💡 优化建议

1. **标题优化**：根据高阅读量文章的标题特点，优化标题写法
2. **发布时间**：选择用户活跃时段发布文章
3. **内容质量**：持续产出高质量内容，提升用户粘性
4. **互动引导**：在文章中适当引导用户点赞、分享

---
*报告由 wechat-analytics 技能自动生成*
"""
    
    return report


def update_knowledge_base(analysis):
    """更新知识库"""
    kb = load_knowledge_base()
    
    if analysis:
        kb['performance_benchmarks']['avg_read_num'] = analysis['avg_reads']
        kb['performance_benchmarks']['avg_like_rate'] = (
            analysis['avg_likes'] / analysis['avg_reads'] * 100 
            if analysis['avg_reads'] > 0 else 0
        )
        
        # 更新最佳发布时间
        kb['best_practices']['publish_times'] = [
            f"{hour}:00" for hour, _ in analysis['best_publish_hours']
        ]
    
    kb['last_updated'] = datetime.now().isoformat()
    
    with open(KNOWLEDGE_BASE_FILE, 'w', encoding='utf-8') as f:
        json.dump(kb, f, ensure_ascii=False, indent=2)
    
    print(f"✅ 知识库已更新：{KNOWLEDGE_BASE_FILE}")


def main():
    """主函数"""
    print("📊 正在分析文章数据...")
    
    articles = load_articles()
    if not articles:
        return
    
    analysis = analyze_articles(articles)
    
    # 生成报告
    report = generate_report(analysis)
    ANALYTICS_DIR.mkdir(parents=True, exist_ok=True)
    with open(REPORT_FILE, 'w', encoding='utf-8') as f:
        f.write(report)
    print(f"✅ 分析报告已生成：{REPORT_FILE}")
    
    # 更新知识库
    update_knowledge_base(analysis)
    
    # 打印摘要
    print(f"\n📈 数据摘要：")
    print(f"   文章总数：{analysis['total_articles']}")
    print(f"   平均阅读：{analysis['avg_reads']:.0f}")
    print(f"   平均点赞：{analysis['avg_likes']:.1f}")


if __name__ == '__main__':
    main()
