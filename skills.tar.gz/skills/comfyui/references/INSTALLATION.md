# ComfyUI MCP 服务器安装指南

## 系统要求

- Python 3.8+
- ComfyUI 已安装并运行
- GPU 推荐用于更好的性能

## 安装依赖

```bash
pip install mcp fastmcp httpx pydantic
```

## 配置

### 环境变量（可选）

```bash
# Windows
set COMFYUI_SERVER_URL=http://127.0.0.1:8188
set COMFYUI_WORKFLOW_PATH=Flux2 Klein_edit_api_local.json
set COMFYUI_OUTPUT_DIR=generated_images

# Linux/Mac
export COMFYUI_SERVER_URL="http://127.0.0.1:8188"
export COMFYUI_WORKFLOW_PATH="Flux2 Klein_edit_api_local.json"
export COMFYUI_OUTPUT_DIR="generated_images"
```

### 运行服务器

```bash
# 进入comfyui_mcp目录
cd comfyui_mcp

# 运行MCP服务器
python -m comfyui_mcp.server
```

### 使用MCP Inspector测试

```bash
npx @modelcontextprotocol/inspector python -m comfyui_mcp.server
```

## Claude Desktop 集成

### 配置文件位置

- **Windows**: `%APPDATA%\Claude\claude_desktop_config.json`
- **macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Linux**: `~/.config/claude/claude_desktop_config.json`

### Windows 配置

```json
{
  "mcpServers": {
    "comfyui": {
      "command": "python",
      "args": ["-m", "comfyui_mcp.server"],
      "cwd": "D:\\workspace-mcp\\local-comfyui-mcp\\comfyui_mcp",
      "env": {
        "COMFYUI_SERVER_URL": "http://127.0.0.1:8188",
        "COMFYUI_WORKFLOW_PATH": "../Flux2 Klein_edit_api_local.json",
        "COMFYUI_OUTPUT_DIR": "../generated_images"
      }
    }
  }
}
```

### macOS/Linux 配置

```json
{
  "mcpServers": {
    "comfyui": {
      "command": "python3",
      "args": ["-m", "comfyui_mcp.server"],
      "cwd": "/path/to/local-comfyui-mcp/comfyui_mcp",
      "env": {
        "COMFYUI_SERVER_URL": "http://127.0.0.1:8188",
        "COMFYUI_WORKFLOW_PATH": "../Flux2 Klein_edit_api_local.json",
        "COMFYUI_OUTPUT_DIR": "../generated_images"
      }
    }
  }
}
```

## 验证安装

在 Claude Desktop 中测试：
```
请使用 comfyui_list_workflows 列出可用的工作流
```

如果看到工作流列表，说明配置成功！
