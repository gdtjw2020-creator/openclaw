---
name: wechat-article-beautifier
description: 微信公众号文章排版美化技能包。将 Markdown 文章转换为精美的公众号格式，支持多种主题风格、代码高亮、CSS内联化处理。当需要：(1) 美化公众号文章排版 (2) Markdown转公众号格式 (3) 生成可直接粘贴到微信后台的富文本 (4) 文章主题样式定制时触发此技能。
---

# WeChat Article Beautifier

微信公众号文章排版美化技能包，将 Markdown 转换为可直接粘贴到公众号后台的精美富文本。

## 核心流程

```
Markdown源码 → 解析为HTML → 应用主题CSS → CSS内联化 → 生成可复制的富文本
```

## 快速开始

**一键美化文章：**
```
美化文章：[粘贴Markdown内容]
主题：[默认/简约/科技/文艺]
```

**生成HTML文件（可在浏览器中复制）：**
```
生成公众号文章：[文章标题]
内容：[Markdown内容]
输出：article.html
```

## Step 1: Markdown 转 HTML

使用 marked.js 或 markdown-it 将 Markdown 转换为 HTML。

**基础转换脚本** (scripts/md2html.js)：
```javascript
const marked = require('marked');

// 配置 marked
marked.setOptions({
  gfm: true,
  breaks: true,
  highlight: function(code, lang) {
    // 代码高亮处理
    return `<code class="language-${lang}">${escapeHtml(code)}</code>`;
  }
});

function convertMarkdown(markdown) {
  return marked.parse(markdown);
}
```

## Step 2: 应用主题样式

### 可用主题

| 主题名 | 风格特点 | 适用场景 |
|--------|----------|----------|
| default | 简洁大方，黑白为主 | 通用文章 |
| elegant | 文艺清新，柔和配色 | 生活/情感类 |
| tech | 科技感，深色代码块 | 技术/教程类 |
| vibrant | 活泼明亮，彩色标题 | 营销/活动类 |

### 主题CSS结构

每个主题定义以下元素样式：
- 标题 (h1-h6)
- 段落 (p)
- 引用块 (blockquote)
- 代码块 (pre, code)
- 列表 (ul, ol, li)
- 图片 (img)
- 链接 (a)
- 分割线 (hr)

## Step 3: CSS 内联化（关键步骤）

**微信公众号只识别行内样式**，必须将 CSS 转换为 `style="..."` 属性。

**内联化脚本** (scripts/inline-css.js)：
```javascript
const juice = require('juice');

function inlineStyles(html, css) {
  const fullHtml = `<style>${css}</style>${html}`;
  return juice(fullHtml, {
    removeStyleTags: true,
    preserveImportant: true
  });
}
```

**纯前端实现（无需 Node.js）：**
```javascript
function inlineStylesClient(container) {
  const elements = container.querySelectorAll('*');
  elements.forEach(el => {
    const computed = window.getComputedStyle(el);
    const styles = [];
    for (let prop of computed) {
      styles.push(`${prop}: ${computed.getPropertyValue(prop)}`);
    }
    el.style.cssText = styles.join('; ');
  });
  return container.innerHTML;
}
```

## Step 4: 生成可复制的 HTML 文件

生成一个包含"一键复制"按钮的 HTML 文件：

```html
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>公众号文章预览</title>
  <style>
    .copy-btn {
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 10px 20px;
      background: #07c160;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    .article-container {
      max-width: 677px;
      margin: 0 auto;
      padding: 20px;
    }
  </style>
</head>
<body>
  <button class="copy-btn" onclick="copyArticle()">复制到公众号</button>
  <div id="article" class="article-container">
    <!-- 内联样式后的HTML内容 -->
  </div>
  <script>
    function copyArticle() {
      const article = document.getElementById('article');
      const blob = new Blob([article.innerHTML], { type: 'text/html' });
      navigator.clipboard.write([
        new ClipboardItem({ 'text/html': blob })
      ]).then(() => {
        alert('复制成功！请到公众号后台粘贴');
      });
    }
  </script>
</body>
</html>
```

## 主题样式定义

### Default 主题（简约）

```css
/* 标题 */
h1 { font-size: 22px; font-weight: bold; color: #333; text-align: center; margin: 20px 0; }
h2 { font-size: 18px; font-weight: bold; color: #333; border-bottom: 1px solid #eee; padding-bottom: 8px; margin: 16px 0; }
h3 { font-size: 16px; font-weight: bold; color: #333; margin: 14px 0; }

/* 段落 */
p { font-size: 15px; color: #333; line-height: 1.8; margin: 12px 0; text-align: justify; }

/* 引用 */
blockquote {
  border-left: 3px solid #07c160;
  background: #f7f7f7;
  padding: 10px 15px;
  margin: 15px 0;
  color: #666;
  font-size: 14px;
}

/* 代码块 */
pre {
  background: #282c34;
  color: #abb2bf;
  padding: 15px;
  border-radius: 5px;
  overflow-x: auto;
  font-size: 13px;
  line-height: 1.5;
}
code { font-family: Consolas, Monaco, monospace; }

/* 行内代码 */
p code, li code {
  background: #f0f0f0;
  padding: 2px 6px;
  border-radius: 3px;
  color: #c7254e;
  font-size: 14px;
}

/* 列表 */
ul, ol { padding-left: 25px; margin: 12px 0; }
li { font-size: 15px; line-height: 1.8; color: #333; margin: 5px 0; }

/* 图片 */
img { max-width: 100%; height: auto; display: block; margin: 15px auto; border-radius: 5px; }

/* 链接 */
a { color: #07c160; text-decoration: none; }

/* 分割线 */
hr { border: none; border-top: 1px dashed #ddd; margin: 20px 0; }
```

## 特殊组件处理

### 代码高亮

使用 highlight.js 处理代码块：
```javascript
const hljs = require('highlight.js');

function highlightCode(code, language) {
  if (language && hljs.getLanguage(language)) {
    return hljs.highlight(code, { language }).value;
  }
  return hljs.highlightAuto(code).value;
}
```

### 图片处理

微信公众号对外链图片有限制，建议：
1. 使用微信素材库图片
2. 使用 base64 编码（小图片）
3. 使用微信允许的图床

### 脚注处理

将 Markdown 脚注转换为文末引用列表。

## 完整工作流命令

**生成完整的公众号文章：**
```
1. 读取 Markdown 文件
2. 选择主题：default/elegant/tech/vibrant
3. 执行转换：运行 scripts/beautify.js
4. 输出 HTML 文件
5. 在浏览器中打开，点击"复制到公众号"
6. 粘贴到微信公众号后台
```

## References

- **主题样式库**: See [references/themes.md](references/themes.md) 获取完整主题CSS
- **组件样式**: See [references/components.md](references/components.md) 获取特殊组件样式
- **常见问题**: See [references/faq.md](references/faq.md) 解决常见排版问题
