---
name: runninghub-text-image-gen
description: 调用 RunningHub 平台的 AI 图像生成应用，基于提示词和参考图生成人物图像。当用户需要生成符合特定描述的人物图像、需要根据提示词和参考图创作图像、或需要调用 RunningHub 图生图应用时使用此 skill。
---

# RunningHub 图像生成

基于提示词和参考图生成符合描述的人物图像。

## 功能概述

- **输入**: 提示词（描述图像内容）+ 参考图（人物基础形象）
- **输出**: 生成的符合提示词描述的人物图像
- **API**: RunningHub OpenAPI V2

## 快速开始

### 1. 确保环境变量已设置

```bash
# 设置 API 密钥
$env:RUNNINGHUB_API_KEY = "your-api-key"
```

### 2. 使用脚本调用

```bash
# 基本用法（使用已上传的图片文件名）
python scripts/text_image_gen.py -p "上半身照，图中女人在海边散步，正面镜头，黄昏时光" -i "pasted/xxx.png"

# 上传本地图片并发起任务
python scripts/text_image_gen.py -p "上半身照，女人在咖啡厅" -i "./local.png" --upload

# 等待任务完成
python scripts/text_image_gen.py -p "上半身照，女人在海边" -i "xxx.png" --wait --timeout 600
```

## API 参数说明

| 参数 | 节点ID | 字段名 | 说明 |
|------|--------|--------|------|
| 提示词 | 117 | text | 描述要生成的图像内容 |
| 参考图 | 76 | image | 已上传的参考图文件名 |

### API 请求示例

```bash
curl --location --request POST 'https://www.runninghub.cn/openapi/v2/run/ai-app/2013960462408359938' \
--header "Content-Type: application/json" \
--header "Authorization: Bearer ${RUNNINGHUB_API_KEY}" \
--data-raw '{
  "nodeInfoList": [
    {
      "nodeId": "117",
      "fieldName": "text",
      "fieldValue": "上半身照，图中女人在海边散步，正面镜头，黄昏时光",
      "description": "提示词"
    },
    {
      "nodeId": "76",
      "fieldName": "image",
      "fieldValue": "pasted/xxx.png",
      "description": "参考图"
    }
  ],
  "instanceType": "default",
  "usePersonalQueue": "false"
}'
```

## 脚本参数

| 参数 | 简写 | 必需 | 说明 |
|------|------|------|------|
| `--prompt` | `-p` | ✅ | 提示词 |
| `--image` | `-i` | ✅ | 参考图文件名或本地路径 |
| `--upload` | - | ❌ | 若 image 为本地路径，先上传 |
| `--wait` | - | ❌ | 等待任务完成 |
| `--timeout` | - | ❌ | 等待超时（秒，默认600） |
| `--instance-type` | - | ❌ | 实例类型（默认 default） |
| `--api-key` | - | ❌ | API 密钥 |
| `--output-json` | - | ❌ | JSON 格式输出 |
| `--debug` | - | ❌ | 启用详细调试日志 |
| `--retry-delay` | - | ❌ | 生图前等待时间（秒，避免并发限制，默认2） |
| `--cache-file` | - | ❌ | 缓存文件路径（默认 .runninghub_cache.json） |
| `--no-cache` | - | ❌ | 禁用上传缓存 |

## 集成到项目

在项目后端服务中调用：

```python
from scripts.text_image_gen import run_text_image_gen, wait_for_completion

# 发起任务（自动重试）
task_id = run_text_image_gen(
    prompt="上半身照，女人在海边散步",
    image_filename="uploaded/xxx.png",
    api_key=os.environ["RUNNINGHUB_API_KEY"]
)

# 等待结果
result = wait_for_completion(task_id, api_key)
print(result["outputs"])
```

## 新功能特性

### 1. 智能重试机制
- 自动处理 API 并发限制（errorCode 421）
- 重试延迟：5, 10, 15, 30, 60 秒（指数增长）
- 最多重试 5 次
- 无需手动干预

### 2. 上传缓存
- 基于文件哈希值缓存已上传的文件名
- 避免重复上传相同文件，节省带宽和时间
- 缓存文件：`.runninghub_cache.json`
- 可用 `--no-cache` 禁用

### 3. 请求间隔优化
- `--retry-delay` 参数（默认 2 秒）
- 在上传和生图之间增加延迟
- 降低触发并发限制的风险

### 4. 详细调试日志
- `--debug` 参数显示完整的请求/响应内容
- 所有关键步骤都有日志输出

## 常见问题

### Q: 提示 "API并发限制" 怎么办？
A: 脚本会自动重试，无需手动处理。如果频繁遇到，可以增加 `--retry-delay` 参数（如 `--retry-delay 5`）。

### Q: 如何禁用缓存？
A: 使用 `--no-cache` 参数强制重新上传文件。

### Q: 如何查看详细的请求信息？
A: 使用 `--debug` 参数查看完整的请求和响应内容。

### Q: API 端点是什么？
A:
- **创建任务**: `POST https://www.runninghub.cn/openapi/v2/run/ai-app/{webapp_id}`
- **查询任务/获取结果**: `POST https://www.runninghub.cn/openapi/v2/query` (Body: `{"taskId": "xxx"}`)

注意：查询任务状态和获取结果都使用 `/openapi/v2/query` 端点，它会同时返回状态和生成的图片结果。

## 提示词编写建议

- 描述人物姿态：上半身照、全身照、侧面、正面
- 描述场景：海边、咖啡厅、城市街道
- 描述光线：黄昏、日出、室内光
- 描述动作：散步、坐着、站立
