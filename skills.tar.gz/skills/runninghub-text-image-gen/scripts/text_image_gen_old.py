#!/usr/bin/env python3
"""
RunningHub 图像生成 API 调用脚本

基于提示词和参考图生成符合描述的人物图像。

使用方法:
    python text_image_gen.py --prompt "提示词" --image "参考图路径" [选项]

参数:
    --prompt, -p     : 提示词，描述要生成的图像内容
    --image, -i      : 参考图文件名（已上传到RunningHub的文件名）
    --instance-type  : 实例类型，默认 "default"
    --api-key        : API密钥（可通过环境变量 RUNNINGHUB_API_KEY 设置）
    --wait           : 等待任务完成并获取结果
    --timeout        : 等待超时时间（秒），默认 600
    --debug          : 启用详细调试日志
    --cache-file     : 缓存文件路径（保存已上传的文件名，避免重复上传）
"""

import argparse
import json
import os
import sys
import time
import requests
import hashlib
from typing import Optional, Dict, Any, List

# 默认配置
DEFAULT_BASE_URL = "https://www.runninghub.cn"
DEFAULT_WEBAPP_ID = "2013960462408359938"
DEFAULT_INSTANCE_TYPE = "default"
DEFAULT_CACHE_FILE = ".runninghub_cache.json"
DEFAULT_RETRY_DELAYS = [5, 10, 15, 30, 60]  # 重试延迟（秒），指数增长

# 节点配置
NODE_CONFIG = {
    "prompt": {"nodeId": "117", "fieldName": "text", "description": "提示词"},
    "image": {"nodeId": "76", "fieldName": "image", "description": "参考图"}
}

# 强制刷新输出的日志函数
def log(msg: str, error=False):
    """打印日志并强制刷新"""
    print(msg, file=sys.stderr if error else sys.stdout, flush=True)


def get_file_hash(file_path: str) -> str:
    """计算文件的哈希值，用于缓存键"""
    hasher = hashlib.md5()
    with open(file_path, 'rb') as f:
        hasher.update(f.read())
    return hasher.hexdigest()


def load_cache(cache_file: str) -> Dict[str, str]:
    """加载缓存：文件哈希 -> 上传后的文件名"""
    if os.path.exists(cache_file):
        try:
            with open(cache_file, 'r') as f:
                return json.load(f)
        except:
            pass
    return {}


def save_cache(cache_file: str, cache: Dict[str, str]):
    """保存缓存"""
    try:
        with open(cache_file, 'w') as f:
            json.dump(cache, f, indent=2)
    except Exception as e:
        log(f"[DEBUG] 保存缓存失败: {e}", error=True)


def upload_image(file_path: str, api_key: str, base_url: str = DEFAULT_BASE_URL, debug: bool = False) -> Optional[str]:
    """
    上传图片到 RunningHub
    
    Args:
        file_path: 本地图片文件路径
        api_key: API 密钥
        base_url: API 基础 URL
        debug: 是否启用调试模式
        
    Returns:
        上传后的文件名，失败返回 None
    """
    log(f"[DEBUG] 开始上传图片: {file_path}", error=debug)
    
    if not os.path.exists(file_path):
        log(f"错误: 文件不存在 - {file_path}", error=True)
        return None
    
    filename = os.path.basename(file_path)
    file_size = os.path.getsize(file_path)
    log(f"[DEBUG] 文件信息: {filename}, 大小: {file_size} bytes", error=debug)
    
    try:
        with open(file_path, 'rb') as f:
            file_data = f.read()
        
        files = {'file': (filename, file_data)}
        data = {'apiKey': api_key, 'fileType': 'input'}
        
        log(f"[DEBUG] 发送上传请求到: {base_url}/task/openapi/upload", error=debug)
        
        response = requests.post(
            f"{base_url}/task/openapi/upload",
            files=files,
            data=data,
            timeout=60
        )
        
        log(f"[DEBUG] 上传响应状态码: {response.status_code}", error=debug)
        
        if response.status_code == 200:
            result = response.json()
            log(f"[DEBUG] 上传响应内容: {json.dumps(result, ensure_ascii=False)}", error=debug)
            if result.get('code') == 0:
                uploaded_filename = result.get('data', {}).get('fileName')
                log(f"✓ 图片上传成功: {uploaded_filename}")
                return uploaded_filename
            else:
                log(f"✗ 上传失败: {result.get('msg')}", error=True)
                return None
        else:
            log(f"✗ 上传请求失败: {response.status_code} - {response.text}", error=True)
            return None
            
    except Exception as e:
        log(f"✗ 上传异常: {type(e).__name__}: {e}", error=True)
        import traceback
        log(f"[DEBUG] 异常堆栈:\n{traceback.format_exc()}", error=debug)
        return None


def run_text_image_gen(
    prompt: str,
    image_filename: str,
    api_key: str,
    instance_type: str = DEFAULT_INSTANCE_TYPE,
    base_url: str = DEFAULT_BASE_URL,
    webapp_id: str = DEFAULT_WEBAPP_ID,
    use_personal_queue: bool = False,
    debug: bool = False,
    retry_delays: list = None
) -> Optional[str]:
    """
    发起图像生成任务（支持智能重试）

    Args:
        prompt: 提示词
        image_filename: 已上传的参考图文件名
        api_key: API 密钥
        instance_type: 实例类型
        base_url: API 基础 URL
        webapp_id: 应用 ID
        use_personal_queue: 是否使用个人队列
        debug: 是否启用调试模式
        retry_delays: 重试延迟列表（秒）

    Returns:
        任务 ID，失败返回 None
    """
    if retry_delays is None:
        retry_delays = DEFAULT_RETRY_DELAYS

    log(f"[DEBUG] 开始创建任务", error=debug)
    log(f"[DEBUG] 提示词: {prompt}", error=debug)
    log(f"[DEBUG] 参考图: {image_filename}", error=debug)

    node_info_list = [
        {
            "nodeId": NODE_CONFIG["prompt"]["nodeId"],
            "fieldName": NODE_CONFIG["prompt"]["fieldName"],
            "fieldValue": prompt,
            "description": NODE_CONFIG["prompt"]["description"]
        },
        {
            "nodeId": NODE_CONFIG["image"]["nodeId"],
            "fieldName": NODE_CONFIG["image"]["fieldName"],
            "fieldValue": image_filename,
            "description": NODE_CONFIG["image"]["description"]
        }
    ]

    # 使用 OpenAPI V2 接口
    request_data = {
        "nodeInfoList": node_info_list,
        "instanceType": instance_type,
        "usePersonalQueue": str(use_personal_queue).lower()
    }

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }

    url = f"{base_url}/openapi/v2/run/ai-app/{webapp_id}"
    log(f"[DEBUG] 请求URL: {url}", error=debug)
    log(f"[DEBUG] 请求数据: {json.dumps(request_data, ensure_ascii=False)}", error=debug)

    # 智能重试循环
    for attempt, delay in enumerate(retry_delays, 1):
        if attempt > 1:
            log(f"⏳ 第 {attempt} 次重试，等待 {delay} 秒...", error=True)
            time.sleep(delay)

        try:
            response = requests.post(
                url,
                headers=headers,
                json=request_data,
                timeout=60
            )

            log(f"[DEBUG] 响应状态码: {response.status_code}", error=debug)
            log(f"[DEBUG] 响应内容: {response.text}", error=debug)

            if response.status_code == 200:
                result = response.json()

                # 检查是否有错误码
                error_code = result.get('errorCode', '')
                code = result.get('code')

                # 并发限制错误（421）- 可重试
                if error_code == '421' or 'limit' in str(result.get('errorMessage', '')).lower():
                    if attempt < len(retry_delays):
                        log(f"⚠ API并发限制，{delay}秒后重试 ({attempt}/{len(retry_delays)})", error=True)
                        continue
                    else:
                        log(f"✗ 达到最大重试次数，仍然受到并发限制", error=True)
                        return None

                # 其他错误 - 不可重试
                if error_code or (code and str(code) != '0'):
                    error_msg = result.get('errorMessage') or result.get('msg') or '未知错误'
                    log(f"✗ API错误: errorCode={error_code}, msg={error_msg}", error=True)
                    return None

                # 成功：提取 taskId 和 status
                task_id = result.get('taskId')
                task_status = result.get('status', 'UNKNOWN')

                if task_id:
                    if attempt > 1:
                        log(f"✓ 重试成功！任务已创建: {task_id}, 状态: {task_status}")
                    else:
                        log(f"✓ 任务已创建: {task_id}, 状态: {task_status}")
                    return task_id
                else:
                    log(f"✗ 响应中没有 taskId", error=True)
                    log(f"[DEBUG] 完整响应: {json.dumps(result, ensure_ascii=False)}", error=debug)
                    return None
            else:
                log(f"✗ API请求失败 ({response.status_code}): {response.text}", error=True)
                return None

        except Exception as e:
            log(f"✗ 发起任务异常: {type(e).__name__}: {e}", error=True)
            import traceback
            log(f"[DEBUG] 异常堆栈:\n{traceback.format_exc()}", error=debug)
            return None

    return None


def check_task_status(task_id: str, api_key: str, base_url: str = DEFAULT_BASE_URL) -> Dict[str, Any]:
    """
    查询任务状态
    
    Args:
        task_id: 任务 ID
        api_key: API 密钥
        base_url: API 基础 URL
        
    Returns:
        任务状态信息
    """
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }
    
    try:
        response = requests.post(
            f"{base_url}/openapi/v2/task/status",
            headers=headers,
            json={"taskId": task_id},
            timeout=30
        )
        
        if response.status_code == 200:
            result = response.json()
            if result.get('code') == 0:
                return {
                    "status": result.get('data', 'UNKNOWN'),
                    "taskId": task_id
                }
            return {"status": "ERROR", "message": result.get('msg')}
        return {"status": "ERROR", "message": f"HTTP {response.status_code}"}
        
    except Exception as e:
        return {"status": "ERROR", "message": str(e)}


def get_task_outputs(task_id: str, api_key: str, base_url: str = DEFAULT_BASE_URL) -> List[Dict[str, Any]]:
    """
    获取任务生成结果
    
    Args:
        task_id: 任务 ID
        api_key: API 密钥
        base_url: API 基础 URL
        
    Returns:
        生成结果列表
    """
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {api_key}"
    }
    
    try:
        response = requests.post(
            f"{base_url}/openapi/v2/task/outputs",
            headers=headers,
            json={"taskId": task_id},
            timeout=30
        )
        
        if response.status_code == 200:
            result = response.json()
            if result.get('code') == 0:
                return result.get('data', [])
            print(f"获取结果失败: {result.get('msg')}", file=sys.stderr)
            return []
        return []
        
    except Exception as e:
        print(f"获取结果异常: {e}", file=sys.stderr)
        return []


def wait_for_completion(
    task_id: str,
    api_key: str,
    base_url: str = DEFAULT_BASE_URL,
    timeout: int = 600,
    poll_interval: int = 10,
    debug: bool = False
) -> Dict[str, Any]:
    """
    等待任务完成并获取结果
    
    Args:
        task_id: 任务 ID
        api_key: API 密钥
        base_url: API 基础 URL
        timeout: 超时时间（秒）
        poll_interval: 轮询间隔（秒）
        debug: 是否启用调试模式
        
    Returns:
        包含状态和输出的字典
    """
    log(f"[DEBUG] 开始等待任务完成: {task_id}", error=debug)
    start_time = time.time()
    attempt = 0
    
    while time.time() - start_time < timeout:
        attempt += 1
        elapsed = int(time.time() - start_time)
        log(f"[DEBUG] 轮询 #{attempt}, 已等待: {elapsed}秒", error=debug)
        
        status_result = check_task_status(task_id, api_key, base_url)
        status = status_result.get("status", "UNKNOWN")
        
        log(f"任务状态: {status}")
        
        if status == "SUCCESS":
            log(f"[DEBUG] 任务成功，获取输出...", error=debug)
            outputs = get_task_outputs(task_id, api_key, base_url)
            log(f"[DEBUG] 获取到 {len(outputs)} 个输出", error=debug)
            return {"status": "SUCCESS", "outputs": outputs}
        elif status in ["FAILED", "ERROR"]:
            log(f"✗ 任务失败: {status_result.get('message', '未知错误')}", error=True)
            return {"status": status, "message": status_result.get("message", "任务失败")}
        
        time.sleep(poll_interval)
    
    log(f"✗ 任务超时（{timeout}秒）", error=True)
    return {"status": "TIMEOUT", "message": f"任务超时（{timeout}秒）"}


def main():
    parser = argparse.ArgumentParser(
        description="RunningHub 图像生成 - 基于提示词和参考图生成人物图像",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 发起任务（使用已上传的图片文件名）
  python text_image_gen.py -p "上半身照，图中女人在海边散步，正面镜头，黄昏时光" -i "uploaded/xxx.png"
  
  # 上传本地图片并发起任务
  python text_image_gen.py -p "上半身照，女人在咖啡厅" -i "./local_image.png" --upload
  
  # 发起任务并等待完成
  python text_image_gen.py -p "上半身照，女人在海边" -i "uploaded/xxx.png" --wait
        """
    )
    
    parser.add_argument("-p", "--prompt", required=True, help="提示词，描述要生成的图像内容")
    parser.add_argument("-i", "--image", required=True, help="参考图文件名（已上传）或本地路径（需要--upload）")
    parser.add_argument("--upload", action="store_true", help="如果--image是本地文件路径，先上传再使用")
    parser.add_argument("--instance-type", default=DEFAULT_INSTANCE_TYPE, help=f"实例类型 (默认: {DEFAULT_INSTANCE_TYPE})")
    parser.add_argument("--api-key", help="API密钥（也可通过RUNNINGHUB_API_KEY环境变量设置）")
    parser.add_argument("--base-url", default=DEFAULT_BASE_URL, help=f"API基础URL (默认: {DEFAULT_BASE_URL})")
    parser.add_argument("--webapp-id", default=DEFAULT_WEBAPP_ID, help=f"应用ID (默认: {DEFAULT_WEBAPP_ID})")
    parser.add_argument("--wait", action="store_true", help="等待任务完成并获取结果")
    parser.add_argument("--timeout", type=int, default=600, help="等待超时时间（秒，默认: 600）")
    parser.add_argument("--personal-queue", action="store_true", help="使用个人队列")
    parser.add_argument("--output-json", action="store_true", help="以JSON格式输出结果")
    parser.add_argument("--debug", action="store_true", help="启用详细调试日志")
    
    args = parser.parse_args()
    
    # 启用调试模式
    debug = args.debug
    if debug:
        log("=" * 60)
        log("调试模式已启用")
        log("=" * 60)
    
    # 获取 API Key
    api_key = args.api_key or os.environ.get("RUNNINGHUB_API_KEY")
    if not api_key:
        log("✗ 错误: 未提供API密钥。请通过 --api-key 参数或 RUNNINGHUB_API_KEY 环境变量设置。", error=True)
        sys.exit(1)
    
    log(f"[DEBUG] API Key: {api_key[:10]}...{api_key[-4:]}", error=debug)
    
    try:
        # 处理图片
        image_filename = args.image
        if args.upload:
            # 需要上传本地图片
            log("步骤 1/2: 上传参考图...")
            uploaded = upload_image(args.image, api_key, args.base_url, debug=debug)
            if not uploaded:
                log("✗ 错误: 图片上传失败", error=True)
                sys.exit(1)
            image_filename = uploaded
        else:
            log(f"使用已上传的图片: {image_filename}")
        
        # 发起任务
        log("步骤 2/2: 创建生成任务...")
        task_id = run_text_image_gen(
            prompt=args.prompt,
            image_filename=image_filename,
            api_key=api_key,
            instance_type=args.instance_type,
            base_url=args.base_url,
            webapp_id=args.webapp_id,
            use_personal_queue=args.personal_queue,
            debug=debug
        )
        
        if not task_id:
            log("✗ 错误: 任务创建失败", error=True)
            sys.exit(1)
        
        result = {"taskId": task_id}
        
        # 等待完成
        if args.wait:
            log(f"等待任务完成（超时: {args.timeout}秒）...")
            completion_result = wait_for_completion(
                task_id=task_id,
                api_key=api_key,
                base_url=args.base_url,
                timeout=args.timeout,
                debug=debug
            )
            result.update(completion_result)
        
        # 输出结果
        log("\n" + "=" * 60)
        if args.output_json:
            log(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            log(f"\n任务ID: {task_id}")
            if args.wait:
                log(f"最终状态: {result.get('status')}")
                if result.get('outputs'):
                    log("生成结果:")
                    for i, output in enumerate(result['outputs'], 1):
                        log(f"  [{i}] {output.get('fileUrl', 'N/A')}")
        log("=" * 60)
        
    except KeyboardInterrupt:
        log("\n✗ 用户中断", error=True)
        sys.exit(130)
    except Exception as e:
        log(f"\n✗ 未预期的异常: {type(e).__name__}: {e}", error=True)
        import traceback
        log(f"\n异常堆栈:\n{traceback.format_exc()}", error=True)
        sys.exit(1)
    
    # 输出结果
    if args.output_json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"\n任务ID: {task_id}")
        if args.wait:
            print(f"状态: {result.get('status')}")
            if result.get('outputs'):
                print("输出:")
                for i, output in enumerate(result['outputs'], 1):
                    print(f"  [{i}] {output.get('fileUrl', 'N/A')}")


if __name__ == "__main__":
    main()
