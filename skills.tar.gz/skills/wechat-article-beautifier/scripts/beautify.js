#!/usr/bin/env node
/**
 * 公众号文章美化脚本
 * 将 Markdown 转换为可直接粘贴到微信公众号的 HTML
 * 支持首字下沉、装饰分隔线、荧光笔强调等效果
 * 
 * 用法：
 *   node beautify.js input.md [--theme default|elegant|tech|vibrant] [--output output.html]
 */

const fs = require('fs');
const path = require('path');

// ============ 主题配置（内联样式）============
// 主题来源：mdnice.com 开源主题 + 自定义优化
const themeConfigs = {
  // 小梅专属主题 - 文艺简约风，适合情感类文章
  // 纯白底，棕色主题色，微信兼容性好
  xiaomei: {
    // 首字下沉
    firstLetter: 'font-size:40px;float:left;line-height:1;margin-right:8px;margin-top:5px;color:#a08060;',
    // 正文段落
    paragraph: 'font-size:17px;color:#3d3d3d;line-height:2;margin-bottom:16px;text-indent:2em;',
    firstParagraph: 'font-size:17px;color:#3d3d3d;line-height:2;margin-bottom:16px;text-indent:2em;',
    // 内心独白/次要段落（灰色）
    secondaryParagraph: 'font-size:16px;color:#888;line-height:2;margin-bottom:16px;text-indent:2em;',
    // 图片
    image: 'max-width:100%;height:auto;border-radius:6px;display:block;margin:20px auto;',
    // 分隔线
    hrStyle: 'text-align:center;margin:25px 0;border:none;color:#ccc;letter-spacing:8px;',
    hrContent: '◇',
    // 强调文字（对话内容）
    strong: 'color:#a08060;font-weight:normal;',
    em: 'font-style:italic;color:#888;',
    // 引用框（金句）
    blockquote: 'font-size:16px;color:#888;line-height:2;margin-bottom:16px;text-indent:0;border-left:2px solid #ddd;padding-left:15px;',
    blockquoteIcon: '',
    blockquoteIconStyle: '',
    imageDecor: '',
    imageDecorStyle: '',
    // 标题
    h1: 'text-align:center;color:#a09080;font-size:14px;letter-spacing:3px;margin-bottom:25px;font-weight:normal;',
    h2: 'font-size:17px;color:#a08060;line-height:2;margin-bottom:16px;text-indent:2em;font-weight:normal;',
    h3: 'font-size:17px;color:#3d3d3d;line-height:2;margin-bottom:16px;font-weight:500;',
    link: 'color:#a08060;text-decoration:none;',
    ul: 'padding-left:1.5em;margin:16px 0;',
    li: 'font-size:17px;line-height:2;color:#3d3d3d;margin:8px 0;',
    code: 'background:#f5f5f5;padding:2px 6px;border-radius:3px;color:#a08060;font-size:15px;',
    pre: 'background:#2b2b2b;color:#f8f8f2;padding:1em;border-radius:4px;font-size:13px;line-height:1.6;margin:16px 0;overflow-x:auto;',
    // 结尾
    ending: 'text-align:right;margin-top:30px;color:#a08060;font-size:17px;',
    endText: '— END —',
    endStyle: 'text-align:center;margin-top:40px;color:#ccc;font-size:13px;',
    // 容器
    containerPadding: '30px 20px'
  },

  // 橙心主题 - 来自 mdnice，温暖橙色调
  orangeheart: {
    firstLetter: '',
    paragraph: 'font-size: 16px; color: #000; line-height: 1.8em; margin: 0; padding: 8px 0; text-align: left; font-family: Optima, "Microsoft YaHei", "PingFang SC", serif;',
    firstParagraph: 'font-size: 16px; color: #000; line-height: 1.8em; margin: 0; padding: 8px 0; text-align: left; font-family: Optima, "Microsoft YaHei", "PingFang SC", serif;',
    image: 'max-width: 100%; display: block; margin: 10px auto; border-radius: 4px;',
    hrStyle: 'border: none; border-top: 1px solid #ef7060; margin: 20px 0;',
    hrContent: '',
    strong: 'font-weight: bold; color: #ef7060;',
    em: 'font-style: italic; color: #000;',
    blockquote: 'border-left: 3px solid #ef7060; background: #fff9f7; padding: 10px 15px; margin: 15px 0; color: #666; font-size: 15px;',
    blockquoteIcon: '',
    blockquoteIconStyle: '',
    imageDecor: '',
    imageDecorStyle: '',
    h1: 'font-size: 24px; font-weight: bold; color: #000; text-align: left; margin: 30px 0 15px; line-height: 1.5em;',
    h2: 'font-size: 22px; font-weight: bold; color: #fff; background: #ef7060; display: inline-block; padding: 2px 12px; margin: 30px 0 15px; border-bottom: 2px solid #ef7060;',
    h3: 'font-size: 18px; font-weight: bold; color: #ef7060; margin: 25px 0 12px;',
    link: 'color: #ef7060; text-decoration: none; border-bottom: 1px solid #ef7060;',
    ul: 'padding-left: 25px; margin: 12px 0;',
    li: 'font-size: 16px; line-height: 1.8em; color: #000; margin: 5px 0;',
    code: 'font-family: Consolas, Monaco, monospace; background: #fff5f5; padding: 2px 6px; border-radius: 3px; color: #ef7060; font-size: 14px;',
    pre: 'background: #282c34; color: #abb2bf; padding: 15px; border-radius: 5px; overflow-x: auto; font-size: 13px; line-height: 1.6; margin: 15px 0;'
  },
  
  // 姹紫主题 - 来自 mdnice，优雅紫色调
  purple: {
    firstLetter: '',
    paragraph: 'font-size: 16px; color: #333; line-height: 1.8em; margin: 0; padding: 8px 0; text-align: left; font-family: Optima, "Microsoft YaHei", "PingFang SC", serif;',
    firstParagraph: 'font-size: 16px; color: #333; line-height: 1.8em; margin: 0; padding: 8px 0; text-align: left; font-family: Optima, "Microsoft YaHei", "PingFang SC", serif;',
    image: 'max-width: 100%; display: block; margin: 10px auto; border-radius: 4px;',
    hrStyle: 'border: none; border-top: 1px solid #9c27b0; margin: 20px 0;',
    hrContent: '',
    strong: 'font-weight: bold; color: #9c27b0;',
    em: 'font-style: italic; color: #333;',
    blockquote: 'border-left: 3px solid #9c27b0; background: #faf5fc; padding: 10px 15px; margin: 15px 0; color: #666; font-size: 15px;',
    blockquoteIcon: '',
    blockquoteIconStyle: '',
    imageDecor: '',
    imageDecorStyle: '',
    h1: 'font-size: 24px; font-weight: bold; color: #333; text-align: center; margin: 30px 0 15px; line-height: 1.5em;',
    h2: 'font-size: 20px; font-weight: bold; color: #9c27b0; margin: 30px 0 15px; padding-bottom: 8px; border-bottom: 2px solid #9c27b0;',
    h3: 'font-size: 18px; font-weight: bold; color: #9c27b0; margin: 25px 0 12px;',
    link: 'color: #9c27b0; text-decoration: none; border-bottom: 1px solid #9c27b0;',
    ul: 'padding-left: 25px; margin: 12px 0;',
    li: 'font-size: 16px; line-height: 1.8em; color: #333; margin: 5px 0;',
    code: 'font-family: Consolas, Monaco, monospace; background: #faf5fc; padding: 2px 6px; border-radius: 3px; color: #9c27b0; font-size: 14px;',
    pre: 'background: #282c34; color: #abb2bf; padding: 15px; border-radius: 5px; overflow-x: auto; font-size: 13px; line-height: 1.6; margin: 15px 0;'
  },
  
  // 绿意主题 - 来自 mdnice，清新绿色调
  green: {
    firstLetter: '',
    paragraph: 'font-size: 16px; color: #333; line-height: 1.8em; margin: 0; padding: 8px 0; text-align: left; font-family: Optima, "Microsoft YaHei", "PingFang SC", serif;',
    firstParagraph: 'font-size: 16px; color: #333; line-height: 1.8em; margin: 0; padding: 8px 0; text-align: left; font-family: Optima, "Microsoft YaHei", "PingFang SC", serif;',
    image: 'max-width: 100%; display: block; margin: 10px auto; border-radius: 4px;',
    hrStyle: 'border: none; border-top: 1px solid #2e7d32; margin: 20px 0;',
    hrContent: '',
    strong: 'font-weight: bold; color: #2e7d32;',
    em: 'font-style: italic; color: #333;',
    blockquote: 'border-left: 3px solid #2e7d32; background: #f1f8e9; padding: 10px 15px; margin: 15px 0; color: #666; font-size: 15px;',
    blockquoteIcon: '',
    blockquoteIconStyle: '',
    imageDecor: '',
    imageDecorStyle: '',
    h1: 'font-size: 24px; font-weight: bold; color: #333; text-align: center; margin: 30px 0 15px; line-height: 1.5em;',
    h2: 'font-size: 20px; font-weight: bold; color: #2e7d32; margin: 30px 0 15px; padding-bottom: 8px; border-bottom: 2px solid #2e7d32;',
    h3: 'font-size: 18px; font-weight: bold; color: #2e7d32; margin: 25px 0 12px;',
    link: 'color: #2e7d32; text-decoration: none; border-bottom: 1px solid #2e7d32;',
    ul: 'padding-left: 25px; margin: 12px 0;',
    li: 'font-size: 16px; line-height: 1.8em; color: #333; margin: 5px 0;',
    code: 'font-family: Consolas, Monaco, monospace; background: #f1f8e9; padding: 2px 6px; border-radius: 3px; color: #2e7d32; font-size: 14px;',
    pre: 'background: #282c34; color: #abb2bf; padding: 15px; border-radius: 5px; overflow-x: auto; font-size: 13px; line-height: 1.6; margin: 15px 0;'
  },
  
  // 蓝莹主题 - 来自 mdnice，清爽蓝色调
  blue: {
    firstLetter: '',
    paragraph: 'font-size: 16px; color: #333; line-height: 1.8em; margin: 0; padding: 8px 0; text-align: left; font-family: Optima, "Microsoft YaHei", "PingFang SC", serif;',
    firstParagraph: 'font-size: 16px; color: #333; line-height: 1.8em; margin: 0; padding: 8px 0; text-align: left; font-family: Optima, "Microsoft YaHei", "PingFang SC", serif;',
    image: 'max-width: 100%; display: block; margin: 10px auto; border-radius: 4px;',
    hrStyle: 'border: none; border-top: 1px solid #1976d2; margin: 20px 0;',
    hrContent: '',
    strong: 'font-weight: bold; color: #1976d2;',
    em: 'font-style: italic; color: #333;',
    blockquote: 'border-left: 3px solid #1976d2; background: #e3f2fd; padding: 10px 15px; margin: 15px 0; color: #666; font-size: 15px;',
    blockquoteIcon: '',
    blockquoteIconStyle: '',
    imageDecor: '',
    imageDecorStyle: '',
    h1: 'font-size: 24px; font-weight: bold; color: #333; text-align: center; margin: 30px 0 15px; line-height: 1.5em;',
    h2: 'font-size: 20px; font-weight: bold; color: #1976d2; margin: 30px 0 15px; padding-bottom: 8px; border-bottom: 2px solid #1976d2;',
    h3: 'font-size: 18px; font-weight: bold; color: #1976d2; margin: 25px 0 12px;',
    link: 'color: #1976d2; text-decoration: none; border-bottom: 1px solid #1976d2;',
    ul: 'padding-left: 25px; margin: 12px 0;',
    li: 'font-size: 16px; line-height: 1.8em; color: #333; margin: 5px 0;',
    code: 'font-family: Consolas, Monaco, monospace; background: #e3f2fd; padding: 2px 6px; border-radius: 3px; color: #1976d2; font-size: 14px;',
    pre: 'background: #282c34; color: #abb2bf; padding: 15px; border-radius: 5px; overflow-x: auto; font-size: 13px; line-height: 1.6; margin: 15px 0;'
  },
  
  // 文艺风格 - 首字下沉、荧光笔强调、装饰分隔线
  elegant: {
    firstLetter: 'float: left; font-size: 2.8em; line-height: 1; font-weight: bold; color: #e74c3c; margin-right: 10px; margin-top: 5px; font-family: Georgia, serif;',
    paragraph: 'font-size: 16px; color: #3a3a3a; line-height: 2; margin: 0; text-align: justify; letter-spacing: 0.5px; text-indent: 2em;',
    firstParagraph: 'font-size: 16px; color: #3a3a3a; line-height: 2; margin: 0; text-align: justify; letter-spacing: 0.5px;',
    image: 'max-width: 100%; border-radius: 12px; margin: 10px auto; box-shadow: 0 8px 25px rgba(0,0,0,0.12); display: block;',
    hrStyle: 'text-align: center; margin: 25px 0; color: #ccc; font-size: 14px; letter-spacing: 10px;',
    hrContent: '◆ ◇ ◆',
    strong: 'color: #e74c3c; font-weight: 600; background: linear-gradient(to top, #ffeaa7 30%, transparent 30%); padding: 0 3px;',
    em: 'font-style: normal; color: #e74c3c; border-bottom: 2px solid #ffeaa7; padding-bottom: 1px;',
    blockquote: 'background: linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%); border: none; border-radius: 12px; padding: 18px 22px; margin: 20px 0; color: #5d4e37; font-size: 15px;',
    blockquoteIcon: '❝',
    blockquoteIconStyle: 'font-size: 28px; color: rgba(0,0,0,0.15); margin-right: 8px; vertical-align: top; line-height: 1;',
    imageDecor: '· · ·',
    imageDecorStyle: 'text-align: center; color: #ddd; font-size: 14px; letter-spacing: 8px; margin: 8px 0 4px 0;',
    h1: 'font-size: 24px; font-weight: 500; color: #2c3e50; text-align: center; margin: 30px 0 25px; letter-spacing: 2px;',
    h2: 'font-size: 18px; font-weight: 500; color: #34495e; margin: 28px 0 15px; padding-left: 12px; border-left: 4px solid #e74c3c;',
    h3: 'font-size: 16px; font-weight: 500; color: #2c3e50; margin: 22px 0 12px;',
    link: 'color: #e74c3c; text-decoration: none; border-bottom: 1px dashed #e74c3c;',
    ul: 'padding-left: 22px; margin: 15px 0;',
    li: 'font-size: 15px; line-height: 2; color: #3a3a3a; margin: 0;',
    code: 'font-family: Consolas, monospace; background: #ffeaa7; padding: 2px 8px; border-radius: 4px; color: #d63031; font-size: 14px;',
    pre: 'background: #2d3436; color: #dfe6e9; padding: 18px; border-radius: 8px; font-size: 13px; line-height: 1.6; margin: 20px 0; overflow-x: auto;'
  },
  
  // 简约风格 - 干净清爽
  default: {
    firstLetter: '',
    paragraph: 'font-size: 16px; color: #333; line-height: 2; margin: 0; text-align: justify;',
    firstParagraph: 'font-size: 16px; color: #333; line-height: 2; margin: 0; text-align: justify;',
    image: 'max-width: 100%; height: auto; display: block; margin: 12px auto; border-radius: 5px;',
    hrStyle: 'border: none; border-top: 1px dashed #ddd; margin: 15px 0;',
    hrContent: '',
    strong: 'font-weight: bold; color: #333;',
    em: 'font-style: italic; color: #555;',
    blockquote: 'border-left: 3px solid #07c160; background: #f9f9f9; padding: 10px 15px; margin: 15px 0; color: #666; font-size: 14px;',
    blockquoteIcon: '',
    blockquoteIconStyle: '',
    imageDecor: '',
    imageDecorStyle: '',
    h1: 'font-size: 22px; font-weight: bold; color: #333; text-align: center; margin: 20px 0 15px; line-height: 1.4;',
    h2: 'font-size: 18px; font-weight: bold; color: #333; border-bottom: 1px solid #eee; padding-bottom: 8px; margin: 20px 0 12px;',
    h3: 'font-size: 16px; font-weight: bold; color: #333; margin: 18px 0 10px;',
    link: 'color: #07c160; text-decoration: none;',
    ul: 'padding-left: 25px; margin: 12px 0;',
    li: 'font-size: 16px; line-height: 2; color: #333; margin: 0;',
    code: 'font-family: Consolas, Monaco, monospace; background: #f0f0f0; padding: 2px 6px; border-radius: 3px; color: #c7254e; font-size: 14px;',
    pre: 'background: #282c34; color: #abb2bf; padding: 15px; border-radius: 5px; overflow-x: auto; font-size: 13px; line-height: 1.6; margin: 15px 0;'
  }
};

function escapeHtml(text) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// ============ Markdown 解析器（带美化效果）============
function parseMarkdown(markdown, themeName = 'elegant') {
  const theme = themeConfigs[themeName] || themeConfigs.elegant;
  let html = markdown;
  
  // 代码块（必须先处理）
  html = html.replace(/```(\w*)\n([\s\S]*?)```/g, (match, lang, code) => {
    const escaped = escapeHtml(code.trim());
    return `<pre style="${theme.pre}"><code style="font-family: Consolas, Monaco, monospace;">${escaped}</code></pre>`;
  });
  
  // 行内代码
  html = html.replace(/`([^`]+)`/g, `<code style="${theme.code}">$1</code>`);
  
  // 标题
  html = html.replace(/^######\s+(.+)$/gm, `<h6 style="font-size: 14px; font-weight: 500; color: #2c3e50; margin: 15px 0 10px;">$1</h6>`);
  html = html.replace(/^#####\s+(.+)$/gm, `<h5 style="font-size: 15px; font-weight: 500; color: #2c3e50; margin: 18px 0 10px;">$1</h5>`);
  html = html.replace(/^####\s+(.+)$/gm, `<h4 style="font-size: 16px; font-weight: 500; color: #2c3e50; margin: 20px 0 12px;">$1</h4>`);
  html = html.replace(/^###\s+(.+)$/gm, `<h3 style="${theme.h3}">$1</h3>`);
  html = html.replace(/^##\s+(.+)$/gm, `<h2 style="${theme.h2}">$1</h2>`);
  html = html.replace(/^#\s+(.+)$/gm, `<h1 style="${theme.h1}">$1</h1>`);
  
  // 引用块
  if (theme.blockquoteIcon) {
    html = html.replace(/^>\s+(.+)$/gm, `<blockquote style="${theme.blockquote}"><span style="${theme.blockquoteIconStyle}">${theme.blockquoteIcon}</span>$1</blockquote>`);
  } else {
    html = html.replace(/^>\s+(.+)$/gm, `<blockquote style="${theme.blockquote}">$1</blockquote>`);
  }
  
  // 粗体和斜体
  html = html.replace(/\*\*\*(.+?)\*\*\*/g, `<strong style="${theme.strong}"><em style="${theme.em}">$1</em></strong>`);
  html = html.replace(/\*\*(.+?)\*\*/g, `<strong style="${theme.strong}">$1</strong>`);
  html = html.replace(/\*(.+?)\*/g, `<em style="${theme.em}">$1</em>`);
  
  // 图片（加装饰）
  if (theme.imageDecor) {
    html = html.replace(/!\[([^\]]*)\]\(([^)]+)\)/g, `<p style="${theme.imageDecorStyle}">${theme.imageDecor}</p><img style="${theme.image}" src="$2" alt="$1">`);
  } else {
    html = html.replace(/!\[([^\]]*)\]\(([^)]+)\)/g, `<img style="${theme.image}" src="$2" alt="$1">`);
  }
  
  // 链接
  html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, `<a style="${theme.link}" href="$2">$1</a>`);
  
  // 无序列表
  html = html.replace(/^[\*\-]\s+(.+)$/gm, `<li style="${theme.li}">$1</li>`);
  html = html.replace(/(<li[^>]*>.*<\/li>\n?)+/g, `<ul style="${theme.ul}">$&</ul>`);
  
  // 有序列表
  html = html.replace(/^\d+\.\s+(.+)$/gm, `<li style="${theme.li}">$1</li>`);
  
  // 分割线
  if (theme.hrContent) {
    html = html.replace(/^---+$/gm, `<p style="${theme.hrStyle}">${theme.hrContent}</p>`);
  } else {
    html = html.replace(/^---+$/gm, `<hr style="${theme.hrStyle}">`);
  }
  
  // 段落处理（带首字下沉）
  const lines = html.split('\n');
  const processedLines = [];
  let paragraphCount = 0;
  
  for (let line of lines) {
    const trimmed = line.trim();
    
    // 跳过空行和已处理的标签
    if (trimmed === '' || trimmed.startsWith('<')) {
      processedLines.push(line);
      continue;
    }
    
    // 处理普通文本为段落
    paragraphCount++;
    if (paragraphCount === 1 && theme.firstLetter) {
      // 首段首字下沉
      const firstChar = trimmed.charAt(0);
      const restText = trimmed.slice(1);
      line = `<p style="${theme.firstParagraph}"><span style="${theme.firstLetter}">${firstChar}</span>${restText}</p>`;
    } else {
      line = `<p style="${theme.paragraph}">${trimmed}</p>`;
    }
    processedLines.push(line);
  }
  
  html = processedLines.join('\n');
  
  // 清理多余的空行
  html = html.replace(/\n{3,}/g, '\n\n');
  
  return html;
}

// ============ 生成 HTML 文件 ============
function generateHtmlFile(content, title = '公众号文章预览') {
  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { background: #f5f5f5; padding: 20px; }
    .copy-btn {
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 12px 24px;
      background: #07c160;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-size: 14px;
      font-weight: bold;
      box-shadow: 0 2px 10px rgba(7, 193, 96, 0.3);
      z-index: 1000;
    }
    .copy-btn:hover { background: #06ad56; }
    .copy-btn:active { transform: scale(0.98); }
    .preview-container {
      max-width: 750px;
      margin: 0 auto;
      background: white;
      box-shadow: 0 2px 20px rgba(0,0,0,0.1);
      border-radius: 10px;
      overflow: hidden;
    }
    .preview-header {
      background: #f8f8f8;
      padding: 15px 20px;
      border-bottom: 1px solid #eee;
      font-size: 14px;
      color: #666;
    }
  </style>
</head>
<body>
  <button class="copy-btn" onclick="copyArticle()">📋 复制到公众号</button>
  
  <div class="preview-container">
    <div class="preview-header">
      📱 公众号文章预览 - 点击右上角按钮复制
    </div>
    <div id="article" style="max-width: 677px; margin: 0 auto; padding: 20px; font-family: -apple-system, BlinkMacSystemFont, 'PingFang SC', 'Microsoft YaHei', sans-serif; background: #fff;">
      ${content}
    </div>
  </div>

  <script>
    async function copyArticle() {
      const article = document.getElementById('article');
      try {
        const blob = new Blob([article.innerHTML], { type: 'text/html' });
        await navigator.clipboard.write([
          new ClipboardItem({ 'text/html': blob })
        ]);
        alert('✅ 复制成功！\\n\\n请到微信公众号后台，直接粘贴即可。');
      } catch (err) {
        const range = document.createRange();
        range.selectNode(article);
        window.getSelection().removeAllRanges();
        window.getSelection().addRange(range);
        document.execCommand('copy');
        window.getSelection().removeAllRanges();
        alert('✅ 复制成功！\\n\\n请到微信公众号后台，直接粘贴即可。');
      }
    }
  </script>
</body>
</html>`;
}

// ============ 主函数 ============
function main() {
  const args = process.argv.slice(2);
  
  if (args.length === 0 || args.includes('--help')) {
    console.log(`
公众号文章美化工具

用法：
  node beautify.js <input.md> [选项]

选项：
  --theme <name>    主题名称
  --output <file>   输出文件路径
  --help            显示帮助信息

可用主题（来自 mdnice.com）：
  orangeheart - 橙心，温暖橙色调，二级标题有橙色背景
  purple      - 姹紫，优雅紫色调
  green       - 绿意，清新绿色调
  blue        - 蓝莹，清爽蓝色调
  elegant     - 文艺风格，首字下沉、荧光笔强调、装饰分隔线
  default     - 简约风格，干净清爽

示例：
  node beautify.js article.md
  node beautify.js article.md --theme orangeheart
  node beautify.js article.md --theme purple --output preview.html
    `);
    return;
  }
  
  const inputFile = args[0];
  let theme = 'xiaomei';  // 默认使用小梅主题
  let outputFile = null;
  
  // 解析参数
  for (let i = 1; i < args.length; i++) {
    if (args[i] === '--theme' && args[i + 1]) {
      theme = args[i + 1];
      i++;
    } else if (args[i] === '--output' && args[i + 1]) {
      outputFile = args[i + 1];
      i++;
    }
  }
  
  // 检查主题
  if (!themeConfigs[theme]) {
    console.error(`错误：未知主题 "${theme}"，可用主题：${Object.keys(themeConfigs).join(', ')}`);
    process.exit(1);
  }
  
  // 读取输入文件
  if (!fs.existsSync(inputFile)) {
    console.error(`错误：文件不存在 "${inputFile}"`);
    process.exit(1);
  }
  
  const markdown = fs.readFileSync(inputFile, 'utf-8');
  
  // 转换
  console.log(`📝 正在处理：${inputFile}`);
  console.log(`🎨 使用主题：${theme}`);
  
  const styledHtml = parseMarkdown(markdown, theme);
  const finalHtml = generateHtmlFile(styledHtml);
  
  // 输出
  if (!outputFile) {
    outputFile = inputFile.replace(/\.md$/, '') + '_wechat.html';
  }
  
  fs.writeFileSync(outputFile, finalHtml, 'utf-8');
  console.log(`✅ 生成成功：${outputFile}`);
  console.log(`\n💡 提示：在浏览器中打开该文件，点击"复制到公众号"按钮即可。`);
}

if (require.main === module) {
  main();
}

module.exports = { parseMarkdown, generateHtmlFile, themeConfigs };
