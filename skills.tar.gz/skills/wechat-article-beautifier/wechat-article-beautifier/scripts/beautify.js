#!/usr/bin/env node
/**
 * 公众号文章美化脚本
 * 将 Markdown 转换为可直接粘贴到微信公众号的 HTML
 * 
 * 用法：
 *   node beautify.js input.md [--theme default|elegant|tech|vibrant] [--output output.html]
 */

const fs = require('fs');
const path = require('path');

// ============ Markdown 解析器（简化版）============
function parseMarkdown(markdown) {
  let html = markdown;
  
  // 代码块（必须先处理）
  html = html.replace(/```(\w*)\n([\s\S]*?)```/g, (match, lang, code) => {
    const escaped = escapeHtml(code.trim());
    return `<pre class="code-block" data-lang="${lang}"><code>${escaped}</code></pre>`;
  });
  
  // 行内代码
  html = html.replace(/`([^`]+)`/g, '<code class="inline-code">$1</code>');
  
  // 标题
  html = html.replace(/^######\s+(.+)$/gm, '<h6>$1</h6>');
  html = html.replace(/^#####\s+(.+)$/gm, '<h5>$1</h5>');
  html = html.replace(/^####\s+(.+)$/gm, '<h4>$1</h4>');
  html = html.replace(/^###\s+(.+)$/gm, '<h3>$1</h3>');
  html = html.replace(/^##\s+(.+)$/gm, '<h2>$1</h2>');
  html = html.replace(/^#\s+(.+)$/gm, '<h1>$1</h1>');
  
  // 引用块
  html = html.replace(/^>\s+(.+)$/gm, '<blockquote><p>$1</p></blockquote>');
  
  // 粗体和斜体
  html = html.replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>');
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');
  
  // 图片（必须在链接之前处理）
  html = html.replace(/!\[([^\]]*)\]\(([^)]+)\)/g, '<img src="$2" alt="$1">');
  
  // 链接
  html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2">$1</a>');
  
  // 无序列表
  html = html.replace(/^[\*\-]\s+(.+)$/gm, '<li>$1</li>');
  html = html.replace(/(<li>.*<\/li>\n?)+/g, '<ul>$&</ul>');
  
  // 有序列表
  html = html.replace(/^\d+\.\s+(.+)$/gm, '<li>$1</li>');
  
  // 分割线
  html = html.replace(/^---+$/gm, '<hr>');
  
  // 表格处理
  html = html.replace(/^\|(.+)\|$/gm, (match, content) => {
    const cells = content.split('|').map(c => c.trim());
    // 检查是否是分隔行
    if (cells.every(c => /^[-:]+$/.test(c))) {
      return '<!-- table separator -->';
    }
    return `<tr>${cells.map(c => `<td>${c}</td>`).join('')}</tr>`;
  });
  // 包装表格行
  html = html.replace(/((?:<tr>.*<\/tr>\n?)+)/g, (match) => {
    const cleaned = match.replace(/<!-- table separator -->\n?/g, '');
    if (cleaned.trim()) {
      // 将第一行转为表头
      const rows = cleaned.trim().split('\n');
      if (rows.length > 0) {
        const headerRow = rows[0].replace(/<td>/g, '<th>').replace(/<\/td>/g, '</th>');
        const bodyRows = rows.slice(1).join('\n');
        return `<table>${headerRow}${bodyRows}</table>`;
      }
    }
    return match;
  });
  
  // 段落（处理剩余的文本行）
  html = html.replace(/^(?!<[a-z]|$)(.+)$/gm, '<p>$1</p>');
  
  // 清理多余的空行
  html = html.replace(/\n{3,}/g, '\n\n');
  
  return html;
}

function escapeHtml(text) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// ============ 主题样式 ============
const themes = {
  default: `
    .article-container { max-width: 677px; margin: 0 auto; padding: 20px; font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", sans-serif; background: #fff; }
    h1 { font-size: 22px; font-weight: bold; color: #333; text-align: center; margin: 25px 0 20px; line-height: 1.4; }
    h2 { font-size: 18px; font-weight: bold; color: #333; border-bottom: 1px solid #eee; padding-bottom: 10px; margin: 25px 0 15px; }
    h3 { font-size: 16px; font-weight: bold; color: #333; margin: 20px 0 12px; }
    p { font-size: 15px; color: #333; line-height: 1.8; margin: 15px 0; text-align: justify; }
    blockquote { border-left: 3px solid #07c160; background: #f9f9f9; padding: 12px 15px; margin: 20px 0; color: #666; font-size: 14px; }
    blockquote p { margin: 0; font-size: 14px; }
    pre { background: #282c34; color: #abb2bf; padding: 15px; border-radius: 5px; overflow-x: auto; font-size: 13px; line-height: 1.6; margin: 20px 0; }
    pre code { font-family: Consolas, Monaco, monospace; background: none; padding: 0; color: inherit; }
    .inline-code { font-family: Consolas, Monaco, monospace; background: #f0f0f0; padding: 2px 6px; border-radius: 3px; color: #c7254e; font-size: 14px; }
    ul, ol { padding-left: 25px; margin: 15px 0; }
    li { font-size: 15px; line-height: 1.8; color: #333; margin: 8px 0; }
    img { max-width: 100%; height: auto; display: block; margin: 20px auto; border-radius: 5px; }
    a { color: #07c160; text-decoration: none; }
    hr { border: none; border-top: 1px dashed #ddd; margin: 25px 0; }
    strong { font-weight: bold; color: #333; }
    em { font-style: italic; color: #555; }
    table { width: 100%; border-collapse: collapse; margin: 20px 0; font-size: 14px; }
    th { background: #f5f5f5; font-weight: bold; padding: 10px 12px; border: 1px solid #ddd; text-align: left; }
    td { padding: 10px 12px; border: 1px solid #ddd; }
  `,
  
  elegant: `
    .article-container { max-width: 677px; margin: 0 auto; padding: 20px; font-family: "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif; background: #fff; }
    h1 { font-size: 24px; font-weight: 500; color: #2c3e50; text-align: center; margin: 30px 0 25px; letter-spacing: 2px; }
    h2 { font-size: 18px; font-weight: 500; color: #34495e; margin: 28px 0 15px; padding-left: 12px; border-left: 4px solid #e74c3c; }
    h3 { font-size: 16px; font-weight: 500; color: #2c3e50; margin: 22px 0 12px; }
    p { font-size: 15px; color: #444; line-height: 2; margin: 18px 0; text-align: justify; letter-spacing: 0.5px; }
    blockquote { background: linear-gradient(to right, #ffecd2, #fcb69f); border: none; border-radius: 8px; padding: 15px 20px; margin: 22px 0; color: #5d4e37; font-size: 14px; font-style: italic; }
    pre { background: #2d3436; color: #dfe6e9; padding: 18px; border-radius: 8px; font-size: 13px; line-height: 1.6; margin: 22px 0; }
    .inline-code { font-family: Consolas, monospace; background: #ffeaa7; padding: 2px 8px; border-radius: 4px; color: #d63031; font-size: 14px; }
    ul, ol { padding-left: 22px; margin: 18px 0; }
    li { font-size: 15px; line-height: 2; color: #444; margin: 10px 0; }
    img { max-width: 100%; border-radius: 10px; margin: 25px auto; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
    a { color: #e74c3c; text-decoration: none; border-bottom: 1px dashed #e74c3c; }
    hr { border: none; height: 1px; background: linear-gradient(to right, transparent, #bdc3c7, transparent); margin: 30px 0; }
    strong { color: #e74c3c; font-weight: 600; }
    table { width: 100%; border-collapse: collapse; margin: 22px 0; font-size: 14px; border-radius: 8px; overflow: hidden; }
    th { background: #e74c3c; color: white; font-weight: 500; padding: 12px 15px; text-align: left; }
    td { padding: 12px 15px; border-bottom: 1px solid #eee; }
    tr:nth-child(even) { background: #fafafa; }
  `,
  
  tech: `
    .article-container { max-width: 677px; margin: 0 auto; padding: 20px; font-family: -apple-system, "SF Pro Text", "Helvetica Neue", Arial, sans-serif; }
    h1 { font-size: 24px; font-weight: 700; color: #667eea; text-align: center; margin: 25px 0; }
    h2 { font-size: 18px; font-weight: 600; color: #16213e; margin: 25px 0 15px; padding: 8px 15px; background: #f8f9fa; border-left: 4px solid #667eea; border-radius: 0 5px 5px 0; }
    h3 { font-size: 16px; font-weight: 600; color: #1a1a2e; margin: 20px 0 12px; }
    p { font-size: 15px; color: #333; line-height: 1.8; margin: 15px 0; }
    blockquote { background: #e8f4f8; border-left: 4px solid #0984e3; padding: 12px 18px; margin: 20px 0; color: #2d3436; font-size: 14px; border-radius: 0 8px 8px 0; }
    pre { background: #1e1e1e; color: #d4d4d4; padding: 18px; border-radius: 8px; font-size: 13px; line-height: 1.6; margin: 20px 0; border: 1px solid #333; }
    .inline-code { font-family: "JetBrains Mono", Consolas, monospace; background: #e3f2fd; padding: 3px 8px; border-radius: 4px; color: #1565c0; font-size: 14px; }
    ul, ol { padding-left: 25px; margin: 15px 0; }
    li { font-size: 15px; line-height: 1.8; color: #333; margin: 8px 0; }
    img { max-width: 100%; border-radius: 8px; margin: 20px auto; border: 1px solid #eee; }
    a { color: #667eea; text-decoration: none; font-weight: 500; }
    hr { border: none; height: 2px; background: linear-gradient(to right, #667eea, #764ba2); margin: 30px 0; border-radius: 1px; }
    strong { color: #667eea; font-weight: 600; }
  `,
  
  vibrant: `
    .article-container { max-width: 677px; margin: 0 auto; padding: 20px; font-family: "PingFang SC", "Microsoft YaHei", sans-serif; }
    h1 { font-size: 24px; font-weight: bold; color: #fff; text-align: center; margin: 25px 0; padding: 15px 20px; background: linear-gradient(135deg, #ff6b6b, #feca57); border-radius: 10px; }
    h2 { font-size: 18px; font-weight: bold; color: #ff6b6b; margin: 25px 0 15px; padding-bottom: 8px; border-bottom: 2px dashed #feca57; }
    h3 { font-size: 16px; font-weight: bold; color: #5f27cd; margin: 20px 0 12px; }
    p { font-size: 15px; color: #333; line-height: 1.9; margin: 15px 0; }
    blockquote { background: #fff3cd; border: 2px solid #feca57; border-radius: 10px; padding: 15px 18px; margin: 20px 0; color: #856404; font-size: 14px; }
    pre { background: #2d3436; color: #74b9ff; padding: 18px; border-radius: 10px; font-size: 13px; line-height: 1.6; margin: 20px 0; border: 2px solid #0984e3; }
    .inline-code { font-family: Consolas, monospace; background: #dfe6e9; padding: 3px 8px; border-radius: 5px; color: #d63031; font-size: 14px; }
    ul, ol { padding-left: 25px; margin: 15px 0; }
    li { font-size: 15px; line-height: 1.9; color: #333; margin: 10px 0; }
    img { max-width: 100%; border-radius: 12px; margin: 20px auto; box-shadow: 0 5px 20px rgba(255, 107, 107, 0.3); }
    a { color: #ff6b6b; text-decoration: none; font-weight: bold; }
    hr { border: none; height: 3px; background: linear-gradient(to right, #ff6b6b, #feca57, #48dbfb, #ff6b6b); margin: 30px 0; border-radius: 2px; }
    strong { color: #ff6b6b; font-weight: bold; }
  `
};

// ============ CSS 内联化 ============
function inlineStyles(html, css) {
  // 解析 CSS 规则
  const rules = {};
  const ruleRegex = /([^{]+)\{([^}]+)\}/g;
  let match;
  
  while ((match = ruleRegex.exec(css)) !== null) {
    const selector = match[1].trim();
    const styles = match[2].trim();
    rules[selector] = styles;
  }
  
  // 应用样式到 HTML
  let result = html;
  
  // 处理类选择器
  for (const [selector, styles] of Object.entries(rules)) {
    if (selector.startsWith('.')) {
      const className = selector.slice(1);
      const regex = new RegExp(`class="${className}"`, 'g');
      result = result.replace(regex, `style="${styles.replace(/\n/g, ' ').replace(/\s+/g, ' ')}"`);
    } else {
      // 处理标签选择器
      const tagRegex = new RegExp(`<${selector}(?![\\w-])([^>]*)>`, 'gi');
      result = result.replace(tagRegex, (match, attrs) => {
        if (attrs.includes('style=')) {
          // 合并样式
          return match.replace(/style="([^"]*)"/, `style="$1 ${styles.replace(/\n/g, ' ').replace(/\s+/g, ' ')}"`);
        }
        return `<${selector} style="${styles.replace(/\n/g, ' ').replace(/\s+/g, ' ')}"${attrs}>`;
      });
    }
  }
  
  return result;
}

// ============ 生成 HTML 文件 ============
function generateHtmlFile(content, title = '公众号文章预览') {
  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { background: #f5f5f5; padding: 20px; }
    .copy-btn {
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 12px 24px;
      background: #07c160;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-size: 14px;
      font-weight: bold;
      box-shadow: 0 2px 10px rgba(7, 193, 96, 0.3);
      z-index: 1000;
    }
    .copy-btn:hover { background: #06ad56; }
    .copy-btn:active { transform: scale(0.98); }
    .preview-container {
      max-width: 750px;
      margin: 0 auto;
      background: white;
      box-shadow: 0 2px 20px rgba(0,0,0,0.1);
      border-radius: 10px;
      overflow: hidden;
    }
    .preview-header {
      background: #f8f8f8;
      padding: 15px 20px;
      border-bottom: 1px solid #eee;
      font-size: 14px;
      color: #666;
    }
  </style>
</head>
<body>
  <button class="copy-btn" onclick="copyArticle()">📋 复制到公众号</button>
  
  <div class="preview-container">
    <div class="preview-header">
      📱 公众号文章预览 - 点击右上角按钮复制
    </div>
    <div id="article" class="article-container" style="max-width: 677px; margin: 0 auto; padding: 20px; font-family: -apple-system, BlinkMacSystemFont, PingFang SC, Microsoft YaHei, sans-serif; background: #fff;">
      ${content}
    </div>
  </div>

  <script>
    async function copyArticle() {
      const article = document.getElementById('article');
      try {
        const blob = new Blob([article.innerHTML], { type: 'text/html' });
        await navigator.clipboard.write([
          new ClipboardItem({ 'text/html': blob })
        ]);
        alert('✅ 复制成功！\\n\\n请到微信公众号后台，直接粘贴即可。');
      } catch (err) {
        // 降级方案
        const range = document.createRange();
        range.selectNode(article);
        window.getSelection().removeAllRanges();
        window.getSelection().addRange(range);
        document.execCommand('copy');
        window.getSelection().removeAllRanges();
        alert('✅ 复制成功！\\n\\n请到微信公众号后台，直接粘贴即可。');
      }
    }
  </script>
</body>
</html>`;
}

// ============ 主函数 ============
function main() {
  const args = process.argv.slice(2);
  
  if (args.length === 0 || args.includes('--help')) {
    console.log(`
公众号文章美化工具

用法：
  node beautify.js <input.md> [选项]

选项：
  --theme <name>    主题名称 (default|elegant|tech|vibrant)
  --output <file>   输出文件路径
  --help            显示帮助信息

示例：
  node beautify.js article.md
  node beautify.js article.md --theme tech
  node beautify.js article.md --theme elegant --output preview.html
    `);
    return;
  }
  
  const inputFile = args[0];
  let theme = 'default';
  let outputFile = null;
  
  // 解析参数
  for (let i = 1; i < args.length; i++) {
    if (args[i] === '--theme' && args[i + 1]) {
      theme = args[i + 1];
      i++;
    } else if (args[i] === '--output' && args[i + 1]) {
      outputFile = args[i + 1];
      i++;
    }
  }
  
  // 检查主题
  if (!themes[theme]) {
    console.error(`错误：未知主题 "${theme}"，可用主题：${Object.keys(themes).join(', ')}`);
    process.exit(1);
  }
  
  // 读取输入文件
  if (!fs.existsSync(inputFile)) {
    console.error(`错误：文件不存在 "${inputFile}"`);
    process.exit(1);
  }
  
  const markdown = fs.readFileSync(inputFile, 'utf-8');
  
  // 转换
  console.log(`📝 正在处理：${inputFile}`);
  console.log(`🎨 使用主题：${theme}`);
  
  const html = parseMarkdown(markdown);
  const styledHtml = inlineStyles(html, themes[theme]);
  const finalHtml = generateHtmlFile(styledHtml);
  
  // 输出
  if (!outputFile) {
    outputFile = inputFile.replace(/\.md$/, '') + '_wechat.html';
  }
  
  fs.writeFileSync(outputFile, finalHtml, 'utf-8');
  console.log(`✅ 生成成功：${outputFile}`);
  console.log(`\n💡 提示：在浏览器中打开该文件，点击"复制到公众号"按钮即可。`);
}

// 如果直接运行此脚本
if (require.main === module) {
  main();
}

module.exports = { parseMarkdown, inlineStyles, generateHtmlFile, themes };
