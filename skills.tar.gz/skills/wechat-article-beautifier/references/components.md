# 特殊组件样式

## 目录
1. [标题装饰](#标题装饰)
2. [引用样式](#引用样式)
3. [提示框](#提示框)
4. [步骤指示](#步骤指示)
5. [卡片样式](#卡片样式)
6. [代码高亮](#代码高亮)

---

## 标题装饰

### 带图标的标题

```html
<h2 style="font-size: 18px; color: #333; display: flex; align-items: center; margin: 25px 0 15px;">
  <span style="display: inline-block; width: 6px; height: 20px; background: #07c160; margin-right: 10px; border-radius: 3px;"></span>
  标题内容
</h2>
```

### 居中带装饰线标题

```html
<h2 style="font-size: 18px; color: #333; text-align: center; margin: 30px 0 20px; position: relative;">
  <span style="display: inline-block; padding: 0 20px; background: #fff; position: relative; z-index: 1;">标题内容</span>
</h2>
```

### 渐变背景标题

```html
<h2 style="font-size: 18px; color: #fff; padding: 12px 20px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 8px; margin: 25px 0 15px;">
  标题内容
</h2>
```

### 序号标题

```html
<h2 style="font-size: 18px; color: #333; margin: 25px 0 15px; display: flex; align-items: center;">
  <span style="display: inline-flex; align-items: center; justify-content: center; width: 28px; height: 28px; background: #07c160; color: #fff; border-radius: 50%; font-size: 14px; margin-right: 12px;">1</span>
  第一步：准备工作
</h2>
```

---

## 引用样式

### 信息提示引用

```html
<blockquote style="background: #e7f3ff; border-left: 4px solid #1890ff; padding: 12px 15px; margin: 20px 0; border-radius: 0 8px 8px 0;">
  <p style="margin: 0; font-size: 14px; color: #333; line-height: 1.7;">
    <strong style="color: #1890ff;">💡 提示：</strong>这是一条提示信息
  </p>
</blockquote>
```

### 警告引用

```html
<blockquote style="background: #fff7e6; border-left: 4px solid #fa8c16; padding: 12px 15px; margin: 20px 0; border-radius: 0 8px 8px 0;">
  <p style="margin: 0; font-size: 14px; color: #333; line-height: 1.7;">
    <strong style="color: #fa8c16;">⚠️ 注意：</strong>这是一条警告信息
  </p>
</blockquote>
```

### 成功引用

```html
<blockquote style="background: #f6ffed; border-left: 4px solid #52c41a; padding: 12px 15px; margin: 20px 0; border-radius: 0 8px 8px 0;">
  <p style="margin: 0; font-size: 14px; color: #333; line-height: 1.7;">
    <strong style="color: #52c41a;">✅ 成功：</strong>操作已完成
  </p>
</blockquote>
```

### 名人名言引用

```html
<blockquote style="background: #f9f9f9; border: none; padding: 20px 25px; margin: 25px 0; text-align: center; border-radius: 10px;">
  <p style="margin: 0 0 10px; font-size: 16px; color: #555; font-style: italic; line-height: 1.8;">
    "生活不止眼前的苟且，还有诗和远方。"
  </p>
  <p style="margin: 0; font-size: 13px; color: #999;">
    —— 高晓松
  </p>
</blockquote>
```

---

## 提示框

### 蓝色信息框

```html
<div style="background: #e6f7ff; border: 1px solid #91d5ff; border-radius: 8px; padding: 15px; margin: 20px 0;">
  <p style="margin: 0; font-size: 14px; color: #333; line-height: 1.7;">
    <span style="color: #1890ff; font-weight: bold;">ℹ️ 信息</span><br>
    这是一条信息提示内容。
  </p>
</div>
```

### 绿色成功框

```html
<div style="background: #f6ffed; border: 1px solid #b7eb8f; border-radius: 8px; padding: 15px; margin: 20px 0;">
  <p style="margin: 0; font-size: 14px; color: #333; line-height: 1.7;">
    <span style="color: #52c41a; font-weight: bold;">✅ 成功</span><br>
    操作已成功完成。
  </p>
</div>
```

### 黄色警告框

```html
<div style="background: #fffbe6; border: 1px solid #ffe58f; border-radius: 8px; padding: 15px; margin: 20px 0;">
  <p style="margin: 0; font-size: 14px; color: #333; line-height: 1.7;">
    <span style="color: #faad14; font-weight: bold;">⚠️ 警告</span><br>
    请注意以下事项。
  </p>
</div>
```

### 红色错误框

```html
<div style="background: #fff2f0; border: 1px solid #ffccc7; border-radius: 8px; padding: 15px; margin: 20px 0;">
  <p style="margin: 0; font-size: 14px; color: #333; line-height: 1.7;">
    <span style="color: #ff4d4f; font-weight: bold;">❌ 错误</span><br>
    发生了一个错误。
  </p>
</div>
```

---

## 步骤指示

### 横向步骤条

```html
<div style="display: flex; justify-content: space-between; margin: 25px 0; padding: 0 10px;">
  <div style="text-align: center; flex: 1;">
    <div style="width: 32px; height: 32px; background: #07c160; color: #fff; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 14px; font-weight: bold;">1</div>
    <p style="margin: 8px 0 0; font-size: 13px; color: #333;">准备</p>
  </div>
  <div style="text-align: center; flex: 1;">
    <div style="width: 32px; height: 32px; background: #07c160; color: #fff; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 14px; font-weight: bold;">2</div>
    <p style="margin: 8px 0 0; font-size: 13px; color: #333;">执行</p>
  </div>
  <div style="text-align: center; flex: 1;">
    <div style="width: 32px; height: 32px; background: #ddd; color: #999; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 14px; font-weight: bold;">3</div>
    <p style="margin: 8px 0 0; font-size: 13px; color: #999;">完成</p>
  </div>
</div>
```

### 纵向步骤列表

```html
<div style="margin: 20px 0; padding-left: 30px; border-left: 2px solid #07c160;">
  <div style="margin-bottom: 20px; position: relative;">
    <span style="position: absolute; left: -39px; top: 0; width: 20px; height: 20px; background: #07c160; color: #fff; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px;">1</span>
    <h4 style="margin: 0 0 5px; font-size: 15px; color: #333;">第一步：准备环境</h4>
    <p style="margin: 0; font-size: 14px; color: #666; line-height: 1.6;">安装必要的依赖和工具。</p>
  </div>
  <div style="margin-bottom: 20px; position: relative;">
    <span style="position: absolute; left: -39px; top: 0; width: 20px; height: 20px; background: #07c160; color: #fff; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px;">2</span>
    <h4 style="margin: 0 0 5px; font-size: 15px; color: #333;">第二步：配置参数</h4>
    <p style="margin: 0; font-size: 14px; color: #666; line-height: 1.6;">根据需求修改配置文件。</p>
  </div>
</div>
```

---

## 卡片样式

### 简单卡片

```html
<div style="background: #fff; border: 1px solid #eee; border-radius: 10px; padding: 20px; margin: 20px 0; box-shadow: 0 2px 8px rgba(0,0,0,0.06);">
  <h4 style="margin: 0 0 10px; font-size: 16px; color: #333;">卡片标题</h4>
  <p style="margin: 0; font-size: 14px; color: #666; line-height: 1.7;">卡片内容描述文字。</p>
</div>
```

### 带图标卡片

```html
<div style="background: #f8f9fa; border-radius: 10px; padding: 20px; margin: 20px 0; display: flex; align-items: flex-start;">
  <span style="font-size: 30px; margin-right: 15px;">🚀</span>
  <div>
    <h4 style="margin: 0 0 8px; font-size: 16px; color: #333;">快速开始</h4>
    <p style="margin: 0; font-size: 14px; color: #666; line-height: 1.6;">只需三步即可完成配置。</p>
  </div>
</div>
```

### 渐变边框卡片

```html
<div style="background: linear-gradient(135deg, #667eea, #764ba2); padding: 2px; border-radius: 12px; margin: 20px 0;">
  <div style="background: #fff; border-radius: 10px; padding: 20px;">
    <h4 style="margin: 0 0 10px; font-size: 16px; color: #333;">精选内容</h4>
    <p style="margin: 0; font-size: 14px; color: #666; line-height: 1.7;">这是一段精选内容的描述。</p>
  </div>
</div>
```

---

## 代码高亮

### JavaScript 代码块

```html
<pre style="background: #282c34; color: #abb2bf; padding: 18px; border-radius: 8px; overflow-x: auto; font-size: 13px; line-height: 1.6; margin: 20px 0;">
<code style="font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;">
<span style="color: #c678dd;">const</span> <span style="color: #e06c75;">greeting</span> <span style="color: #56b6c2;">=</span> <span style="color: #98c379;">"Hello World"</span>;
<span style="color: #c678dd;">function</span> <span style="color: #61afef;">sayHello</span>() {
  <span style="color: #e5c07b;">console</span>.<span style="color: #61afef;">log</span>(greeting);
}
</code>
</pre>
```

### Python 代码块

```html
<pre style="background: #1e1e1e; color: #d4d4d4; padding: 18px; border-radius: 8px; overflow-x: auto; font-size: 13px; line-height: 1.6; margin: 20px 0;">
<code style="font-family: 'SFMono-Regular', Consolas, monospace;">
<span style="color: #569cd6;">def</span> <span style="color: #dcdcaa;">hello</span>():
    <span style="color: #ce9178;">"""Say hello"""</span>
    <span style="color: #c586c0;">print</span>(<span style="color: #ce9178;">"Hello World"</span>)
</code>
</pre>
```

### 带行号的代码块

```html
<div style="background: #282c34; border-radius: 8px; overflow: hidden; margin: 20px 0;">
  <div style="background: #21252b; padding: 8px 15px; font-size: 12px; color: #abb2bf;">
    JavaScript
  </div>
  <pre style="margin: 0; padding: 15px; overflow-x: auto;"><code style="font-family: Consolas, monospace; font-size: 13px; line-height: 1.6; color: #abb2bf;">
<span style="color: #5c6370; user-select: none;">1  </span><span style="color: #c678dd;">const</span> app = <span style="color: #c678dd;">require</span>(<span style="color: #98c379;">'express'</span>)();
<span style="color: #5c6370; user-select: none;">2  </span>
<span style="color: #5c6370; user-select: none;">3  </span>app.<span style="color: #61afef;">get</span>(<span style="color: #98c379;">'/'</span>, (req, res) => {
<span style="color: #5c6370; user-select: none;">4  </span>  res.<span style="color: #61afef;">send</span>(<span style="color: #98c379;">'Hello World'</span>);
<span style="color: #5c6370; user-select: none;">5  </span>});
</code></pre>
</div>
```

---

## 使用说明

1. 复制需要的组件 HTML 代码
2. 替换其中的文字内容
3. 组件已包含内联样式，可直接使用
4. 可根据需要调整颜色和尺寸
