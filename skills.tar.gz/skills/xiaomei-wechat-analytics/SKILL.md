---
name: xiaomei-wechat-analytics
description: 小梅微信公众号数据分析技能包。定期抓取"小梅的深夜随笔"公众号后台数据，分析文章表现（阅读量、点赞、在看、分享、收藏等），生成数据分析报告并更新知识库。独立于写作流程，可定期执行。当需要：(1) 抓取公众号数据 (2) 分析文章表现 (3) 生成数据报告 (4) 更新知识库时触发此技能。
---

# 小梅微信公众号数据分析技能

## 概述
独立的数据分析流程，定期抓取并分析小梅公众号的文章数据，帮助优化内容创作策略。

**与写作流程的关系**：
- 独立的 skill，不依赖 xiaomei-emotional-writing
- 可定期执行（如每周、每月）
- 分析结果自动更新知识库
- 写作时自动从知识库获取数据洞察

## ⚠️ 账号验证

**默认验证账号**：小梅的深夜随笔

**验证目的**：避免错误分析其他公众号的数据

**验证方式**：通过 Chrome DevTools 检查当前登录的公众号名称

**如何确认账号是否正确：**
1. 访问 https://mp.weixin.qq.com/
2. 登录公众号后台
3. 在页面顶部或标题栏查看公众号名称
4. 确认显示的是"小梅的深夜随笔"

## 功能
1. 通过 chrome-devtools 抓取公众号后台数据
2. **验证账号**：确认当前登录的是"小梅的深夜随笔"
3. 分析文章表现（阅读量、点赞、在看、分享、收藏等）
4. 生成数据分析报告
5. 更新 xiaomei-works/analytics/knowledge_base.json

## 数据抓取方法

### 方法一：Chrome DevTools 抓取（推荐）

**为什么推荐这种方式：**
- 微信 API 的数据统计接口（datacube）只对认证服务号开放
- 订阅号无法通过 API 获取阅读量、点赞等数据
- Chrome DevTools 可以直接从公众平台后台抓取完整数据
- 支持自动账号验证，避免错误分析

**抓取步骤：**

1. 确保 Chrome 浏览器已打开并连接 DevTools MCP
2. 导航到微信公众平台：`https://mp.weixin.qq.com/`
3. 登录公众号后台（扫码或账号密码）
4. **系统自动验证账号**：检查当前登录的是否为"小梅的深夜随笔"
   - 如果账号正确：继续执行数据抓取
   - 如果账号错误：停止执行并提示切换到正确的账号
5. 在首页"近期发表"区域可直接获取最近文章数据
6. 点击"全部发表记录"可获取更多历史数据

**账号验证流程**：
```python
# 系统会执行以下验证步骤：
1. 从公众号后台页面获取当前账号名称
2. 对比是否为"小梅的深夜随笔"
3. 验证通过：继续数据抓取
4. 验证失败：提示错误，停止执行
```

**可抓取的数据字段：**
- 文章标题、发布时间、URL
- 阅读数（read_count）
- 点赞数（like_count）
- 在看数（wow_count）
- 分享数（share_count）
- 收藏数（favorite_count）
- 评论数（comment_count）

**抓取后操作：**
1. 更新 `works/analytics/articles.json` - 文章数据
2. 分析数据并更新 `works/analytics/knowledge_base.json` - 知识库
3. 生成 `works/analytics/analysis_report.md` - 分析报告

### 方法二：API 方式（仅限认证服务号）

**注意：** 以下 API 仅对认证服务号开放，订阅号无法使用。

#### 获取 Access Token
```python
GET https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={APPID}&secret={SECRET}
```

#### 获取已发布文章列表（仅基本信息，无统计数据）
```python
POST https://api.weixin.qq.com/cgi-bin/freepublish/batchget?access_token={TOKEN}
{
    "offset": 0,
    "count": 20,
    "no_content": 1
}
```

#### 获取文章数据统计（仅认证服务号）
```python
POST https://api.weixin.qq.com/datacube/getarticletotal?access_token={TOKEN}
{
    "begin_date": "2024-01-01",
    "end_date": "2024-01-07"
}
```

## 数据存储位置
- `works/analytics/articles.json` - 文章数据
- `works/analytics/articles_archive.json` - 历史文章归档
- `works/analytics/analysis_report.md` - 分析报告
- `works/analytics/knowledge_base.json` - 知识库

## 数据字段说明

### 文章数据 (articles.json)
```json
{
  "last_updated": "更新时间",
  "source": "chrome-devtools抓取",
  "account_info": {
    "name": "公众号名称",
    "original_count": 原创数量,
    "total_followers": 粉丝数,
    "yesterday_read": 昨日阅读,
    "yesterday_share": 昨日分享,
    "yesterday_new_followers": 昨日新增关注
  },
  "articles": [
    {
      "id": "文章ID",
      "title": "文章标题",
      "publish_date": "发布日期",
      "publish_time": "发布时间",
      "url": "文章URL",
      "is_original": true/false,
      "stats": {
        "read_count": 阅读数,
        "like_count": 点赞数,
        "wow_count": 在看数,
        "share_count": 分享数,
        "favorite_count": 收藏数,
        "comment_count": 评论数
      },
      "metrics": {
        "like_rate": 点赞率,
        "share_rate": 分享率,
        "engagement_rate": 互动率
      }
    }
  ]
}
```

### 知识库 (knowledge_base.json)
包含从历史数据中学习到的规律：
- `proven_patterns` - 验证有效的内容模式
- `title_patterns` - 标题写作规律
- `content_patterns` - 内容写作规范
- `benchmarks` - 表现基准线
- `evolution_log` - 知识演进记录

## 注意事项
1. **账号验证**：在分析数据前，系统会自动验证当前登录的公众号是否为"小梅的深夜随笔"
2. Chrome DevTools 抓取需要先登录公众号后台
3. 数据统计有 1-3 天延迟，最新文章数据可能不完整
4. 每次抓取后应更新知识库，持续学习优化
5. 敏感数据不要提交到 Git
6. 如果账号验证失败，请：
   - 确认登录的是正确的公众号（小梅的深夜随笔）
   - 如果需要切换账号，先退出当前账号再重新登录
   - 刷新页面后重新执行分析任务

## 数据输出位置

**知识库更新**：
- `xiaomei-works/analytics/knowledge_base.json` - 小梅知识库
- `xiaomei-works/analytics/analysis_report.md` - 分析报告

**使用场景**：
- 定期数据分析（每周/每月）
- 优化内容创作策略
- 了解读者偏好
- 跟踪文章表现
