#!/usr/bin/env python3
"""
微信公众号草稿发布脚本

用法：
    python publish_to_draft.py --title "文章标题" --content article.html --cover cover.jpg

支持自动处理文章内的图片：
    - 本地图片路径：自动上传到微信服务器
    - 外部图片URL：自动下载并上传到微信服务器
"""

import argparse
import os
import sys
import io
import json
import re
import requests
import tempfile
import hashlib
from urllib.parse import urlparse
from dotenv import load_dotenv

# 设置UTF-8输出编码（解决Windows下emoji打印问题）
if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8")

# 加载环境变量
load_dotenv()

# 配置
WECHAT_APP_ID = os.getenv("WECHAT_APP_ID")
WECHAT_APP_SECRET = os.getenv("WECHAT_APP_SECRET")

# API URLs
ACCESS_TOKEN_URL = "https://api.weixin.qq.com/cgi-bin/token"
UPLOAD_IMG_URL = "https://api.weixin.qq.com/cgi-bin/media/uploadimg"
ADD_MATERIAL_URL = "https://api.weixin.qq.com/cgi-bin/material/add_material"
DRAFT_ADD_URL = "https://api.weixin.qq.com/cgi-bin/draft/add"
FREEPUBLISH_URL = "https://api.weixin.qq.com/cgi-bin/freepublish/submit"


class WeChatPublisher:
    """微信公众号发布器"""

    def __init__(self):
        self.access_token = None
        self._check_config()
        self._get_access_token()

    def _check_config(self):
        """检查配置"""
        if not WECHAT_APP_ID or not WECHAT_APP_SECRET:
            print("❌ 错误：请在 .env 文件中配置 WECHAT_APP_ID 和 WECHAT_APP_SECRET")
            sys.exit(1)

    def _get_access_token(self):
        """获取 access_token"""
        params = {
            "grant_type": "client_credential",
            "appid": WECHAT_APP_ID,
            "secret": WECHAT_APP_SECRET,
        }

        try:
            response = requests.get(ACCESS_TOKEN_URL, params=params)
            result = response.json()

            if "access_token" in result:
                self.access_token = result["access_token"]
                print(f"✅ 获取 access_token 成功")
            else:
                print(f"❌ 获取 access_token 失败: {result}")
                sys.exit(1)
        except Exception as e:
            print(f"❌ 请求失败: {e}")
            sys.exit(1)

    def upload_image(self, image_path):
        """上传图片获取URL（用于文章内图片）"""
        if not os.path.exists(image_path):
            raise FileNotFoundError(f"图片不存在: {image_path}")

        with open(image_path, "rb") as f:
            files = {"media": (os.path.basename(image_path), f, "image/jpeg")}
            params = {"access_token": self.access_token}

            response = requests.post(UPLOAD_IMG_URL, params=params, files=files)
            result = response.json()

            if "url" in result:
                print(f"✅ 上传图片成功: {os.path.basename(image_path)}")
                return result["url"]
            else:
                raise Exception(f"上传图片失败: {result}")

    def upload_image_from_url(self, image_url):
        """从URL下载图片并上传到微信服务器"""
        try:
            # 下载图片
            headers = {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            }
            response = requests.get(image_url, headers=headers, timeout=30)
            response.raise_for_status()

            # 获取文件扩展名
            content_type = response.headers.get("Content-Type", "image/jpeg")
            ext_map = {
                "image/jpeg": ".jpg",
                "image/png": ".png",
                "image/gif": ".gif",
                "image/webp": ".webp",
            }
            ext = ext_map.get(content_type, ".jpg")

            # 生成临时文件名
            url_hash = hashlib.md5(image_url.encode()).hexdigest()[:8]
            temp_filename = f"temp_img_{url_hash}{ext}"
            temp_path = os.path.join(tempfile.gettempdir(), temp_filename)

            # 保存到临时文件
            with open(temp_path, "wb") as f:
                f.write(response.content)

            # 上传到微信
            wechat_url = self.upload_image(temp_path)

            # 清理临时文件
            os.remove(temp_path)

            return wechat_url
        except Exception as e:
            print(f"⚠️ 处理图片URL失败: {image_url}, 错误: {e}")
            return None

    def upload_material(self, file_path, media_type="thumb"):
        """上传永久素材（用于封面图）"""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"文件不存在: {file_path}")

        with open(file_path, "rb") as f:
            files = {"media": (os.path.basename(file_path), f, "image/jpeg")}
            params = {"access_token": self.access_token, "type": media_type}

            response = requests.post(ADD_MATERIAL_URL, params=params, files=files)
            result = response.json()

            if "media_id" in result:
                print(f"✅ 上传封面图成功: media_id={result['media_id']}")
                return result["media_id"]
            else:
                raise Exception(f"上传封面图失败: {result}")

    def create_draft(
        self,
        title,
        content,
        thumb_media_id,
        author="",
        digest="",
        content_source_url="",
        need_open_comment=1,
        only_fans_can_comment=0,
    ):
        """
        创建草稿

        Args:
            title: 文章标题
            content: HTML内容
            thumb_media_id: 封面图media_id
            author: 作者
            digest: 摘要（不填则自动截取前54字）
            content_source_url: 原文链接
            need_open_comment: 是否打开评论 (0关闭, 1打开)
            only_fans_can_comment: 是否仅粉丝可评论 (0所有人, 1仅粉丝)
        """
        articles = [
            {
                "title": title,
                "thumb_media_id": thumb_media_id,
                "author": author,
                "digest": digest,
                "content": content,
                "content_source_url": content_source_url,
                "show_cover_pic": 0,
                "need_open_comment": need_open_comment,
                "only_fans_can_comment": only_fans_can_comment,
            }
        ]

        params = {"access_token": self.access_token}
        data = {"articles": articles}

        headers = {"Content-Type": "application/json; charset=utf-8"}
        json_data = json.dumps(data, ensure_ascii=False)

        response = requests.post(
            DRAFT_ADD_URL,
            params=params,
            data=json_data.encode("utf-8"),
            headers=headers,
        )
        result = response.json()

        if result.get("errcode", 0) == 0 and "media_id" in result:
            print(f"✅ 创建草稿成功: media_id={result['media_id']}")
            return result["media_id"]
        else:
            raise Exception(f"创建草稿失败: {result}")

    def publish_draft(self, media_id):
        """发布草稿"""
        params = {"access_token": self.access_token}
        data = {"media_id": media_id}

        response = requests.post(FREEPUBLISH_URL, params=params, json=data)
        result = response.json()

        if result.get("errcode", 0) == 0 and "publish_id" in result:
            print(f"✅ 发布成功: publish_id={result['publish_id']}")
            return result["publish_id"]
        else:
            raise Exception(f"发布失败: {result}")


def extract_article_content(html_content):
    """从美化后的 HTML 文件中提取文章内容"""
    # 提取 id="article" 的 div 内容
    article_match = re.search(
        r'<div[^>]*id="article"[^>]*>([\s\S]*?)</div>\s*</div>\s*<script',
        html_content,
        re.IGNORECASE,
    )
    if article_match:
        return article_match.group(1).strip()

    # 备选：提取 body 内容
    body_match = re.search(r"<body[^>]*>([\s\S]*)</body>", html_content, re.IGNORECASE)
    if body_match:
        return body_match.group(1).strip()

    # 如果都没有，返回原内容
    return html_content


def process_images_in_content(content, publisher, base_path=None):
    """
    处理文章内容中的图片，将外部图片上传到微信服务器

    Args:
        content: HTML内容
        publisher: WeChatPublisher实例
        base_path: 本地图片的基础路径

    Returns:
        处理后的HTML内容
    """
    # 匹配所有img标签的src属性
    img_pattern = r'<img([^>]*?)src=["\']([^"\']+)["\']([^>]*?)>'

    def replace_image(match):
        before = match.group(1)
        src = match.group(2)
        after = match.group(3)

        # 跳过已经是微信服务器的图片
        if "mmbiz.qpic.cn" in src:
            return match.group(0)

        # 跳过base64图片
        if src.startswith("data:"):
            return match.group(0)

        new_url = None

        # 处理外部URL
        if src.startswith("http://") or src.startswith("https://"):
            print(f"🔄 处理外部图片: {src[:60]}...")
            new_url = publisher.upload_image_from_url(src)

        # 处理本地路径
        elif base_path:
            local_path = os.path.join(base_path, src) if not os.path.isabs(src) else src
            if os.path.exists(local_path):
                print(f"🔄 处理本地图片: {src}")
                new_url = publisher.upload_image(local_path)

        if new_url:
            return f'<img{before}src="{new_url}"{after}>'
        else:
            print(f"⚠️ 无法处理图片: {src}")
            return match.group(0)

    processed_content = re.sub(img_pattern, replace_image, content, flags=re.IGNORECASE)
    return processed_content


def main():
    parser = argparse.ArgumentParser(description="发布文章到微信公众号草稿箱")
    parser.add_argument("--title", required=True, help="文章标题")
    parser.add_argument("--content", required=True, help="HTML文件路径（美化后的文章）")
    parser.add_argument("--cover", required=True, help="封面图路径")
    parser.add_argument("--author", default="", help="作者名称")
    parser.add_argument("--digest", default="", help="文章摘要（不填自动截取前54字）")
    parser.add_argument("--source-url", default="", help="原文链接")
    parser.add_argument("--no-comment", action="store_true", help="关闭评论功能")
    parser.add_argument("--fans-only", action="store_true", help="仅粉丝可评论")
    parser.add_argument(
        "--ai-generated", action="store_true", help="在文末添加AI生成声明"
    )
    parser.add_argument("--publish", action="store_true", help="创建后直接发布")
    parser.add_argument("--no-image-process", action="store_true", help="跳过图片处理")

    args = parser.parse_args()

    print(f"\n📝 准备发布文章: {args.title}")
    print(f"📄 内容文件: {args.content}")
    print(f"📷 封面图: {args.cover}")

    # 读取 HTML 内容
    with open(args.content, "r", encoding="utf-8") as f:
        html_content = f.read()

    # 提取文章内容
    content = extract_article_content(html_content)
    print(f"✅ 提取文章内容成功 ({len(content)} 字符)")

    # 添加AI生成声明
    if args.ai_generated:
        ai_notice = """
<p style="font-size: 12px; color: #999; text-align: center; margin-top: 30px; padding-top: 15px; border-top: 1px dashed #ddd;">
📝 本文内容由AI辅助生成
</p>"""
        content = content + ai_notice
        print(f"✅ 已添加AI生成声明")

    # 创建发布器
    publisher = WeChatPublisher()

    # 处理文章内的图片
    if not args.no_image_process:
        # 检查是否有需要处理的图片（排除已上传到微信的和base64图片）
        img_count = len(
            re.findall(
                r'<img[^>]*src=["\'](?!data:)(?!https?://mmbiz\.qpic\.cn)', content
            )
        )
        if img_count > 0:
            print(f"\n🖼️ 发现 {img_count} 张图片需要处理...")
            base_path = os.path.dirname(os.path.abspath(args.content))
            content = process_images_in_content(content, publisher, base_path)
            print(f"✅ 图片处理完成")

    # 上传封面图
    print(f"\n⬆️ 上传封面图...")
    thumb_media_id = publisher.upload_material(args.cover, "thumb")

    # 创建草稿
    print(f"\n📤 创建草稿...")
    draft_id = publisher.create_draft(
        title=args.title,
        content=content,
        thumb_media_id=thumb_media_id,
        author=args.author,
        digest=args.digest,
        content_source_url=args.source_url,
        need_open_comment=0 if args.no_comment else 1,
        only_fans_can_comment=1 if args.fans_only else 0,
    )

    print(f"\n✅ 草稿创建成功！")
    print(f"   media_id: {draft_id}")
    print(f"   请到公众号后台查看草稿箱")

    # 可选：发布
    if args.publish:
        print(f"\n📢 发布文章...")
        publish_id = publisher.publish_draft(draft_id)
        print(f"✅ 发布成功！publish_id: {publish_id}")

    return 0

    return 0

    return 0


if __name__ == "__main__":
    sys.exit(main())
