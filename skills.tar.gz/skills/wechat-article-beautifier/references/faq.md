# 常见问题解答

## 目录
1. [样式丢失问题](#样式丢失问题)
2. [图片问题](#图片问题)
3. [代码显示问题](#代码显示问题)
4. [排版问题](#排版问题)
5. [兼容性问题](#兼容性问题)

---

## 样式丢失问题

### Q: 粘贴到公众号后样式全部丢失？

**原因：** 微信公众号编辑器会过滤 `<style>` 标签，只保留行内样式。

**解决方案：**
1. 确保使用 CSS 内联化工具（如 Juice）处理 HTML
2. 所有样式必须写在 `style="..."` 属性中
3. 检查是否有遗漏的外部样式引用

### Q: 部分样式生效，部分不生效？

**原因：** 微信公众号不支持某些 CSS 属性。

**不支持的属性：**
- `position: fixed/absolute`（部分场景）
- `float`（不稳定）
- `@keyframes` 动画
- `transform`（部分）
- `filter`
- CSS 变量 `var(--xxx)`

**解决方案：** 使用基础 CSS 属性，避免高级特性。

### Q: 字体不生效？

**原因：** 微信公众号只支持系统默认字体。

**推荐字体栈：**
```css
font-family: -apple-system, BlinkMacSystemFont, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif;
```

---

## 图片问题

### Q: 图片无法显示？

**原因：** 微信公众号有图片防盗链机制。

**解决方案：**
1. 将图片上传到微信素材库
2. 使用微信允许的图床
3. 将小图片转为 base64 编码

**Base64 转换示例：**
```javascript
function imageToBase64(url) {
  return fetch(url)
    .then(res => res.blob())
    .then(blob => {
      return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.readAsDataURL(blob);
      });
    });
}
```

### Q: 图片尺寸不对？

**解决方案：**
```css
img {
  max-width: 100%;
  height: auto;
  display: block;
}
```

### Q: 图片无法居中？

**解决方案：**
```html
<p style="text-align: center;">
  <img src="..." style="max-width: 100%; display: inline-block;">
</p>
```

---

## 代码显示问题

### Q: 代码块背景色不显示？

**原因：** 可能是 `pre` 标签的样式被覆盖。

**解决方案：**
```html
<pre style="background: #282c34 !important; padding: 15px; border-radius: 5px; overflow-x: auto;">
  <code style="color: #abb2bf; font-family: Consolas, monospace;">
    // 代码内容
  </code>
</pre>
```

### Q: 代码高亮颜色不显示？

**原因：** 高亮样式没有内联化。

**解决方案：** 将每个高亮 token 的颜色写成行内样式：
```html
<span style="color: #c678dd;">const</span>
<span style="color: #e06c75;">name</span>
<span style="color: #56b6c2;">=</span>
<span style="color: #98c379;">"value"</span>
```

### Q: 代码太长被截断？

**解决方案：**
```css
pre {
  overflow-x: auto;
  white-space: pre;
  word-wrap: normal;
}
```

---

## 排版问题

### Q: 行间距太小/太大？

**解决方案：** 调整 `line-height` 属性：
```css
p {
  line-height: 1.8;  /* 推荐值：1.6-2.0 */
}
```

### Q: 段落间距不一致？

**解决方案：** 统一设置 margin：
```css
p {
  margin: 15px 0;
}
```

### Q: 列表缩进不正确？

**解决方案：**
```css
ul, ol {
  padding-left: 25px;
  margin: 15px 0;
}
li {
  margin: 8px 0;
}
```

### Q: 表格显示不全？

**解决方案：**
```html
<div style="overflow-x: auto;">
  <table style="min-width: 100%;">
    ...
  </table>
</div>
```

---

## 兼容性问题

### Q: iOS 和 Android 显示不一致？

**常见差异：**
1. 字体渲染差异
2. 行高计算差异
3. 边框圆角差异

**解决方案：**
- 使用系统字体栈
- 避免使用小数值
- 测试两个平台

### Q: 深色模式下显示异常？

**解决方案：** 避免使用纯白背景和纯黑文字：
```css
.article-container {
  background: #fefefe;  /* 略带灰的白色 */
}
p {
  color: #333;  /* 深灰而非纯黑 */
}
```

### Q: 旧版微信显示异常？

**解决方案：**
- 避免使用 Flexbox（旧版不支持）
- 避免使用 CSS Grid
- 使用传统布局方式

---

## 最佳实践

### 1. 样式简化原则
- 只使用必要的样式
- 避免复杂的选择器
- 优先使用行内样式

### 2. 测试流程
1. 在浏览器中预览
2. 复制到公众号后台
3. 使用手机预览
4. 检查 iOS 和 Android

### 3. 推荐的 CSS 属性
```
✅ 推荐使用：
- color, background-color
- font-size, font-weight, font-family
- line-height, letter-spacing
- margin, padding
- border, border-radius
- text-align
- display: block/inline/inline-block

❌ 避免使用：
- position: fixed/absolute
- float
- transform
- animation
- filter
- CSS 变量
```

### 4. 调试技巧
- 使用浏览器开发者工具检查样式
- 逐步添加样式，定位问题
- 保留简单的备用样式
