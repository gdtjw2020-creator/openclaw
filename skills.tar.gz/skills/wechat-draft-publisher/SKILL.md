---
name: wechat-draft-publisher
description: 微信公众号草稿发布技能包。将图文文章自动发布到微信公众号草稿箱，支持：(1) HTML格式文章发布到草稿箱 (2) 自动上传图片到微信服务器 (3) 设置封面图和文章元信息 (4) 从草稿箱发布文章。当需要发布文章到公众号、上传图文到微信草稿箱、自动发布公众号内容时触发此技能。
---

# WeChat Draft Publisher

将图文文章自动发布到微信公众号草稿箱。

## 前置要求

1. **已认证的微信公众号**（服务号或认证订阅号）
2. **AppID 和 AppSecret**：在公众号后台 → 开发 → 基本配置 中获取
3. **IP白名单**：将服务器IP添加到公众号白名单

## 配置

在项目目录创建 `.env` 文件：
```
WECHAT_APP_ID=你的AppID
WECHAT_APP_SECRET=你的AppSecret
```

## 工作流程

```
使用 wechat-article-beautifier 美化文章 → 准备封面图 → 上传封面图 → 创建草稿 → (可选)发布
```

**与美化技能配合使用：**
1. 先用 `wechat-article-beautifier` 将 Markdown 转换为美化后的 HTML
2. 再用本技能将 HTML 发布到公众号草稿箱

## 快速使用

**发布美化后的文章到草稿箱：**
```bash
python scripts/publish_to_draft.py --title "文章标题" --content 美化后的文章.html --cover cover.jpg
```

**带作者和摘要：**
```bash
python scripts/publish_to_draft.py --title "文章标题" --content article.html --cover cover.jpg --author "作者名" --digest "文章摘要"
```

**创建后直接发布：**
```bash
python scripts/publish_to_draft.py --title "文章标题" --content article.html --cover cover.jpg --publish
```

## API 说明

### 核心接口

| 接口 | 用途 | 说明 |
|------|------|------|
| /cgi-bin/token | 获取 access_token | 有效期2小时 |
| /cgi-bin/media/uploadimg | 上传图文消息内的图片 | 返回图片URL |
| /cgi-bin/material/add_material | 上传永久素材 | 用于封面图 |
| /cgi-bin/draft/add | 新建草稿 | 核心接口 |
| /cgi-bin/freepublish/submit | 发布草稿 | 从草稿发布 |

### 草稿接口参数

```json
{
  "articles": [{
    "title": "文章标题",
    "thumb_media_id": "封面图media_id",
    "author": "作者",
    "digest": "摘要（可选）",
    "content": "HTML内容",
    "content_source_url": "原文链接（可选）",
    "show_cover_pic": 0,
    "need_open_comment": 1,
    "only_fans_can_comment": 0
  }]
}
```

## 注意事项

### 图片处理
- 文章内图片需先上传到微信服务器获取URL
- 封面图需上传为永久素材获取 media_id
- 图片大小限制：2MB
- 支持格式：jpg, png, gif

### 内容限制
- 文章内容必须是 HTML 格式
- 不支持外部 CSS，样式必须内联
- 不支持 JavaScript
- 图片必须使用微信服务器的URL

### 常见错误

| 错误码 | 说明 | 解决方案 |
|--------|------|----------|
| 40001 | access_token 无效 | 重新获取 token |
| 40004 | 无效的媒体文件 | 检查图片格式和大小 |
| 45009 | API 调用频率超限 | 等待后重试 |
| 48001 | 没有接口权限 | 检查公众号认证状态 |

## 脚本说明

### publish_to_draft.py

主发布脚本，支持参数：

```
--title       文章标题（必需）
--content     HTML文件路径（美化后的文章，必需）
--cover       封面图路径（必需）
--author      作者名称
--digest      文章摘要
--publish     创建后直接发布（默认只保存草稿）
```

### wechat_api.py

微信API封装类，提供方法：

- `get_access_token()` - 获取访问令牌
- `upload_image(path)` - 上传图片获取URL
- `upload_material(path)` - 上传永久素材
- `create_draft(articles)` - 创建草稿
- `publish_draft(media_id)` - 发布草稿

## 完整示例

```python
from wechat_api import WeChatAPI

api = WeChatAPI()

# 1. 上传封面图
cover_media_id = api.upload_material("cover.jpg", "thumb")

# 2. 上传文章内图片（如果有）
img_url = api.upload_image("photo1.jpg")

# 3. 准备文章内容（替换图片URL）
content = f'<p>这是文章内容</p><img src="{img_url}">'

# 4. 创建草稿
draft_id = api.create_draft(
    title="文章标题",
    content=content,
    thumb_media_id=cover_media_id,
    author="作者名"
)

print(f"草稿创建成功: {draft_id}")

# 5. 可选：发布草稿
# api.publish_draft(draft_id)
```

## References

- **API文档**: See [references/wechat-api.md](references/wechat-api.md) 获取完整API说明
- **错误处理**: See [references/error-codes.md](references/error-codes.md) 获取错误码列表
