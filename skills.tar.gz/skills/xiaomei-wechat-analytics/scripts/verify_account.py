#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
微信公众号账号验证脚本
验证当前登录的公众号是否为小梅的账号
"""

import json
import sys
import io
from pathlib import Path

# 设置 Windows 命令行编码
if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

# 数据存储路径
ANALYTICS_DIR = Path("works/analytics")
CONFIG_FILE = ANALYTICS_DIR / "config.json"

# 小梅的公众号名称（用于账号验证）
XIAOMEI_ACCOUNT_NAME = "小梅的深夜随笔"


def load_config():
    """加载配置"""
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {
        "account_name": XIAOMEI_ACCOUNT_NAME,
        "last_checked_account": None,
        "last_verified_time": None,
    }


def save_config(config):
    """保存配置"""
    ANALYTICS_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=2)


def verify_account_name(account_name):
    """验证公众号名称是否正确

    Args:
        account_name: 当前登录的公众号名称

    Returns:
        (is_valid, message): 是否有效和提示信息
    """
    if not account_name:
        return False, "❌ 无法获取公众号名称，请确保已登录公众号后台"

    if account_name == XIAOMEI_ACCOUNT_NAME:
        return True, f"✅ 账号验证通过：{account_name}"
    else:
        return (
            False,
            f"❌ 账号验证失败！\n   当前登录的公众号：{account_name}\n   预期账号：{XIAOMEI_ACCOUNT_NAME}\n   请确保登录的是小梅的公众号，避免分析错误账号的数据！",
        )


def print_verification_result(is_valid, message):
    """打印验证结果"""
    print("\n" + "=" * 60)
    print("🔐 公众号账号验证")
    print("=" * 60)
    print(f"\n{message}")

    if is_valid:
        print("\n✅ 验证通过，可以开始抓取数据")
        print("\n📊 后续步骤：")
        print("   1. 使用 Chrome DevTools MCP 工具抓取数据")
        print("   2. 分析文章表现")
        print("   3. 生成数据报告")
        print("   4. 更新知识库")
    else:
        print("\n🚨 验证失败，请先切换到正确的账号")
        print("\n📝 操作步骤：")
        print("   1. 访问 https://mp.weixin.qq.com/")
        print("   2. 退出当前账号")
        print("   3. 重新登录正确的公众号（小梅的深夜随笔）")
        print("   4. 刷新页面后重新验证")

    print("=" * 60 + "\n")


def get_verification_instructions():
    """获取验证说明"""
    return f"""
# 公众号账号验证说明

## 目标账号

**正确的公众号名称**：{XIAOMEI_ACCOUNT_NAME}

## 验证目的

为了避免错误分析其他公众号的数据，系统会在抓取数据前验证当前登录的公众号是否正确。

## 如何验证

### 方法 1：通过 MCP 工具验证（推荐）

1. 打开 Chrome 浏览器，访问：https://mp.weixin.qq.com/
2. 登录公众号后台
3. 使用 `chrome-devtools_take_snapshot` 获取页面快照
4. 检查页面中的公众号名称是否为"{XIAOMEI_ACCOUNT_NAME}"

### 方法 2：手动验证

1. 访问 https://mp.weixin.qq.com/
2. 登录公众号后台
3. 在页面顶部或标题栏查看公众号名称
4. 确认显示的是"{XIAOMEI_ACCOUNT_NAME}"

## 验证失败处理

如果验证失败，请：

1. 确认当前登录的公众号名称是否正确
2. 如果登录的是其他公众号，请先退出
3. 重新登录正确的公众号（{XIAOMEI_ACCOUNT_NAME}）
4. 刷新页面后重新执行验证

## 配置文件

验证配置保存在：{CONFIG_FILE}

记录信息：
- `account_name`: 预期的公众号名称
- `last_checked_account`: 上次验证的账号
- `last_verified_time`: 上次验证时间
"""


if __name__ == "__main__":
    print(get_verification_instructions())

    config = load_config()
    print(f"\n📋 当前配置：")
    print(f"   预期账号：{config.get('account_name', XIAOMEI_ACCOUNT_NAME)}")
    print(f"   上次验证：{config.get('last_checked_account', '未验证')}")
    print(f"   验证时间：{config.get('last_verified_time', '未验证')}")
    print("\n💡 提示：请使用 MCP 工具获取页面快照后调用验证函数")
