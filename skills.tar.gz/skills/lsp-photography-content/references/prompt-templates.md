# AI图像生成提示词模板库

## 目录
1. [提示词结构](#提示词结构)
2. [风格模板](#风格模板)
3. [场景模板](#场景模板)
4. [光线模板](#光线模板)
5. [服装模板](#服装模板)
6. [组合示例](#组合示例)

---

## 提示词结构

### 基础结构
```
[主体] + [服装] + [场景] + [光线] + [风格] + [技术参数]
```

### 完整结构
```
[主体描述], [年龄/气质], [服装详情], [姿态/动作], [场景环境], [光线条件], [摄影风格], [色调氛围], [相机/镜头], [其他细节]
```

### 质量增强词
- `professional photography`
- `high quality`
- `detailed`
- `sharp focus`
- `beautiful lighting`
- `masterpiece`

---

## 风格模板

### 日系清新风
```
A young Asian woman with natural light makeup, soft smile, wearing [服装], in [场景], soft diffused natural light, Japanese photography style, film camera aesthetic, warm pastel tones, shallow depth of field, dreamy atmosphere, Fujifilm color science
```

### 复古胶片风
```
An elegant Asian woman, [服装], [场景], vintage film photography style, Kodak Portra 400 colors, natural film grain, nostalgic warm tones, soft contrast, retro aesthetic, shot on medium format film camera
```

### 韩系氛围风
```
A stylish Asian woman with minimal makeup, [服装], [场景], Korean photography style, soft muted tones, low contrast, moody atmosphere, editorial look, clean composition, subtle color grading
```

### 电影感风格
```
A beautiful Asian woman, [服装], [场景], cinematic lighting, movie still aesthetic, dramatic shadows, rich colors, anamorphic lens flare, 2.39:1 aspect ratio feel, film color grading
```

### 时尚杂志风
```
A confident Asian model, [服装], [场景], high fashion photography, studio lighting, sharp details, vibrant colors, editorial style, Vogue magazine aesthetic, professional retouching look
```

### 国风古典
```
A graceful Asian woman in traditional Chinese [服装], [场景], Chinese painting aesthetic, soft natural light, elegant pose, ink wash color tones, classical beauty, artistic composition, cultural atmosphere
```

---

## 场景模板

### 咖啡馆
```
cozy cafe interior, sitting by the window, warm ambient lighting, coffee cup on wooden table, plants in background, soft morning light streaming through glass, bokeh lights
```

### 城市街道
```
urban city street, modern architecture background, golden hour sunlight, busy street with motion blur, neon signs, reflective surfaces, metropolitan atmosphere
```

### 海边
```
sandy beach at sunset, ocean waves in background, golden hour warm light, sea breeze effect on hair, horizon line, soft sand texture, coastal atmosphere
```

### 森林
```
lush green forest, dappled sunlight through leaves, natural woodland setting, moss-covered trees, soft forest floor, magical atmosphere, nature backdrop
```

### 花海
```
vast flower field, [花的种类] in full bloom, soft natural daylight, colorful petals, dreamy pastoral scene, romantic atmosphere, endless flowers stretching to horizon
```

### 室内工作室
```
professional photo studio, clean white/gray backdrop, controlled studio lighting, softbox illumination, minimalist setting, professional environment
```

### 老建筑
```
vintage architecture, old brick walls, weathered textures, historical building interior/exterior, nostalgic atmosphere, architectural details, timeless setting
```

---

## 光线模板

### 黄金时刻
```
golden hour sunlight, warm orange glow, long shadows, magical lighting, sun low on horizon, golden rim light on subject
```

### 蓝调时刻
```
blue hour lighting, soft twilight, cool blue tones, city lights beginning to glow, peaceful evening atmosphere
```

### 窗光
```
soft window light, natural daylight from side, gentle shadows, indoor natural lighting, diffused sunlight through curtains
```

### 逆光
```
backlit subject, sun behind, rim lighting effect, lens flare, silhouette edges, glowing hair, dramatic backlighting
```

### 阴天柔光
```
overcast sky lighting, soft diffused light, no harsh shadows, even illumination, cloudy day natural light, flattering portrait lighting
```

### 夜景霓虹
```
neon lights at night, colorful urban lighting, city nightscape, reflections on wet streets, vibrant artificial lights, cyberpunk atmosphere
```

---

## 服装模板

### 日常休闲
```
casual white t-shirt and jeans, simple everyday outfit, comfortable clothing, minimal accessories
```

### 连衣裙
```
flowing [颜色] dress, elegant feminine style, [材质] fabric, [长度] length, graceful movement
```

### 职业装
```
professional business attire, tailored blazer, sophisticated office wear, elegant and confident look
```

### 汉服
```
traditional Chinese Hanfu, [朝代] dynasty style, flowing silk robes, intricate embroidery, elegant traditional accessories, hair ornaments
```

### 旗袍
```
elegant Chinese Qipao/Cheongsam, [颜色] silk fabric, traditional patterns, form-fitting silhouette, classic beauty
```

### 学院风
```
preppy school uniform style, pleated skirt, white shirt, sweater vest, youthful academic look
```

---

## 组合示例

### 示例1：春日咖啡馆
```
A young Asian woman with natural makeup and gentle smile, wearing a cream-colored knit sweater and light blue jeans, sitting by a large window in a cozy cafe, holding a warm latte, soft morning sunlight streaming through the glass creating warm highlights, Japanese photography style, Fujifilm film simulation, warm pastel tones, shallow depth of field, peaceful spring morning atmosphere, 85mm portrait lens, f/1.8
```

### 示例2：都市黄昏街拍
```
A stylish Asian woman in her twenties, wearing a beige trench coat over a black turtleneck, walking through modern city streets, golden hour sunlight casting long shadows, urban architecture in background, cinematic street photography style, warm golden tones with cool shadow contrast, candid natural pose, 35mm lens perspective, metropolitan fashion editorial look
```

### 示例3：古典园林汉服
```
A graceful Asian woman wearing traditional Ming dynasty Hanfu in soft pink and white, standing in a classical Chinese garden with pavilion and lotus pond, gentle natural light filtering through willow trees, Chinese painting aesthetic, elegant poised stance, traditional hair accessories with flowers, ink wash inspired color palette, artistic composition, 85mm lens, dreamy ethereal atmosphere
```

### 示例4：海边日落
```
A beautiful Asian woman with windswept hair, wearing a flowing white linen dress, standing on sandy beach at sunset, golden hour warm light creating rim lighting effect, ocean waves softly blurring in background, romantic coastal atmosphere, film photography aesthetic, warm orange and pink sky tones, natural relaxed pose, 50mm lens, f/2.8, peaceful summer evening mood
```

### 示例5：复古书店
```
An elegant Asian woman with vintage styling, wearing a dark green velvet dress with pearl accessories, browsing books in an old library with wooden shelves, soft warm lamp light mixed with window daylight, nostalgic vintage atmosphere, Kodak Portra film colors, natural grain texture, intellectual sophisticated mood, medium format camera look, rich warm tones
```

---

## 负面提示词（避免生成）

建议在生成时排除以下元素：
```
blurry, low quality, distorted, deformed, ugly, bad anatomy, bad proportions, extra limbs, mutated, disfigured, watermark, text, logo, oversaturated, overexposed, underexposed
```

---

## 参数建议

| 场景类型 | 推荐宽高比 | 推荐尺寸 |
|----------|------------|----------|
| 公众号封面 | 16:9 | 4K |
| 竖版人像 | 3:4 | 4K |
| 方形展示 | 1:1 | 2K |
| 横版场景 | 16:9 | 4K |
| 手机壁纸 | 9:16 | 4K |
