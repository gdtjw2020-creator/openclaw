# 小梅主题 (Xiaomei)

温柔文艺风，专为情感类公众号文章设计。

## 设计理念

- 温暖但不张扬
- 文艺但不做作
- 适合深夜阅读
- 情绪感强

## Color Palette

- **主色调**: `#d4956a` - 温暖的焦糖色，用于首字、强调、分隔线
- **正文色**: `#595959` - 柔和的深灰，护眼不刺眼
- **背景色**: `#faf7f4` - 淡米色，温暖的阅读背景
- **引用背景**: `#f5f0eb` - 更深一点的米色
- **辅助色**: `#888888` - 用于次要文字

## Typography

- **正文字号**: 15px
- **行高**: 1.75
- **段落间距**: 1em
- **首行缩进**: 2em
- **首字下沉**: 2.2em，主色调

## 元素样式

### 段落
```css
font-size: 15px;
color: #595959;
line-height: 1.75;
margin: 0 0 1em 0;
text-indent: 2em;
```

### 首字下沉
```css
float: left;
font-size: 2.2em;
line-height: 1;
color: #d4956a;
margin-right: 6px;
margin-top: 4px;
```

### 分隔线
```css
text-align: center;
color: #d4956a;
letter-spacing: 0.5em;
/* 内容: ♡ */
```

### 引用块
```css
border-left: 3px solid #d4956a;
background: #faf7f4;
padding: 1em;
color: #666;
```

### 强调文字
```css
color: #d4956a;
font-weight: bold;
```

## Best Used For

情感文章、生活随笔、个人成长、两性关系、独居生活等温柔细腻的内容。
