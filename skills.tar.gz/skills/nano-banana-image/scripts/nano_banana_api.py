#!/usr/bin/env python3
"""
Real API calls for Nano Banana and Sora2
Contains the actual API integration code
"""

import os
import json
import time
import requests
import hashlib
from typing import List, Optional
from pathlib import Path
import http.client
import mimetypes
from codecs import encode


class NanoBananaAPI:
    """Nano Banana真实API调用封装"""

    def __init__(self, api_key: str, base_url: str):
        self.api_key = api_key
        self.base_url = base_url
        self.session = requests.Session()
        self.session.headers.update({
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        })

    def generate_image(self, prompt: str, width: int = 1024, height: int = 1024,
                      aspect_ratio: str = "16:9", image_size: str = "2K", 
                      reference_image_urls: List[str] = None) -> Optional[str]:
        """调用Nano Banana生成图像API，支持参考图像URL"""

        # 清理prompt中的特殊字符
        clean_prompt = prompt.replace('\u0e3f', '').replace('\xa0', ' ')
        clean_prompt = clean_prompt.replace('\n\n', '\n').replace('\r', '')
        clean_prompt = ' '.join(clean_prompt.split())

        try:
            # 构建请求数据（JSON格式）
            data = {
                "model": "nano-banana",
                "prompt": clean_prompt,
                "aspect_ratio": aspect_ratio,
                "response_format": "url"
            }

            if image_size != "1K":
                data["image_size"] = image_size
            
            # 如果有参考图像URL，添加到请求中
            if reference_image_urls and len(reference_image_urls) > 0:
                data["image"] = reference_image_urls
                print(f"\n{'='*70}")
                print(f"调用 Nano Banana 生成API (带参考图URL)")
                print(f"{'='*70}")
                print(f"参考图URL列表 (共{len(reference_image_urls)}个):")
                for i, url in enumerate(reference_image_urls):
                    print(f"  参考图{i+1}: {url}")
                print(f"{'='*70}\n")
            else:
                print(f"\n{'='*70}")
                print(f"调用 Nano Banana 生成API")
                print(f"{'='*70}")

            # 输出请求参数
            print(f"模型: {data['model']}")
            print(f"提示词: {data['prompt'][:100]}..." if len(data['prompt']) > 100 else f"提示词: {data['prompt']}")
            print(f"提示词长度: {len(data['prompt'])} 字符")
            print(f"宽高比: {data['aspect_ratio']}")
            print(f"图像尺寸: {image_size}")  # 新增：输出image_size参数
            print(f"响应格式: {data['response_format']}")
            if 'image' in data:
                print(f"参考图像数量: {len(data['image'])}")
            print(f"{'='*70}\n")

            response = self.session.post(
                f"{self.base_url}/v1/images/generations",
                json=data,
                timeout=120
            )

            if response.status_code == 200:
                result = response.json()
                if 'data' in result and len(result['data']) > 0:
                    return result['data'][0]['url']
            else:
                print(f"Nano Banana API错误: {response.status_code} - {response.text}")
                return None

        except Exception as e:
            print(f"调用Nano Banana API失败: {e}")
            return None

    def edit_image(self, image_path: str, prompt: str, aspect_ratio: str = "1:1",
                   image_size: str = "1K", reference_images: List[str] = None) -> Optional[str]:
        """调用Nano Banana编辑图像API"""

        try:
            print(f"\n{'='*70}")
            print(f"调用 Nano Banana 编辑API")
            print(f"{'='*70}")
            
            # 转换为绝对路径
            abs_image_path = str(Path(image_path).resolve())
            print(f"主图像路径: {abs_image_path}")
            print(f"主图像存在: {Path(abs_image_path).exists()}")
            
            # 准备文件列表（所有图片都使用'image'键名）
            files = []

            # 添加主图像
            with open(abs_image_path, 'rb') as f:
                image_data = f.read()
                files.append(('image', (Path(abs_image_path).name, image_data, 'image/png')))
                print(f"主图像大小: {len(image_data)} bytes")

            # 添加参考图像（所有图片都使用'image'键名）
            if reference_images:
                print(f"\n参考图像列表 (共{len(reference_images)}个):")
                for i, ref_path in enumerate(reference_images):
                    # 转换为绝对路径
                    abs_ref_path = str(Path(ref_path).resolve())
                    print(f"  参考图{i+1}:")
                    print(f"    原始路径: {ref_path}")
                    print(f"    绝对路径: {abs_ref_path}")
                    print(f"    文件存在: {Path(abs_ref_path).exists()}")
                    
                    if Path(abs_ref_path).exists():
                        with open(abs_ref_path, 'rb') as f:
                            ref_data = f.read()
                            files.append(('image', (Path(abs_ref_path).name, ref_data, 'image/png')))
                            print(f"    文件大小: {len(ref_data)} bytes")
                            print(f"    ✓ 已添加到请求")
                    else:
                        print(f"    ✗ 文件不存在，跳过")

            # 构建multipart data
            data = {
                'model': 'nano-banana',
                'prompt': prompt[:200] + '...' if len(prompt) > 200 else prompt,
                'aspect_ratio': aspect_ratio,
                'response_format': 'url'
            }

            if image_size != "1K":
                data['image_size'] = image_size

            print(f"\n请求参数:")
            print(f"  URL: {self.base_url}/v1/images/edits")
            print(f"  Model: {data['model']}")
            print(f"  Aspect Ratio: {data['aspect_ratio']}")
            print(f"  Image Size: {data.get('image_size', '1K')}")
            print(f"  Prompt长度: {len(prompt)} 字符")
            print(f"  Files数量: {len(files)} 个 (所有使用'image'键名)")
            print(f"{'='*70}\n")

            # 移除默认headers，让requests自动设置Content-Type
            headers = {'Authorization': f'Bearer {self.api_key}'}

            response = requests.post(
                f"{self.base_url}/v1/images/edits",
                data=data,
                files=files,
                headers=headers,
                timeout=120
            )

            if response.status_code == 200:
                result = response.json()
                if 'data' in result and len(result['data']) > 0:
                    return result['data'][0]['url']
            else:
                print(f"Nano Banana编辑API错误: {response.status_code} - {response.text}")
                return None

        except Exception as e:
            print(f"调用Nano Banana编辑API失败: {e}")
            return None

    def download_image(self, url: str, save_path: str) -> bool:
        """下载图像到本地，支持重试和更好的错误处理"""
        import time

        # 浏览器User-Agent，模拟正常浏览器访问
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
            'Accept': 'image/webp,image/apng,image/*,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }

        # 如果URL包含closeai.fans，添加Referer
        if 'closeai.fans' in url:
            headers['Referer'] = 'https://closeai.fans/'

        # 确保目标目录存在
        save_dir = os.path.dirname(save_path)
        if save_dir and not os.path.exists(save_dir):
            try:
                os.makedirs(save_dir, exist_ok=True)
                print(f"创建目录: {save_dir}")
            except Exception as e:
                print(f"创建目录失败: {e}")
                return False

        max_retries = 3
        for attempt in range(max_retries):
            try:
                print(f"下载图像 (尝试 {attempt + 1}/{max_retries}): {url}")

                # 使用stream=True进行流式下载，避免大文件内存溢出
                response = requests.get(
                    url,
                    headers=headers,
                    timeout=60,  # 增加超时时间
                    stream=True,
                    verify=True
                )

                if response.status_code == 200:
                    # 检查Content-Type
                    content_type = response.headers.get('content-type', '').lower()
                    if not content_type.startswith('image/'):
                        print(f"警告: 响应不是图片类型: {content_type}")

                    # 获取文件大小
                    total_size = int(response.headers.get('content-length', 0))
                    print(f"文件大小: {total_size} bytes")

                    # 流式写入文件
                    downloaded_size = 0
                    last_progress_time = time.time()
                    download_start_time = time.time()
                    last_chunk_time = time.time()
                    
                    try:
                        with open(save_path, 'wb') as f:
                            for chunk in response.iter_content(chunk_size=65536):  # 增加chunk_size
                                # 检查下载超时（如果30秒没有收到数据，超时）
                                if time.time() - last_chunk_time > 30:
                                    print(f"下载超时：30秒没有收到数据")
                                    # 删除部分文件
                                    if os.path.exists(save_path):
                                        os.remove(save_path)
                                        print(f"已删除不完整的文件: {save_path}")
                                    return False
                                
                                if chunk:
                                    f.write(chunk)
                                    downloaded_size += len(chunk)
                                    last_chunk_time = time.time()
                                    
                                    # 每秒显示一次进度
                                    current_time = time.time()
                                    if current_time - last_progress_time >= 1.0:
                                        progress = (downloaded_size / total_size * 100) if total_size > 0 else 0
                                        print(f"下载进度: {downloaded_size}/{total_size} bytes ({progress:.1f}%)")
                                        last_progress_time = current_time
                        
                        # 检查总下载时间
                        total_download_time = time.time() - download_start_time
                        if total_download_time > 300:  # 5分钟超时
                            print(f"下载总时间过长: {total_download_time:.1f}秒")
                            # 删除部分文件
                            if os.path.exists(save_path):
                                os.remove(save_path)
                                print(f"已删除不完整的文件: {save_path}")
                            return False
                        
                        # 验证文件完整性
                        if total_size > 0 and downloaded_size != total_size:
                            print(f"文件大小不匹配: 期望 {total_size} bytes, 实际 {downloaded_size} bytes")
                            # 删除不完整的文件
                            if os.path.exists(save_path):
                                os.remove(save_path)
                                print(f"已删除不完整的文件: {save_path}")
                            return False
                        
                        # 验证文件存在且非空
                        if not os.path.exists(save_path):
                            print(f"文件未成功保存: {save_path}")
                            return False
                        
                        file_size = os.path.getsize(save_path)
                        if file_size == 0:
                            print(f"文件为空: {save_path}")
                            os.remove(save_path)
                            return False

                        print(f"图像下载成功: {save_path} ({downloaded_size} bytes)")
                        return True
                        
                    except Exception as download_error:
                        print(f"下载写入文件时发生错误: {download_error}")
                        # 删除部分文件
                        if os.path.exists(save_path):
                            os.remove(save_path)
                            print(f"已删除不完整的文件: {save_path}")
                        raise  # 重新抛出异常以便外层捕获

                elif response.status_code == 404:
                    print(f"图像不存在 (404): {url}")
                    return False
                elif response.status_code == 403:
                    print(f"访问被拒绝 (403): {url}")
                    return False
                elif response.status_code == 429:
                    print(f"请求过于频繁 (429)，等待重试...")
                    time.sleep(2 ** attempt)  # 指数退避
                    continue
                else:
                    print(f"下载失败 (HTTP {response.status_code}): {url}")
                    if attempt < max_retries - 1:
                        print(f"等待 {2 ** attempt} 秒后重试...")
                        time.sleep(2 ** attempt)
                        continue
                    return False

            except requests.exceptions.Timeout:
                print(f"下载超时 (尝试 {attempt + 1}/{max_retries}): {url}")
                if attempt < max_retries - 1:
                    print(f"等待 {2 ** attempt} 秒后重试...")
                    time.sleep(2 ** attempt)
                    continue

            except requests.exceptions.ConnectionError as e:
                print(f"连接错误 (尝试 {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    print(f"等待 {2 ** attempt} 秒后重试...")
                    time.sleep(2 ** attempt)
                    continue

            except Exception as e:
                print(f"下载图像异常 (尝试 {attempt + 1}/{max_retries}): {e}")
                print(f"下载地址: {url}")
                if attempt < max_retries - 1:
                    print(f"等待 {2 ** attempt} 秒后重试...")
                    time.sleep(2 ** attempt)
                    continue

        # 所有重试都失败了
        print(f"下载失败，已重试 {max_retries} 次: {url}")
        return False
    
    def upload_file(self, file_path: str) -> Optional[str]:
        """上传文件到服务器获取URL（使用requests库，更可靠）"""
        try:
            print(f"[UPLOAD] 开始上传文件: {file_path}")
            
            # 检查文件是否存在
            if not Path(file_path).exists():
                error_msg = f"[UPLOAD] 错误：要上传的文件不存在: {file_path}"
                print(error_msg)
                raise FileNotFoundError(error_msg)
            
            # 检查文件是否可读
            if not Path(file_path).is_file():
                error_msg = f"[UPLOAD] 错误：路径不是文件: {file_path}"
                print(error_msg)
                raise ValueError(error_msg)
            
            # 检查文件大小
            file_size = Path(file_path).stat().st_size
            if file_size == 0:
                error_msg = f"[UPLOAD] 错误：文件为空: {file_path}"
                print(error_msg)
                raise ValueError(error_msg)
                
            print(f"[UPLOAD] 文件大小: {file_size} bytes")
            
            # 检查文件是否为图片格式
            import mimetypes
            mime_type, _ = mimetypes.guess_type(file_path)
            if not mime_type or not mime_type.startswith('image/'):
                error_msg = f"[UPLOAD] 错误：文件不是图片格式 (MIME: {mime_type}): {file_path}"
                print(error_msg)
                raise ValueError(error_msg)
                
            print(f"[UPLOAD] 文件MIME类型: {mime_type}")
            
            # 检查API配置
            print(f"[UPLOAD] API配置:")
            print(f"[UPLOAD]   Base URL: {self.base_url}")
            print(f"[UPLOAD]   API Key: {self.api_key[:10]}...")
            print(f"[UPLOAD]   Session headers: {dict(self.session.headers)}")
            
            # 使用requests上传文件（multipart/form-data格式）
            print(f"[UPLOAD] 准备上传到: {self.base_url}/v1/files")
            
            with open(file_path, 'rb') as f:
                # 使用标准的multipart/form-data格式
                # requests会自动设置正确的Content-Type header
                files = {
                    'file': (Path(file_path).name, f, mime_type)
                }
                
                # 创建临时headers，移除Content-Type让requests自动设置
                headers = {
                    'Authorization': f'Bearer {self.api_key}'
                }
                
                print(f"[UPLOAD] 上传文件信息:")
                print(f"[UPLOAD]   文件名: {Path(file_path).name}")
                print(f"[UPLOAD]   MIME类型: {mime_type}")
                print(f"[UPLOAD]   文件大小: {file_size} bytes")
                print(f"[UPLOAD]   请求头: {headers}")
                
                try:
                    # 使用requests.post直接上传，不使用session以避免Content-Type冲突
                    response = requests.post(
                        f"{self.base_url}/v1/files",
                        files=files,
                        headers=headers,
                        timeout=60,
                        verify=False  # 临时关闭SSL验证
                    )
                    
                    print(f"[UPLOAD] 响应状态码: {response.status_code}")
                    print(f"[UPLOAD] 响应头: {dict(response.headers)}")
                    
                    if response.status_code == 200:
                        result = response.json()
                        print(f"[UPLOAD] 响应JSON: {result}")
                        if 'url' in result and result['url']:
                            print(f"[UPLOAD] 文件上传成功，URL: {result['url']}")
                            return result['url']
                        else:
                            print(f"[UPLOAD] 上传失败：响应中没有URL - {result}")
                            return None
                    else:
                        print(f"[UPLOAD] 上传失败 (HTTP {response.status_code}): {response.text}")
                        return None
                        
                except Exception as e:
                    print(f"[UPLOAD] 上传请求失败: {e}")
                    import traceback
                    traceback.print_exc()
                    return None
                
        except FileNotFoundError:
            # 重新抛出文件不存在错误
            raise
        except ValueError:
            # 重新抛出文件验证错误
            raise
        except Exception as e:
            print(f"[UPLOAD] 上传文件异常: {e}")
            import traceback
            traceback.print_exc()
            return None


class Sora2API:
    """Sora2真实API调用封装"""

    def __init__(self, api_key: str, base_url: str):
        self.api_key = api_key
        self.base_url = base_url
        self.session = requests.Session()
        self.session.headers.update({
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        })

    def generate_video(self, prompt: str, image_path: str, aspect_ratio: str = "16:9",
                      hd: bool = False, duration: str = "10") -> Optional[str]:
        """调用Sora2生成视频API，返回task_id"""

        # 将本地图像转换为base64
        try:
            import base64
            with open(image_path, 'rb') as f:
                image_data = base64.b64encode(f.read()).decode('utf-8')
        except Exception as e:
            print(f"读取图像失败: {e}")
            return None

        data = {
            "prompt": prompt,
            "model": "sora-2",
            "images": [f"data:image/png;base64,{image_data}"],
            "aspect_ratio": aspect_ratio
        }

        if hd:
            data["hd"] = True
        if duration != "10":
            data["duration"] = duration

        try:
            # 清理prompt中的特殊字符，但保持内容完整
            clean_prompt = prompt.replace('\u0e3f', '').replace('\xa0', ' ')
            clean_prompt = clean_prompt.replace('\n\n', '\n').replace('\r', '')
            clean_prompt = ' '.join(clean_prompt.split())  # 清理多余空格但保留有意义的内容

            # 创建清理后的请求数据
            clean_data = data.copy()
            clean_data["prompt"] = clean_prompt

            response = self.session.post(
                f"{self.base_url}/v2/videos/generations",
                json=clean_data,
                timeout=60
            )

            if response.status_code == 200:
                result = response.json()
                return result.get('task_id')
            else:
                # 清理响应文本中的特殊字符
                response_text = response.text
                if isinstance(response_text, str):
                    response_text = response_text.replace('\u0e3f', '?')
                print(f"Sora2 API错误: {response.status_code} - {response_text}")
                return None

        except Exception as e:
            print(f"调用Sora2 API失败: {e}")
            import traceback
            traceback.print_exc()
            return None

    def check_task_status(self, task_id: str) -> dict:
        """检查任务状态"""
        try:
            response = self.session.get(
                f"{self.base_url}/v2/videos/generations/{task_id}",
                timeout=30
            )

            if response.status_code == 200:
                return response.json()
            else:
                print(f"检查任务状态失败: {response.status_code}")
                return {}

        except Exception as e:
            print(f"检查任务状态异常: {e}")
            return {}

    def wait_for_completion(self, task_id: str, max_wait_time: int = 600,
                           check_interval: int = 10) -> Optional[str]:
        """等待视频生成完成，返回视频URL"""

        start_time = time.time()

        while time.time() - start_time < max_wait_time:
            status_data = self.check_task_status(task_id)

            if not status_data:
                time.sleep(check_interval)
                continue

            status = status_data.get('status')
            progress = status_data.get('progress', '0%')

            print(f"任务 {task_id} 状态: {status}, 进度: {progress}")

            if status == 'SUCCESS':
                data = status_data.get('data', {})
                return data.get('output')
            elif status == 'FAILURE':
                fail_reason = status_data.get('fail_reason', '未知错误')
                print(f"视频生成失败: {fail_reason}")
                return None
            elif status == 'NOT_START':
                pass  # 继续等待
            elif status == 'IN_PROGRESS':
                pass  # 继续等待

            time.sleep(check_interval)

        print(f"等待超时，任务可能仍在处理中: {task_id}")
        return None

    def download_video(self, url: str, save_path: str) -> bool:
        """下载视频到本地，支持重试和更好的错误处理"""
        import time

        # 浏览器User-Agent，模拟正常浏览器访问
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
            'Accept': 'video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }

        # 如果URL包含closeai.fans，添加Referer
        if 'closeai.fans' in url:
            headers['Referer'] = 'https://closeai.fans/'

        max_retries = 3
        for attempt in range(max_retries):
            try:
                print(f"下载视频 (尝试 {attempt + 1}/{max_retries}): {url}")

                # 使用stream=True进行流式下载，避免大文件内存溢出
                response = requests.get(
                    url,
                    headers=headers,
                    timeout=120,  # 视频下载需要更长的超时时间
                    stream=True,
                    verify=True
                )

                if response.status_code == 200:
                    # 检查Content-Type
                    content_type = response.headers.get('content-type', '').lower()
                    if not content_type.startswith('video/'):
                        print(f"警告: 响应不是视频类型: {content_type}")

                    # 获取文件大小
                    total_size = int(response.headers.get('content-length', 0))
                    print(f"文件大小: {total_size} bytes")

                    # 流式写入文件
                    downloaded_size = 0
                    with open(save_path, 'wb') as f:
                        for chunk in response.iter_content(chunk_size=8192):
                            if chunk:
                                f.write(chunk)
                                downloaded_size += len(chunk)

                    print(f"视频下载成功: {save_path} ({downloaded_size} bytes)")
                    return True

                elif response.status_code == 404:
                    print(f"视频不存在 (404): {url}")
                    return False
                elif response.status_code == 403:
                    print(f"访问被拒绝 (403): {url}")
                    return False
                elif response.status_code == 429:
                    print(f"请求过于频繁 (429)，等待重试...")
                    time.sleep(2 ** attempt)  # 指数退避
                    continue
                else:
                    print(f"下载失败 (HTTP {response.status_code}): {url}")
                    if attempt < max_retries - 1:
                        print(f"等待 {2 ** attempt} 秒后重试...")
                        time.sleep(2 ** attempt)
                        continue
                    return False

            except requests.exceptions.Timeout:
                print(f"下载超时 (尝试 {attempt + 1}/{max_retries}): {url}")
                if attempt < max_retries - 1:
                    print(f"等待 {2 ** attempt} 秒后重试...")
                    time.sleep(2 ** attempt)
                    continue

            except requests.exceptions.ConnectionError as e:
                print(f"连接错误 (尝试 {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    print(f"等待 {2 ** attempt} 秒后重试...")
                    time.sleep(2 ** attempt)
                    continue

            except Exception as e:
                print(f"下载视频异常 (尝试 {attempt + 1}/{max_retries}): {e}")
                print(f"下载地址: {url}")
                if attempt < max_retries - 1:
                    print(f"等待 {2 ** attempt} 秒后重试...")
                    time.sleep(2 ** attempt)
                    continue

        # 所有重试都失败了
        print(f"下载失败，已重试 {max_retries} 次: {url}")
        return False


def get_aspect_ratio(width: int, height: int) -> str:
    """根据宽高获取aspect_ratio字符串"""
    # aspect_ratios = {
    #     (1024, 1536): "3:4", (1536, 1024): "4:3",
    #     (1536, 864): "16:9", (864, 1536): "9:16",
    #     (1024, 1024): "1:1", (1536, 1536): "1:1",
    #     (1920, 1080): "16:9", (1080, 1920): "9:16"
    # }
    # return aspect_ratios.get((width, height), "16:9")
    return "16:9"


def get_image_size(width: int, height: int) -> str:
    """根据分辨率获取image_size字符串"""
    # max_dimension = max(width, height)
    # if max_dimension >= 4096:
    #     return "4K"
    # elif max_dimension >= 2048:
    #     return "2K"
    # else:
    #     return "1K"
    return "2K"


# 使用示例
if __name__ == "__main__":
    # API配置
    BANANA2_API_KEY = "sk-scRRxuA917CXN0CZUkaMsmhkeOtzrSgszBuyM8J0UcLBpM3a"
    SORA2_API_KEY = "sk-scRRxuA917CXN0CZUkaMsmhkeOtzrSgszBuyM8J0UcLBpM3a"
    BASE_URL = "https://ai.t8star.cn"

    # 测试图像生成
    banana_api = NanoBananaAPI(BANANA2_API_KEY, BASE_URL)

    prompt = "动漫风格的可爱猫咪，日系画风，高清细节"
    image_url = banana_api.generate_image(prompt, width=1024, height=1024)

    if image_url:
        print(f"图像生成成功: {image_url}")

        # 下载图像
        save_path = "test_image.png"
        if banana_api.download_image(image_url, save_path):
            print(f"图像已下载: {save_path}")

            # 测试视频生成
            sora_api = Sora2API(SORA2_API_KEY, BASE_URL)

            video_prompt = "猫咪在阳光下打哈欠，自然光线，温暖氛围"
            task_id = sora_api.generate_video(video_prompt, save_path, aspect_ratio="1:1")

            if task_id:
                print(f"视频生成任务已提交: {task_id}")

                # 等待完成
                video_url = sora_api.wait_for_completion(task_id)
                if video_url:
                    print(f"视频生成成功: {video_url}")

                    # 下载视频
                    video_save_path = "test_video.mp4"
                    if sora_api.download_video(video_url, video_save_path):
                        print(f"视频已下载: {video_save_path}")
                else:
                    print("视频生成失败")
            else:
                print("提交视频生成任务失败")
        else:
            print("图像下载失败")
    else:
        print("图像生成失败")