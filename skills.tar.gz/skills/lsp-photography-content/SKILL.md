---
name: lsp-photography-content
description: LSP摄影创作技能包。专业人像摄影图文内容创作，用于创建高质量的美女摄影公众号图文内容，支持完整的自动化流程：(1) 创建工作目录 (2) 选题策划与创意构思 (3) AI图像生成 (4) 专业摄影文案撰写 (5) 内容审核 (6) 调用美化skill生成HTML (7) 调用发布skill发布到公众号草稿箱。当需要LSP摄影创作、人像摄影、时尚写真、艺术人像等公众号内容时触发此技能。
---

# LSP Photography Content

LSP摄影创作 - 专业美女摄影公众号图文内容创作技能包。

## ⚠️ 重要：创作前必读

**核心定位**：美女摄影作品创作，风格不要大调整，保持一致性。

**创作原则**：
1. 每次创作前，检查近期创作记录，避免主题重复
2. 保持美女摄影的核心风格
3. 可以有新尝试，但不要偏离主题太远

## 完整工作流程

```
检查近期记录 → 确定选题 → 【用户确认】→ 创建工作目录 → AI生成图片 → 撰写文案 → 内容审核 → 美化排版 → 发布草稿
```

**⚠️ 注意：选题确定后必须等待用户确认，才能继续后续步骤！**

## Step 0: 检查近期创作记录（防止重复！）

**每次创作前，必须先检查 lsp-works/ 目录下近7天的创作记录：**

```powershell
# 列出近期创作目录
Get-ChildItem -Path "lsp-works" -Directory | Where-Object { $_.Name -match "^\d{4}-\d{2}-\d{2}$" } | Sort-Object Name -Descending | Select-Object -First 7
```

**① 主题防重复（严格！）**：

1. 读取近7天的工作目录，提取已创作的主题名称
2. **不仅检查名称是否相同，还要检查语义是否相似**
3. 以下情况视为重复，必须换方向：
   - 相同场景：温泉/私汤/泡池 都算温泉类
   - 相同季节+场景：冬日温泉 ≈ 冬日私汤 ≈ 雪景泡池
   - 相同服装+场景：海边比基尼 ≈ 沙滩泳装 ≈ 海滩bikini

**② 场景分类参考（同类视为重复）**：

| 场景类别 | 包含的关键词 |
|----------|-------------|
| 温泉类 | 温泉、私汤、泡池、汤池、露天风吕 |
| 海边类 | 海边、沙滩、海滩、海岸、礁石 |
| 泳池类 | 泳池、游泳池、无边泳池、天台泳池 |
| 室内私房 | 私房、卧室、酒店、民宿、浴室 |
| 都市户外 | 天台、街拍、咖啡馆、商场、写字楼 |
| 自然户外 | 森林、草地、花海、田野、山野 |

**同一天内，同一场景类别只能创作一次！**

## Step 1: 创建工作目录

每次创作前，先创建工作目录：

**目录结构**：
```
lsp-works/
└── [日期]/              # 日期目录
    └── [主题名]/         # 作品主题目录
        ├── images/          # 存放生成的图片
        ├── prompts.json     # 图片生成提示词记录
        ├── creative_brief.json  # 创作方案记录
        ├── article.md       # Markdown文章
        ├── article_wechat.html  # 美化后的HTML
        ├── cover.png        # 封面图
        └── publish_info.json    # 发布信息
```

**创建命令**（由AI自动执行）：
```bash
$date = Get-Date -Format "yyyy-MM-dd"
$theme = "[主题名]"
$workDir = "lsp-works/$date/$theme"
New-Item -ItemType Directory -Path "$workDir/images" -Force
```

## Step 2: 选题策划

### 热门选题方向

| 类型 | 示例主题 | 适合季节 |
|------|----------|----------|
| 光影艺术 | 金色时刻人像、逆光剪影、室内自然光 | 全年 |
| 场景主题 | 都市街拍、咖啡馆写真、海边旅拍 | 按场景 |
| 风格流派 | 日系清新、复古胶片、电影感人像 | 全年 |
| 服装搭配 | 汉服写真、JK制服、轻礼服 | 全年 |
| 节日特辑 | 春日樱花、秋日银杏、圣诞氛围 | 对应季节 |

### 选题输出格式

```json
{
  "theme": "冬日咖啡馆人像",
  "style": "日系清新",
  "target_audience": "摄影爱好者",
  "key_points": ["温暖氛围", "自然光运用", "生活气息"],
  "image_count": 5,
  "cover_ratio": "16:9",
  "content_ratio": "3:4"
}
```

### ⚠️ 用户确认选题（必须执行！）

**在确定创作方向后，必须等待用户确认才能继续后续步骤！**

**展示格式示例：**
```
📋 创作选题确认

主题：[主题名称]
风格：[风格类型]
场景：[场景描述]
图片数量：[数量]

请确认是否继续此方向？
- 输入"确认"或"可以"继续创作
- 输入修改意见，我会调整方向
```

**未经用户确认，禁止进入 Step 3 及后续步骤！**

## Step 3: AI图像生成

### 图片生成工具（按优先级）

**⚠️ 优先使用 ComfyUI，效果最专业且完全免费！**

| 优先级 | 工具 | 说明 |
|--------|------|------|
| 🥇 1 | **mcp_comfyui_comfyui_generate_image** | 推荐！使用本地ComfyUI生成 |
| 🥈 2 | **runninghub-text-image-gen** | 备选，基于参考图+提示词 |
| 🥉 3 | gemini-image-generator | 免费，使用 Gemini Advanced |
| 4 | nano-banana | 付费，效果好 |

### 🥇 优先方案：ComfyUI 图像生成
\n**可用性检查：**

在开始生成前，先检查ComfyUI服务是否可用：

```bash
# 检查ComfyUI服务状态
if curl -s http://localhost:8188 > /dev/null; then
    echo "✅ ComfyUI可用，使用ComfyUI生成（速度快）"
    # 使用ComfyUI生成
else
    echo "⚠️ ComfyUI不可用，使用RunningHub"
    # 使用RunningHub生成
fi
```

**推荐理由：**
- ⚡ 速度快：ComfyUI本地生成，约10-15秒/张
- 💰 完全免费：无需API费用
- 🎨 质量优秀：Flux2-Klein模型输出专业级质量



**调用方式**：
```bash
mcp_comfyui_comfyui_generate_image(
    prompt="A young Asian woman, walking on the beach, sunset, detailed face, 4k",
    width=720,
    height=1280,
    filename_prefix="portrait_shoot"
)
```

**提示词编写要点**：
- **画质增强后缀（重要！）**：末尾添加 `, 8K, 4K, 增加细节`
- **结构**：`参考这张图片，[画面描述]。8K, 4K, 增加细节`

### 🥈 备选方案：RunningHub 图像生成 (支持修图)

当需要基于参考图生成（修图）或 ComfyUI 不可用时，使用 RunningHub。

**调用方式**：
```bash
python skills/runninghub-text-image-gen/scripts/text_image_gen.py \
  --prompt "[提示词]" \
  --image "images/01.png" \
  --upload
```

**参数说明**：
- `--prompt` / `-p`: 提示词
- `--image` / `-i`: 参考图片路径（可以是本地刚生成的图片，用于迭代修改）
- `--upload`: 如果使用本地图片作为参考，必须加此参数
- **注意**：需要环境变量 `RUNNINGHUB_API_KEY`

### 图片数量与比例

**推荐配置**：
- **图片数量**：8-10张（1封面 + 7-9内容图）
- **封面比例**：16:9
- **内容比例**：9:16（竖图为主，视觉冲击力强）

**比例混搭示例**（10张图）：
```
图1-8: 9:16 竖图 - 全身、半身、特写、背影等
图9: 1:1 方图 - 节奏变化
图10: 4:3 横图 - 场景感
```

### 多视角拍摄

| 视角 | 提示词 | 效果 |
|------|--------|------|
| 全身 | full body shot | 身材、服装 |
| 半身 | medium shot | 常规人像 |
| 特写 | close up | 表情、细节 |
| 背影 | from behind | 神秘、曲线 |
| 侧面 | side view | 轮廓、光影 |
| 俯拍 | high angle | 可爱感 |
| 仰拍 | low angle | 气场、腿长 |

### 保存提示词记录

**每次生成图片后，必须保存提示词到 `prompts.json`**：

```json
{
  "created_at": "[当前日期]",
  "theme": "[本次创作主题]",
  "cover": {
    "file": "cover.png",
    "prompt": "[封面图提示词]",
    "aspect_ratio": "16:9"
  },
  "images": [
    {
      "file": "images/01.png",
      "prompt": "[图片1提示词]",
      "aspect_ratio": "9:16",
      "shot_type": "全身"
    }
  ],
  "generation_tool": {
    "name": "comfyui",
    "quality": "4K"
  }
}
```

## Step 4: 文案撰写

### ⚠️ 文案核心原则

**用户来看什么？** 看美女、看氛围、找情绪共鸣，不是来学摄影的！

**文案目标**：
- 🎯 **制造情绪** - 让读者有代入感、有向往
- 🎯 **引发想象** - 留白比说透更有吸引力
- 🎯 **轻松阅读** - 短句、有节奏、不说教

**绝对避免**：
- ❌ 摄影教程式写法（场景选择、光线运用、构图技巧）
- ❌ 拍摄参数表格（相机、镜头、光圈、ISO）
- ❌ 后期调色思路
- ❌ 长篇大论的技术分析

### 文章模板：情绪散文风（推荐）

**⚠️ 注意：内容中不要写标题（# xxx），标题在发布时单独设置！**

**字数要求**：
- 总字数：500-800 字（不含图片标记）
- 每张图配文：80-120 字

```markdown
[开篇：一句话情绪定调，制造氛围，20-30字]

![](images/01.png)

[第一段：3-5句氛围描写。用感官词汇描述场景。80-120字]

![](images/02.png)

[第二段：情绪深入。内心独白、联想、回忆。80-120字]

![](images/03.png)

[第三段：换个角度，聚焦细节。加入故事感。80-120字]

![](images/04.png)

[第四段：情绪高潮或转折。更私密、更深入。80-120字]

![](images/05.png)

[第五段：情绪收束。感悟、留白、或开放式结尾。50-80字]

[结尾：一句话点题或引发共鸣，用疑问句让读者代入。20-30字]

---
```

### 文案写作技巧

**1. 开头抓人**
- ❌ "今天给大家分享一组XX人像"
- ✅ 用场景/感官/情绪开头，直接带入氛围

**2. 用感官词汇**
- 触觉：温热、冰凉、丝滑
- 视觉：朦胧、透亮、斑驳
- 听觉：安静、呢喃、沉默

**3. 短句制造节奏**
- ❌ "她站在温泉池边，雾气缭绕在她的周围"
- ✅ "雾气缭绕。阳光落在肩上。她没有说话。"

**4. 留白比说透好**
- ❌ "这组照片想表达的是冬日的温暖与孤独的对比"
- ✅ "有些温暖，只有在寒冷中才能被感知"

**5. 结尾引发共鸣**
- 用疑问句："你有多久没有..."
- 用感叹句："原来..."
- 用省略号："也许..."

### 标题公式

**高互动标题要素**：
- 情绪词：炸裂、绝美、心动、上头
- 具体词：4K、温泉、比基尼、雪景
- 悬念词：这、那个、居然、原来

**标题模板**：
- `[场景]：[情绪化描述]`
- `[情绪词]！[具体描述]`
- `[疑问/悬念]`

## Step 5: 内容审核

### 审核清单

**图像审核**：
- [ ] 着装得体，无暴露
- [ ] 姿态自然，无不当暗示
- [ ] 图像质量清晰

**文案审核**：
- [ ] 无低俗用语
- [ ] 无虚假宣传
- [ ] 符合平台规范

### 创建发布信息

在工作目录创建 `publish_info.json`：
```json
{
  "title": "冬日咖啡馆，那些被阳光温柔以待的温暖瞬间",
  "author": "摄影工作室",
  "digest": "午后三点，咖啡馆里弥漫着温暖的光线...",
  "theme": "elegant",
  "ai_generated": true,
  "cover": "cover.png",
  "article": "article.md"
}
```

## Step 6: 调用美化Skill

审核通过后，调用 `wechat-article-beautifier` skill 美化文章：

```bash
node skills/wechat-article-beautifier/scripts/beautify.js "lsp-works/[日期]/[主题]/article.md" --theme elegant --output "lsp-works/[日期]/[主题]/article_wechat.html"
```

**可用主题**：
- `elegant` - 文艺清新（推荐人像摄影）
- `default` - 简洁大方
- `vibrant` - 活泼明亮

## Step 7: 调用发布Skill
\n### ⚠️ 首次发布前配置

**微信公众号IP白名单设置：**

1. 登录微信公众号后台
2. 进入"开发" → "基本配置"
3. 找到"IP白名单"设置
4. 添加服务器IP：`113.88.95.116`
5. 保存更改

**⚠️ 不配置IP白名单会导致发布失败！**

错误示例：
```
❌ 获取 access_token 失败: {"errcode": 40164, "errmsg": "invalid ip 113.88.95.116, not in whitelist"}
```



美化完成后，调用 `wechat-draft-publisher` skill 发布到草稿箱：

```bash
python skills/wechat-draft-publisher/scripts/publish_to_draft.py \
  --title "[文章标题]" \
  --content "lsp-works/[日期]/[主题]/article_wechat.html" \
  --cover "lsp-works/[日期]/[主题]/cover.png" \
  --author "[作者名]" \
  --digest "[摘要]" \
  --ai-generated
```

## 一键创作命令

**快速创作**（告诉AI以下信息即可自动执行全流程）：

```
创作人像摄影图文：
主题：[主题名称]
风格：[日系清新/复古胶片/都市街拍/...]
图片数量：[8-10张]
发布：[是/否]
```

**示例**：
```
创作人像摄影图文：
主题：春日樱花人像
风格：日系清新
图片数量：10张
发布：是
```

## 注意事项

1. **图片路径**：文章中的图片使用相对路径 `images/01.png`
2. **封面图**：建议使用16:9比例
3. **内容审核**：AI生成的图片需要人工确认无违规内容
4. **发布确认**：默认只保存到草稿箱，需要在公众号后台确认发布

## References

- **选题灵感库**: See [references/topic-ideas.md](references/topic-ideas.md)
- **提示词模板库**: See [references/prompt-templates.md](references/prompt-templates.md)
- **文案范例库**: See [references/article-examples.md](references/article-examples.md)

## Step 6.5: 文末广告插入（可选）

### 使用场景

当用户需要在文章末尾添加推广内容时（如推广AI助理系统、课程、产品等）。

### 广告模板

**标准广告格式：**

```markdown
---

## 👨‍💻 作者有话说

这一期的修图/文案其实有不少我的 AI 数字员工辅助完成的。

最近我在 AWS 上部署了一套 OpenClaw 智能助理系统，不仅能帮我跑图，还能 24 小时帮我接待客户、自动回消息（防封号、秒回）。

如果你也想搭建一套这样**"真正能干活"**的 AI 系统（做外贸、做私域都行），可以加我微信交流。

👇 扫码备注【AI】，围观我的自动赚钱机器 👇
![](images/qr_code.jpg)
```

### 执行步骤

**1. 确认广告需求**
```
"需要在文末添加广告吗？如需二维码请发送图片。"
```

**2. 接收二维码**
- 用户发送二维码图片
- 保存到 `images/qr_code.jpg`
- 复制命令：
  ```bash
  cp /root/.openclaw/media/inbound/[xxx].jpg \
     lsp-works/[日期]/[主题]/images/qr_code.jpg
  ```

**3. 更新article.md**
```bash
# 在文件末尾追加广告内容
cat >> lsp-works/[日期]/[主题]/article.md << 'AD_EOF'

---

## 👨‍💻 作者有话说

[广告内容...]

👇 扫码备注【AI】，围观我的自动赚钱机器 👇
![](images/qr_code.jpg)
AD_EOF
```

**4. 更新HTML文件**
- 方式A：手动编辑HTML，在`</div></body></html>`前添加广告模块
- 方式B：重新执行美化（如果有广告专用模板）

**5. 验证文件**
```bash
grep -q "作者有话说" article.md && echo "✅ Markdown已更新"
grep -q "qr_code.jpg" article_wechat.html && echo "✅ HTML已更新"
```

### HTML广告模块样式参考

```html
<div class="author-note">
  <h3>👨‍💻 作者有话说</h3>
  <p>这一期的修图/文案其实有不少我的 AI 数字员工辅助完成的。</p>
  <p>最近我在 AWS 上部署了一套 <strong>OpenClaw 智能助理系统</strong>，不仅能帮我跑图，还能 24 小时帮我接待客户、自动回消息（防封号、秒回）。</p>
  <p>如果你也想搭建一套这样<strong>"真正能干活"</strong>的 AI 系统（做外贸、做私域都行），可以加我微信交流。</p>
</div>

<div class="cta-box">
  <p><strong>👇 扫码备注【AI】，围观我的自动赚钱机器 👇</strong></p>
  <img src="images/qr_code.jpg" alt="微信二维码" style="max-width: 200px; margin: 20px auto; display: block; border-radius: 4px;"/>
</div>
```

**CSS样式：**
```css
.author-note {
  background: #f8f9fa;
  border-left: 4px solid #3498db;
  padding: 20px;
  margin: 30px 0;
  border-radius: 6px;
}
.cta-box {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 25px;
  border-radius: 8px;
  text-align: center;
  margin: 30px 0;
}
```

## Step 3.5: 补充图片生成（可选）

### 使用场景

当用户需要更多图片选择时（如从10张扩展到20张），可以补充生成。

### 执行步骤

**1. 确认补充数量**
```
"需要补充多少张图片？（建议10张）"
```

**2. 设计差异化提示词**
- 改变拍摄角度（仰拍/俯拍/侧拍）
- 改变姿态动作（伸展/蹲姿/转身）
- 改变情绪氛围（活泼/静谧/性感）
- 改变构图方式（特写/全身/远景）

**3. 生成补充图片**
```bash
# 使用RunningHub或ComfyUI生成
# 保存时递增编号
# 如：原有01-10.png，补充11-20.png
```

**4. 供用户挑选**
```
"补充图片生成完成！共20张供你挑选。
请删除不需要的图片，保留最终选中的图片。"
```

**5. 重新统计图片数量**
```bash
ls -1 images/*.png | wc -l
```

### 提示词变体示例

**原有：** "Medium shot of woman standing in snow"
**补充变体：**
- "Full body shot of woman stretching arms in snow"（全身伸展）
- "Low angle shot of woman crouching in snow"（低角度蹲姿）
- "Close-up of woman's hand touching snow-covered branch"（手部特写）
- "Back view of woman walking away in snow"（背影行走）

