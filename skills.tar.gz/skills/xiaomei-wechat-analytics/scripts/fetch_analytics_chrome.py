#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
微信公众号文章数据获取脚本（Chrome DevTools版本）
通过 Chrome DevTools 抓取公众号后台数据，支持账号验证
"""

import json
import sys
import io
from datetime import datetime
from pathlib import Path

# 设置 Windows 命令行编码
if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

# 数据存储路径
ANALYTICS_DIR = Path("works/analytics")
ARTICLES_FILE = ANALYTICS_DIR / "articles.json"
ARCHIVE_FILE = ANALYTICS_DIR / "articles_archive.json"
CONFIG_FILE = ANALYTICS_DIR / "config.json"

# 小梅的公众号名称（用于账号验证）
XIAOMEI_ACCOUNT_NAME = "小梅的深夜随笔"


def load_config():
    """加载配置"""
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {
        "account_name": XIAOMEI_ACCOUNT_NAME,
        "last_checked_account": None,
        "last_verified_time": None,
    }


def save_config(config):
    """保存配置"""
    ANALYTICS_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=2)


def verify_account_name(account_name):
    """验证公众号名称是否正确

    Args:
        account_name: 当前登录的公众号名称

    Returns:
        (is_valid, message): 是否有效和提示信息
    """
    if not account_name:
        return False, "❌ 无法获取公众号名称，请确保已登录公众号后台"

    if account_name == XIAOMEI_ACCOUNT_NAME:
        return True, f"✅ 账号验证通过：{account_name}"
    else:
        return (
            False,
            f"❌ 账号验证失败！\n   当前登录的公众号：{account_name}\n   预期账号：{XIAOMEI_ACCOUNT_NAME}\n   请确保登录的是小梅的公众号，避免分析错误账号的数据！",
        )


def check_current_account(snapshot):
    """从快照中获取当前公众号名称

    Args:
        snapshot: Chrome DevTools 页面快照

    Returns:
        str: 公众号名称，如果无法获取则返回 None
    """
    # 尝试从页面标题获取
    try:
        # 公众号后台首页标题通常包含公众号名称
        # 格式可能是 "公众号名称 | 公众号平台" 或类似格式
        for element in snapshot:
            if element.get("type") == "text" or element.get("role") == "heading":
                text = element.get("value", "")
                if XIAOMEI_ACCOUNT_NAME in text:
                    return XIAOMEI_ACCOUNT_NAME
    except Exception as e:
        print(f"⚠️  从快照获取公众号名称时出错：{e}")

    return None


def load_existing_articles():
    """加载现有文章数据"""
    if ARTICLES_FILE.exists():
        with open(ARTICLES_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"articles": [], "last_updated": None}


def save_articles(data):
    """保存文章数据"""
    ANALYTICS_DIR.mkdir(parents=True, exist_ok=True)
    data["last_updated"] = datetime.now().isoformat()
    with open(ARTICLES_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"✅ 数据已保存到 {ARTICLES_FILE}")


def archive_articles(articles):
    """归档历史文章数据"""
    archive = {"articles": [], "archived_at": None}
    if ARCHIVE_FILE.exists():
        with open(ARCHIVE_FILE, "r", encoding="utf-8") as f:
            archive = json.load(f)

    existing_ids = {a.get("article_id") for a in archive["articles"]}
    for article in articles:
        if article.get("article_id") not in existing_ids:
            archive["articles"].append(article)

    archive["archived_at"] = datetime.now().isoformat()
    with open(ARCHIVE_FILE, "w", encoding="utf-8") as f:
        json.dump(archive, f, ensure_ascii=False, indent=2)


def get_instructions():
    """获取使用说明"""
    return f"""
# 微信公众号数据抓取指南

## ⚠️ 重要：账号验证

为了确保分析的是小梅的公众号数据，系统会验证当前登录的账号是否正确。

**小梅的公众号名称**：{XIAOMEI_ACCOUNT_NAME}

## 📋 操作步骤

### 方法 1：通过 MCP 工具直接抓取（推荐）

1. 打开 Chrome 浏览器，访问：https://mp.weixin.qq.com/
2. 登录公众号后台（扫码或账号密码）
3. 使用以下 MCP 工具进行操作：
   - `chrome-devtools_take_snapshot` - 查看页面当前状态
   - `chrome-devtools_navigate_page` - 导航到指定页面
   - 从页面中抓取文章数据

### 方法 2：手动抓取

1. 登录公众号后台
2. 在首页"近期发表"区域可看到最近文章数据
3. 点击"全部发表记录"查看更多历史数据
4. 手动复制数据到本地的 JSON 文件

## 🔍 账号验证方法

系统会自动检查当前登录的公众号名称，确保是：
- ✅ {XIAOMEI_ACCOUNT_NAME}

如果验证失败，请：
1. 确认登录的是正确的公众号
2. 如果需要切换账号，请先退出当前账号
3. 使用正确的账号重新登录

## 📊 数据存储位置

- 文章数据：{ARTICLES_FILE}
- 历史归档：{ARCHIVE_FILE}
- 配置文件：{CONFIG_FILE}

## ⚙️ 配置说明

配置文件（config.json）记录以下信息：
- `account_name`: 预期的公众号名称
- `last_checked_account`: 上次验证的账号
- `last_verified_time`: 上次验证时间

## 🚨 注意事项

1. **必须验证账号**：在抓取数据前，务必确认当前登录的是小梅的公众号
2. **数据时效性**：数据统计有 1-3 天延迟
3. **隐私保护**：不要将数据文件提交到 Git
4. **定期归档**：建议定期运行归档操作
"""


def print_verification_guide():
    """打印账号验证指南"""
    print("\n" + "=" * 60)
    print("🔐 账号验证说明")
    print("=" * 60)
    print(f"\n本技能会自动验证当前登录的公众号是否为小梅的账号")
    print(f"\n✅ 正确的公众号名称：{XIAOMEI_ACCOUNT_NAME}")
    print(f"\n🚨 如果验证失败，请确保：")
    print(f"   1. 已登录正确的公众号")
    print(f"   2. 当前页面在公众号后台")
    print(f"   3. 账号名称完全匹配")
    print(f"\n💡 这是为了避免错误分析其他账号的数据")
    print("=" * 60 + "\n")


if __name__ == "__main__":
    print(get_instructions())
    print("\n" + "=" * 60)
    print_verification_guide()
