# 账号验证快速参考

## 目标账号

**公众号名称**：`小梅的深夜随笔`

## 验证方法

### 方法 1：使用 MCP 工具验证（推荐）

1. **导航到公众号后台**
   ```
   chrome-devtools_navigate_page
   {
     "type": "url",
     "url": "https://mp.weixin.qq.com/"
   }
   ```

2. **获取页面快照**
   ```
   chrome-devtools_take_snapshot
   ```

3. **检查账号名称**
   - 在快照中查找 `小梅的深夜随笔`
   - 如果找到 → 验证通过
   - 如果未找到 → 验证失败，需要切换账号

### 方法 2：手动验证

1. 访问 https://mp.weixin.qq.com/
2. 查看页面顶部或标题栏
3. 确认显示的是"小梅的深夜随笔"

## 验证失败处理

如果验证失败，请：

1. 退出当前公众号账号
2. 重新登录正确的公众号（小梅的深夜随笔）
3. 刷新页面
4. 重新验证

## Python 脚本验证

```bash
python .opencode/skill/wechat-analytics/scripts/verify_account.py
```

## 配置文件位置

```
works/analytics/config.json
```

## 重要提示

⚠️ **在分析数据前必须验证账号**，避免错误分析其他公众号的数据！