/**
 * WeChat Message Autoreply Logic
 * 微信公众号回复自动化脚本
 * 
 * Capability:
 * 1. Batch reply to recent articles
 * 2. Anti-duplicate mechanism
 * 3. Advanced human-like interaction (Pointer Events)
 * 4. Context-aware single reply
 */

/**
 * 高级拟人化点击 (Advanced Human-Like Click)
 * 模拟完整的鼠标事件链 (Pointer -> Mouse -> Click) 以绕过 React/Vue 等框架的事件过滤
 */
function simulateHumanClick(element) {
    const options = {
        bubbles: true, cancelable: true, view: window,
        buttons: 1, pointerId: 1, width: 1, height: 1, pressure: 0.5, isPrimary: true
    };
    const steps = [
        new PointerEvent('pointerover', options),
        new MouseEvent('mouseover', options),
        new PointerEvent('pointerdown', options),
        new MouseEvent('mousedown', options),
        new PointerEvent('pointerup', options),
        new MouseEvent('mouseup', options),
        new PointerEvent('click', options)
    ];
    steps.forEach(evt => element.dispatchEvent(evt));
    element.click(); // Fallback for standard listeners
}

/**
 * 自动回复单条留言（强化版）
 * 包含对 Portal 弹窗内“确定/发送”按钮的深度搜索
 * @param {Element} commentItem 留言项 DOM 元素
 * @param {string} replyText 回复内容
 */
async function _replySingleItem(commentItem, replyText) {
    if (commentItem.innerText.includes("作者回复") || commentItem.querySelector('.reply_content')) {
        return "SKIPPED_ALREADY_REPLIED";
    }

    commentItem.scrollIntoView({ behavior: "instant", block: "center" });
    await new Promise(r => setTimeout(r, 500));

    const replyLink = commentItem.querySelector('a[title="回复"]');
    if (!replyLink) return "ERROR_NO_REPLY_BTN";

    simulateHumanClick(replyLink);

    let input = null;
    let editor = null;
    for (let i = 0; i < 30; i++) {
        const visibleEditors = Array.from(document.querySelectorAll('.emotion_editor')).filter(e => e.offsetParent !== null);
        if (visibleEditors.length > 0) {
            editor = visibleEditors[0];
            input = editor.querySelector('div[contenteditable="true"]');
            if (input) break;
        }
        await new Promise(r => setTimeout(r, 200));
    }

    if (!input) return "ERROR_INPUT_TIMEOUT";

    input.focus();
    await new Promise(r => setTimeout(r, 300));
    document.execCommand('selectAll', false, null);
    document.execCommand('insertText', false, replyText);

    ['input', 'change', 'blur'].forEach(name => {
        input.dispatchEvent(new Event(name, { bubbles: true }));
    });

    await new Promise(r => setTimeout(r, 800));

    let submitBtn = null;
    const dialog = editor.closest('.weui-desktop-dialog') || document.body;

    const allBtns = dialog.querySelectorAll('button, .weui-desktop-btn');
    for (let btn of allBtns) {
        if (btn.offsetParent === null) continue;
        const txt = btn.innerText.trim();
        if (txt === "确定" || txt === "发送" || txt === "回复") {
            if (btn.classList.contains('weui-desktop-btn_primary') || btn.tagName === "BUTTON") {
                submitBtn = btn;
                break;
            }
        }
    }

    if (!submitBtn) return "ERROR_SUBMIT_BTN_NOT_FOUND";
    if (submitBtn.classList.contains('weui-desktop-btn_disabled')) return "ERROR_SUBMIT_BTN_DISABLED";

    simulateHumanClick(submitBtn);

    await new Promise(r => setTimeout(r, 2000));
    const success = editor.offsetParent === null || commentItem.innerText.includes(replyText);
    return success ? "SUCCESS" : "WARNING_UNVERIFIED";
}

/**
 * 智能读取未回复留言，供 AI 生成更有温度的回复
 */
async function fetchUnrepliedComments() {
    const items = document.querySelectorAll('.comment-list__item');
    const pending = [];
    items.forEach(item => {
        if (item.closest('.weui-desktop-dialog')) return;

        const isReplied = item.innerText.includes("作者回复") || item.innerText.includes("我的回复");
        if (!isReplied) {
            const user = item.querySelector('.comment-nickname')?.innerText?.trim() || "Unknown";
            const contentEl = item.querySelector('.comment-content');
            pending.push({
                user,
                content: contentEl ? contentEl.innerText.trim() : "Content not found",
                element: item
            });
        }
    });
    return pending;
}

/**
 * 经典批量回复接口（已降级为辅助功能，建议使用智能逐条回复模式）
 */
async function autoReplyRecentArticles(articleLimit = 2, replyText = "感谢关注！🌹") {
    console.warn("注意：建议使用更具真人感的'智能逐条回复'模式。");
    const items = await fetchUnrepliedComments();
    const results = [];

    for (let itemObj of items) {
        console.log(`正在智能回复 ${itemObj.user}...`);
        const status = await _replySingleItem(itemObj.element, replyText);
        results.push({ user: itemObj.user, status });
        await new Promise(r => setTimeout(r, 2000 + Math.random() * 2000));
    }
    return results;
}

